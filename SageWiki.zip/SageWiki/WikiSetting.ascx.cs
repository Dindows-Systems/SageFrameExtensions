﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.Wiki;
using SageFrame.Wiki.Info;
using SageFrame.Common;
using SageFrame.Core;
using SageFrame.Web.Utilities;

public partial class Modules_SageWiki_WikiSetting : BaseAdministrationUserControl
{
    public string Searchmethod;
    public string modulePath;
    public string username;
    public int PortalId;
    public int UserModuleId;
    public string Enablesearch;
    public string Menuitemperpage;

    protected void Page_Load(object sender, EventArgs e)
    {
        modulePath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "globalVariables", " var WikiModulePath='" + ResolveUrl(modulePath) + "';", true);
        UserModuleId = Int32.Parse(SageUserModuleID);
        PortalId = GetPortalID;
        username = GetUsername;
        GetSageWikiSetting();
        
    }



    public SageWikiInfo GetSageWikiSettingList(int PortalID, int UserModuleID)
    {
        SageWikiInfo Getsettin = new SageWikiInfo();
        List<KeyValuePair<string, object>> paramCol = new List<KeyValuePair<string, object>>();
        paramCol.Add(new KeyValuePair<string, object>("@PortalID", PortalID));
        paramCol.Add(new KeyValuePair<string, object>("@UserModuleID", UserModuleID));
        SQLHandler sageSQL = new SQLHandler();
        Getsettin = sageSQL.ExecuteAsObject<SageWikiInfo>("[dbo].[usp_WikiGetWikiSetting]", paramCol);
        return Getsettin;
    }


    private void GetSageWikiSetting()
    {
        SageWikiInfo objset = GetSageWikiSettingList(GetPortalID, Int32.Parse(SageUserModuleID));
        Enablesearch = objset.EnableSearch;
        Searchmethod = objset.SearchMethod;
        Menuitemperpage = objset.MenuItemPerPage;
        
        if (Searchmethod == "Titlewise")
        {
            //rdbTitlewise.Selected = true;
        }
        if (Searchmethod == "Contentwise")
        {
            //rdbContentwise.Selected = true;
        }
    }
}
