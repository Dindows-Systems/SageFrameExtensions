﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.Wiki;
using SageFrame.Wiki.Info;
using System.Web.UI.HtmlControls;

public partial class Modules_SageWiki_WikiEdit : BaseAdministrationUserControl
{
    public string modulePath = "";
    public string SaveImageURL = "";
    public int UserModuleID;
    public int PortalID;
    public string Username = "";
    protected void Page_Load(object sender, EventArgs e)
    {

        UserModuleID = Int32.Parse(SageUserModuleID);
        PortalID = GetPortalID;
        Username = GetUsername;
        modulePath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "globalVariables", " var ModulePath='" + ResolveUrl(modulePath) + "';", true);

        LoadWikiPageOnGrid(UserModuleID, PortalID);
        ShowNumberOfNotApprovedPages(GetPortalID, Int32.Parse(SageUserModuleID));
        EditMultiView1.SetActiveView(grdPages);
        if (!IsPostBack)
        {

            ImageURL();
        }
    }



    private void ImageURL()
    {

        imgCancelPageToApprove.ImageUrl = GetTemplateImageUrl("btncancel.png", true);
    }



    private void LoadWikiPageOnGrid(int UserModuleID, int PortalID)
    {
        try
        {
            WikiController objC = new WikiController();
            gvWikiPagesList.DataSource = objC.LoadWikiPageOnGrid(UserModuleID, PortalID);
            gvWikiPagesList.DataBind();
        }
        catch (Exception ex)
        {
            throw ex;

        }
    }


    protected void gvWikiPagesList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvWikiPagesList.PageIndex = e.NewPageIndex;
        LoadWikiPageOnGrid(UserModuleID, PortalID);

    }



    protected void gvWikiPagesList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        string PageID = e.CommandArgument.ToString();
        switch (e.CommandName.ToString())
        {
            case "DeletePage":
                DeleteWikiPagesByPageName(PageID);
                break;
        }

    }


    private void DeleteWikiPagesByPageName(string PageID)
    {
        try
        {
            WikiController objC = new WikiController();
            objC.DeleteWikiPagesByPageName(PageID);
            LoadWikiPageOnGrid(UserModuleID, PortalID);
            ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/SageWiki/ModuleLocalText", "DeletedSuccesfully"), "", SageMessageType.Success);

        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }


    #region Page To Be approved
    protected void lnkApproved_Click(object sender, EventArgs e)
    {

        GetPageToApprove(Int32.Parse(SageUserModuleID), GetPortalID);
	
        EditMultiView1.SetActiveView(PagePermissionView);
		
		

    }


    public void GetPageToApprove(int UserModuleID, int PortalID)
    {

        List<SageWikiInfo> objGet = new List<SageWikiInfo>();
        objGet = GetPageToBeApproved(UserModuleID, PortalID);
        gdvAllowPage.DataSource = objGet;
        gdvAllowPage.DataBind();

    }


    public List<SageWikiInfo> GetPageToBeApproved(int UserModuleID, int PortalID)
    {

        WikiController objApp = new WikiController();
        return objApp.GetPageToBeApproved(UserModuleID, PortalID);
    }




    protected void gdvAllowPage_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

    }
	 protected void gdvAllowPage_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }


    protected void gdvAllowPage_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {

            int WikiEntryId = Int32.Parse(e.CommandArgument.ToString());
            switch (e.CommandName.ToString())
            {
                case "Delete":
                    Delete(WikiEntryId);
					ShowNumberOfNotApprovedPages(Int32.Parse(SageUserModuleID), GetPortalID);
                  EditMultiView1.SetActiveView(PagePermissionView);
                    break;
                case "Allow":
                    ApprovePages(WikiEntryId);
					ShowNumberOfNotApprovedPages(Int32.Parse(SageUserModuleID), GetPortalID);
                   EditMultiView1.SetActiveView(PagePermissionView);
                    break;
            }
        }
        catch (Exception ex)
        {
            throw (ex);
        }

    }


    private void ApprovePages(int WikiEntryId)
    {
        WikiController objc = new WikiController();
        objc.ApprovePages(WikiEntryId);
        GetPageToApprove(Int32.Parse(SageUserModuleID), GetPortalID);
        //ShowNumberOfNotApprovedPages(GetPortalID,Int32.Parse(SageUserModuleID));
    }


    private void Delete(int WikiEntryId)
    {

        WikiController objc = new WikiController();
        objc.Delete(WikiEntryId);
        GetPageToApprove(Int32.Parse(SageUserModuleID), GetPortalID);
       // ShowNumberOfNotApprovedPages(GetPortalID, Int32.Parse(SageUserModuleID));

    }
    private void ShowNumberOfNotApprovedPages(int PortalID, int UserModuleID)
    {
        try
        {
            lblToApprove.Text = "(" + NumberOfGetPageToBeApprove(PortalID, UserModuleID) + ")";
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private int NumberOfGetPageToBeApprove(int PortalID, int UserModuleID)
    {
        WikiController objC = new WikiController();
        return objC.NumberOfGetPageToBeApprove(PortalID, UserModuleID);
    }


    public List<SageWikiInfo> getAllPages(int PortalID, int UserModuleID)
    {
        try
        {
            WikiController objP = new WikiController();
            return objP.getAllPages(PortalID, UserModuleID);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    protected void CancelButton_Click(object sender, EventArgs e)
    {
        LoadWikiPageOnGrid(UserModuleID, PortalID);
        ShowNumberOfNotApprovedPages(GetPortalID, Int32.Parse(SageUserModuleID));
        EditMultiView1.SetActiveView(grdPages);

    }


    protected void imgCancelPageToApprove_Click(object sender, EventArgs e)
    {
        LoadWikiPageOnGrid(UserModuleID, PortalID);
        // LoadWikiPageOnGrid(UserModuleID, PortalID);
        ShowNumberOfNotApprovedPages(GetPortalID, Int32.Parse(SageUserModuleID));
        EditMultiView1.SetActiveView(grdPages);
    }
    #endregion
}
