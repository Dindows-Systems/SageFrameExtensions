﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using System.Text.RegularExpressions;
using System.Web.UI.HtmlControls;
using System.Collections.Specialized;
using System.Text;
using SageFrame.Wiki;
using SageFrame.Wiki.Info;
using SageFrame.Web.Utilities;
public partial class Modules_SageWiki_WikiView : BaseAdministrationUserControl
{
    public string Searchmethod;
    public string Enablesearch;
    public string Menuitemperpage;
    public string modulePath = "";
    public int UserModuleId;
    public int PortalId;
    public string WikiID;
    public string UserName = "";
    #region Properties
    private const string _defaultPage = "Home";
    private const string _parameterName = "page"; //Wiki PageID
    private const string _aspxExtension = ".aspx";
    private bool _usePathInfo = true;
    public bool UsePathInfo
    {
        get
        {
            //If the current page has query string info (the raw un-url rewritten value) we should use the query string string technique and not path info.
            //Note: We can't use Request.PathInfo when URL Rewriting is in place (i.e in BlogEngine.NET)
            //The path info component is lost so we have to manually extract it from the RawURL.
            if (Request.RawUrl.TrimEnd('?').Contains('?'))
            {
                return false;
            }
            else return _usePathInfo;
        }
        set
        {
            _usePathInfo = value;
        }
    }

    public bool DisplayVersionHistory { get; set; }

    public bool DisableTitleModification { get; set; }

    public bool DisplayQuickLinks { get; set; }

    private const string _defaultSytaxHighlighterBrush = "c#";
    private string _syntaxHighlighterBrush;
    public string SyntaxHighlighterBrush
    {
        get
        {
            if (String.IsNullOrEmpty(_syntaxHighlighterBrush)) return _defaultSytaxHighlighterBrush;
            else return _syntaxHighlighterBrush;
        }
        set
        {
            _syntaxHighlighterBrush = value;
        }
    }

    //Multiple instances of the wiki can exist on the same database.
    private string _instanceID = "Default";
    public string InstanceID
    {
        get
        {
            return _instanceID;
        }
        set
        {
            _instanceID = value;
        }
    }
    protected string IsApproved
    {
        get
        {
            if (ViewState["IsApproved"] == null)
            {
                ViewState["IsApproved"] = CheckIsApproved();
            }
            return Convert.ToString(ViewState["IsApproved"]);
        }
        set
        {
            ViewState["IsApproved"] = value;
        }
    }

    private string pageID; //cached result;
    protected string PageID
    {
        get
        {
            return BreadCrumbs[BreadCrumbs.Length - 1];
        }
    }
    bool _hasOtherPages;

    #endregion
protected void Page_Init(object sender, EventArgs e)
{
        IncludeJS();
        IncludeCss();
        
}

    protected void Page_Load(object sender, EventArgs e)
    {

        
        InitializeVariables();
        WikiVisibility();
        Event();
        HtmlLink wikiCss = new HtmlLink();
        wikiCss.Attributes["rel"] = "stylesheet";
        wikiCss.Attributes["type"] = "text/css";
        wikiCss.Href = ResolveUrl("Wiki.css");
        Page.Header.Controls.Add(wikiCss);
        if (!DisableTitleModification && PageID != _defaultPage)
        {
            string title = Page.Header.Title;
            if (title != "") title = Page.Header.Title + " | ";
            Page.Header.Title = title + PageID;
        }
        if (_hasOtherPages)
        {
            SetBreadCrumb();
        }
        if (!IsPostBack)
        {
            LoadPage();
            LoadRatingDataOngdv(GetPortalID, Convert.ToInt32(WikiID));
            ImageURL();

        }
        GetSageWikiSetting();
    }


    private void InitializeVariables()
    {
        UserName = GetUsername;
        modulePath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "globalVariables", " var WikiServicePath='" + ResolveUrl(modulePath) + "';", true);
        UserModuleId = Int32.Parse(SageUserModuleID);
        PortalId = GetPortalID;
    }

    private void WikiVisibility()
    {
        string username = Page.User.Identity.Name.ToLower();
        if (username == "superuser" || username == "admin")
        {
            AddPageButton.Visible = true;
        }
        else
        {
            AddPageButton.Visible = false;
        }
        if (!_hasOtherPages || !DisplayQuickLinks)
        {
            QuickLinksLabel.Visible = false;
        }
        ErrorLabel.Visible = false;
        QuickLinksLabel.Visible = true;
        EditButton.Visible = Page.User.Identity.IsAuthenticated;
        //toolbarDiv.Visible = Page.User.Identity.IsAuthenticated || DisplayVersionHistory;
        ErrorLabel.Text = "";
        ErrorLabel.Visible = false;
        _hasOtherPages = SetQuickLinks();
    }


    private void ImageURL()
    {
        try
        {
            ImageFirst.ImageUrl = ResolveUrl("Images/first.png");
            ImagePrevious.ImageUrl = ResolveUrl("Images/previous.png");
            ImageNext.ImageUrl = ResolveUrl("Images/next.png");
            ImageLast.ImageUrl = ResolveUrl("Images/last.png");
            ImageSave.ImageUrl = GetTemplateImageUrl("btnsave.png", true);
            ImageCancel.ImageUrl = GetTemplateImageUrl("btncancel.png", true);
            ImageEdit.ImageUrl = GetTemplateImageUrl("btnedit.png", true);
            imgSearch.ImageUrl = ResolveUrl("Images/search-btn.jpg");
            imgAddPage.ImageUrl = ResolveUrl("Images/add.png");
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    private void Event()
    {
        string notDirty = "dirty = false;";
        string dirty = "dirty = true;";
        SaveButton.Attributes["onclick"] = notDirty;
        CancelButton.Attributes["onclick"] = notDirty;
        WikiTitleTextBox.Attributes["onkeyup"] = notDirty;
        wmd_input.Attributes["onkeyup"] = dirty;
    }



    private void IncludeCss()
    {
        IncludeCss("SagwWiki", "/Modules/SageWiki/Markdown/wmd.css", "/Modules/SageWiki/Css/jquery.rating.css", "/Modules/SageWiki/Wiki.css", "/Modules/SageWiki/Css/PaginStyle.css");

    }


    private void IncludeJS()
    {
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "ReplaceCodeTags", @"
            function wikiControl_replaceCodeTags() {
                $('pre:has(code)').addClass('brush: " + SyntaxHighlighterBrush + @"');
                $('pre>code').each(function(index) {
                    var cnt = $(this).contents();
                    $(this).replaceWith(cnt);    
                });
            }", true);


        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "ProcessCodeTags", @"
                    if (typeof(SyntaxHighlighter) != 'undefined' && typeof(jQuery) != 'undefined') {
                        $(document).ready(function () { 
                            wikiControl_replaceCodeTags();
                        });
                     }", true);
        IncludeJs("SageWiki", "/Modules/SageWiki/Markdown/wmd.js ", "/Modules/SageWiki/js/jquery.MetaData.js", "/Modules/SageWiki/js/jquery.rating.js", "/Modules/SageWiki/js/script.js");
    }


    private string LinkToPageID(string pageTitle)
    {
        return "<a class='wikiLink' href='" + UrlToPageID(pageTitle) + "'>" + pageTitle + "</a>";
    }


    private string UrlToPageID(string pageID)
    {
        pageID = Hyphenate(pageID);
        //Important that we use RawUrl since this is the original request before Url Rewriting has modified it.
        string rawUrl = Request.RawUrl;
        rawUrl = rawUrl.TrimEnd('?'); //trim off unused ? at the end of the RawUrl

        if (UsePathInfo)
        {
            //If there is already some PathInfo clear it with the new page ID (assuming the current site isn't using PathInfo already!)
            //This may need to be rewritten if that case needs to be supported.
            if (pageID == _defaultPage)
                return rawUrl.Substring(0, rawUrl.IndexOf(_aspxExtension) + _aspxExtension.Length);
            if (rawUrl.Contains(pageID))
            {
                return rawUrl.Substring(0, rawUrl.IndexOf(pageID) + pageID.Length);
            }
            else
            {
                return rawUrl + "?page=" + pageID;
            }
        }
        else
        {
            //Need to maintain the current query string values otherwise the right page may not even display.        
            string pattern = _parameterName + "=([^&]*)";
            string replace = null;
            string match = Regex.Match(rawUrl, pattern).ToString();

            if (pageID == _defaultPage)
            {
                replace = "";
            }
            else if (match.Contains(pageID))
            {
                replace = match.Substring(0, match.IndexOf(pageID) + pageID.Length);
            }
            else
            {
                replace= "page=" + Server.UrlEncode(pageID);
            }

            //Preserve original query string.
            if (rawUrl.Contains(_parameterName + "="))
            {
            string url=Regex.Replace(rawUrl, pattern, replace);
            return url.TrimEnd('?');
            }
            else
            {
                string param = _parameterName + "=" + Server.UrlEncode(pageID);
                if (rawUrl.Contains("?"))
                    return rawUrl + "&" + param;
                else
                    return rawUrl + "?" + param;
            }
        }
    }

    #region rating details region
    public void LoadRatingDataOngdv(int PortalID, int WikiID)
    {
        try
        {
            WikiController objC = new WikiController();
            gdvStarRatingDetail.DataSource = objC.LoadRatingDataOngdv(PortalID, WikiID);
            gdvStarRatingDetail.DataBind();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void gdvStarRatingDetail_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvStarRatingDetail.PageIndex = e.NewPageIndex;
        LoadRatingDataOngdv(PortalId, Convert.ToInt32(WikiID));
    }
    #endregion

    protected int GetLatestPageVersion()
    {
        int version;
        WikiController objc = new WikiController();
        SageWikiInfo sgObj = objc.getLatesPageVersion(InstanceID, PageID);
        version = sgObj.Version;
        if (version == -1)
        {
            version = 0;
        }
        return version;

    }


    protected string CheckIsApproved()
    {
        WikiController objWiki = new WikiController();
        SageWikiInfo Obj = objWiki.CheckIsApproved(InstanceID, PageID, PageVersion);
        return Obj.IsApproved;
    }


    protected string[] BreadCrumbs
    {
        get
        {
            List<string> breadCrumbs = new List<string>();
            breadCrumbs.Add(_defaultPage);
            string path;
            if (UsePathInfo)
            {
                path = Request.RawUrl.Substring(Request.RawUrl.IndexOf(_aspxExtension) + _aspxExtension.Length).TrimEnd('/').TrimEnd('?').TrimStart('/');
            }
            else
            {
                path = Request.QueryString[_parameterName];
            }

            if (!String.IsNullOrEmpty(path))
                breadCrumbs.AddRange(path.Split('/').Select(breadCrumb => UnHyphenate(breadCrumb)));

            return breadCrumbs.ToArray();

        }
    }


    protected int PageVersion
    {
        get
        {
            if (ViewState["PageVersion"] == null)
            {
                ViewState["PageVersion"] = GetLatestPageVersion();
            }
            return (int)ViewState["PageVersion"];
        }
        set
        {
            ViewState["PageVersion"] = value;
        }
    }


    protected void ActiveViewChanged(object sender, EventArgs args)
    {
        if (MultiView1.Views[MultiView1.ActiveViewIndex].ID == "editView")
        {
            HtmlLink wmdCss = new HtmlLink();
            wmdCss.Attributes["rel"] = "stylesheet";
            wmdCss.Attributes["type"] = "text/css";
            wmdCss.Href = ResolveUrl("Markdown/wmd.css");
            Page.Header.Controls.Add(wmdCss);

            HtmlGenericControl showdownRef = new HtmlGenericControl();
            showdownRef.TagName = "script";
            showdownRef.Attributes["src"] = ResolveUrl("Markdown/showdown.js");
            showdownRef.Attributes["type"] = "text/javascript";
            Page.Header.Controls.Add(showdownRef);


            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "SyntaxHighlight", @"
                function wikiControl_syntaxHighlight() {
                    wikiControl_replaceCodeTags();
                    SyntaxHighlighter.highlight();
                }", true);

            ScriptManager.RegisterStartupScript(this, this.GetType(), "CheckSyntaxHighlighter", @"
                if (typeof(SyntaxHighlighter) == 'undefined' || typeof(jQuery) == 'undefined') 
                    document.getElementById('wikiControl_formatCodeButton').style.display = 'none';
            ", true);
        }
    }


    private void SetBreadCrumb()
    {
        BreadCrumbLabel.InnerHtml = "";
        foreach (string breadCrumb in BreadCrumbs)
        {
            BreadCrumbLabel.InnerHtml = BreadCrumbLabel.InnerHtml + LinkToPageID(breadCrumb);
        }
    }


    private bool SetQuickLinks()
    { //Returns true if there are other pages linked to in this wiki.
        QuickLinksLabel.InnerHtml = "";
        List<SageWikiInfo> obj = new List<SageWikiInfo>();
        obj = getAllPages(PortalId, UserModuleId);
        if (obj.Count > 0)
        {
            QuickLinksLabel.InnerHtml += "<ul id='holder'>";
            foreach (SageWikiInfo ob in obj)
            {
                QuickLinksLabel.InnerHtml += "<li>" + LinkToPageID(ob.PageID) + "</li>";
            }
            QuickLinksLabel.InnerHtml += "</ul>";
            QuickLinksLabel.InnerHtml = QuickLinksLabel.InnerHtml.TrimEnd(',', ' ');

            return true;
        }
        else
        {
            return false;
        }
    }


    private void LoadPage()
    {
        try
        {
            if (PageVersion > 0)
            {
                SageWikiInfo obj = new SageWikiInfo();
                obj = LoadWikiDataOnPage(PageVersion, PageID, InstanceID, UserModuleId, PortalId);
				if(obj!=null)
				{
                WikiTitleTextBox.Visible = (pageID != _defaultPage);
                WikiTitleTextBox.Text = PageID;
                WikiTitleTextBox.Enabled = false;
                hdfWikiEntryID.Value = Convert.ToString(obj.WikiEntryID);
                WikiID = hdfWikiEntryID.Value;
                MarkdownSharp.Markdown markdown = new MarkdownSharp.Markdown();
                markdown.AutoHyperlink = true;
                string toRender = Regex.Replace(obj.Text, @"\[\[([A-Za-z ,\._\-]*)\]\]", new MatchEvaluator(ReplacePage));
                WikiEntryLabel.InnerHtml = markdown.Transform(toRender);
                wmd_input.Text = obj.Text;
                AuthorLabel.InnerHtml = "By " + obj.AuthorName + " <span>on " + obj.TimeCreated.ToShortDateString() + " (revision " + obj.Version + ")</span>";
                MultiView1.SetActiveView(displayView);
                ErrorLabel.Visible = false;
				}
            }
            else
            {
                BackButton.Enabled = false;
                wmd_input.Text = "";
                WikiTitleTextBox.Visible = (PageID != _defaultPage);
                WikiTitleTextBox.Text = PageID;
                // If there is no content, default to Edit Mode.
                if (Page.User.Identity.IsAuthenticated) MultiView1.SetActiveView(editView);
                ErrorLabel.Text = "There is no content for this item, please add some.";
                ErrorLabel.Visible = true;
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }


    public SageWikiInfo LoadWikiDataOnPage(int PageVersion, string PageID, string InstanceID, int UserModuleID, int PortalID)
    {
        WikiController objC = new WikiController();
        return objC.LoadWikiDataOnPage(PageVersion, PageID, InstanceID, UserModuleID, PortalID);

    }

    public string ReplacePage(Match m)
    {
        return LinkToPageID(m.Groups[1].ToString());
    }

    protected void AddPageButton_Click(object sender, EventArgs e)
    {
        PageVersion = 0;
        wmd_input.Text = "";
        WikiTitleTextBox.Visible = true;
        WikiTitleTextBox.Enabled = true;
        WikiTitleTextBox.Text = "";
        MultiView1.SetActiveView(editView);
    }
    protected void SaveButton_Click(object sender, EventArgs e)
    {
        string username = Page.User.Identity.Name.ToLower();
        SageWikiInfo OBJINF = new SageWikiInfo();
        if (PageVersion != GetLatestPageVersion())
        {
            ErrorLabel.Text = "Someone else has modified this page since loading. Cannot save entry.";
            ErrorLabel.Visible = true;
        }

        else
        {
            //List<SageWikiInfo> obj = new List<SageWikiInfo>();
            //obj = getAllPages(PortalId, UserModuleId);
            //if (obj.Count > 0)
            //{
            //    foreach (SageWikiInfo ob in obj)
            //    {
            //        if (String.Compare(WikiTitleTextBox.Text, ob.PageID,true) == 0)
            //        {
            //            ErrorLabel.Text = "A page of this name already exists, please choose another.";
            //            ErrorLabel.Visible = true;
            //            return;
            //        }
            //    }
            //}
            //using (WikiDataContext ctx = new WikiDataContext())
            //{
            //    //If title has changed
            //    if (String.Compare(WikiTitleTextBox.Text, PageID, true) != 0)
            //    {
            //        var query = from w in ctx.WikiEntries
            //                    where
            //                        w.InstanceID == InstanceID &&
            //                        w.PageID == WikiTitleTextBox.Text
            //                    select w;

            //        if (query.Count() > 0)
            //        {
            //            ErrorLabel.Text = "A page of this name already exists, please choose another.";
            //            ErrorLabel.Visible = true;
            //            return;
            //        }


            //    }
            //    //Insert the new version of the page.

            //}

        }
        OBJINF.InstanceID = InstanceID;
        OBJINF.PageID = WikiTitleTextBox.Text;
        OBJINF.AuthorName = Page.User.Identity.Name;
        OBJINF.Text = wmd_input.Text;
        OBJINF.Version = ++PageVersion;
        if (username == "superuser")
        {
            OBJINF.IsApproved = "True";
        }
        else
        {
            OBJINF.IsApproved = "False";
        }
        OBJINF.TimeCreated = DateTime.Now;
        OBJINF.UserModuleID = Int32.Parse(SageUserModuleID);
        OBJINF.PortalID = GetPortalID;
        WikiController objc = new WikiController();
        objc.SaveWikiData(OBJINF);
        MultiView1.SetActiveView(displayView);
		  
       
        SetQuickLinks();
		
        LoadPage();
        MultiView1.SetActiveView(displayView);
    }


    public List<SageWikiInfo> getAllPages(int PortalID, int UserModuleID)
    {
        try
        {
            WikiController objP = new WikiController();
            return objP.getAllPages(PortalID, UserModuleID);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }



    private string Hyphenate(string s)
    {
        return s.Replace(" ", "-");
    }


    private string UnHyphenate(string s)
    {
        return s.Replace("-", " ");
    }


    protected void CancelButton_Click(object sender, EventArgs e)
    {
        try
        {
            PageVersion = GetLatestPageVersion();
            LoadPage();
            LoadRatingDataOngdv(PortalId, Int32.Parse(WikiID));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    protected void EditButton_Click(object sender, EventArgs e)
    {
        try
        {
            PageVersion = GetLatestPageVersion();
            LoadPage();
            MultiView1.SetActiveView(editView);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    protected void FirstButton_Click(object sender, EventArgs e)
    {
        try
        {
            PageVersion = 1;
            LoadPage();
            LoadRatingDataOngdv(PortalId, Convert.ToInt32(WikiID));
        }
        catch (Exception xe)
        {
            throw xe;
        }
    }


    protected void LastButton_Click(object sender, EventArgs e)
    {
        try
        {
            PageVersion = GetLatestPageVersion();
            LoadPage();
            LoadRatingDataOngdv(PortalId, Convert.ToInt32(WikiID));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    protected void BackButton_Click(object sender, EventArgs e)
    {
        try
        {
            if (PageVersion > 1)
            {

                --PageVersion;
            }
            LoadPage();
            LoadRatingDataOngdv(PortalId, Convert.ToInt32(WikiID));
            QuickLinksLabel.Visible = true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    protected void NextButton_Click(object sender, EventArgs e)
    {
        try
        {
            if (PageVersion != GetLatestPageVersion())
            {

                ++PageVersion;
            }


            LoadPage();
            LoadRatingDataOngdv(PortalId, Convert.ToInt32(WikiID));
            QuickLinksLabel.Visible = true;
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }


    #region PageSearch


    protected void lnkSearch_Click(object sender, EventArgs e)
    {
        QuickLinksLabel.Visible = false;
        BreadCrumbLabel.Visible = false;
        var SearchString = txtSearch.Text;
        List<SageWikiInfo> obj = new List<SageWikiInfo>();
        if (Searchmethod == "Contentwise")
        {
            obj = getSearchedPageContentwise(SearchString);
        }
        if (Searchmethod == "Titlewise")
        {

            obj = getSearchedPage(SearchString);
        }
        if (obj.Count > 0)
        {

            WikiEntryLabel.InnerHtml = "";
			WikiEntryLabel.InnerHtml += "<h3>Searched Result For:" + SearchString + "</h3>" + Environment.NewLine;
            foreach (SageWikiInfo ob in obj)
            {

                MarkdownSharp.Markdown markdown = new MarkdownSharp.Markdown();
                markdown.AutoHyperlink = true;
                
                WikiEntryLabel.InnerHtml += LinkToPageID(ob.PageID);
                string Description = ob.Text;
                if (Description.Length > 200)
                {
                    Description = ob.Text.Substring(0, 200) + "....";
                }
                else
                {
                    Description = ob.Text;
                }
                string toRender = Regex.Replace(Description, @"\[\[([A-Za-z ,\._\-]*)\]\]", new MatchEvaluator(ReplacePage));
                WikiEntryLabel.InnerHtml += markdown.Transform(toRender);
                wmd_input.Text = ob.Text;
            }
            AuthorLabel.Visible = false;
            toolbarDiv.Visible = false;
            divRating.Visible = false;

            MultiView1.SetActiveView(displayView);
        }
        else
        {
            divRating.Visible = false;
            AuthorLabel.Visible = false;
            toolbarDiv.Visible = false;
            WikiEntryLabel.InnerHtml = "";
            WikiEntryLabel.InnerHtml = "<h3>OOPS! searched article doesn't exist</h3>";
            MultiView1.SetActiveView(displayView);


        }


    }


    public List<SageWikiInfo> getSearchedPage(string SearchString)
    {
        WikiController objCt = new WikiController();

        return objCt.getSearchedPage(SearchString, Int32.Parse(SageUserModuleID), GetPortalID);

    }


    public List<SageWikiInfo> getSearchedPageContentwise(string SearchString)
    {
        WikiController objCt = new WikiController();
        return objCt.getSearchedPageContentWise(SearchString, Int32.Parse(SageUserModuleID), GetPortalID);

    }


    #endregion


    #region SageWikisetting


    public SageWikiInfo GetSageWikiSettingList(int PortalID, int UserModuleID)
    {
        WikiController objC = new WikiController();
        return objC.GetSageWikiSettingList(PortalId, UserModuleID);

    }


    private void GetSageWikiSetting()
    {
        try
        {
            SageWikiInfo objset = GetSageWikiSettingList(GetPortalID, Int32.Parse(SageUserModuleID));
            Searchmethod = objset.SearchMethod;
            Searchmethod = objset.SearchMethod;
            Enablesearch = objset.EnableSearch;
            Menuitemperpage = objset.MenuItemPerPage;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    #endregion

}
