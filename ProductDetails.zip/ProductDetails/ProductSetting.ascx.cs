﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;

public partial class Modules_Product_ProductSetting : BaseAdministrationUserControl
{
    public int ModuleID, PortalID;
    public string serviceURL, handlerURL, resolvedURL;
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {

            this.ModuleID = Int32.Parse(SageUserModuleID);
            this.PortalID = GetPortalID;
            this.serviceURL = ResolveUrl(this.AppRelativeTemplateSourceDirectory) + "Services/ProductDetailsWebService.asmx/";
            this.handlerURL = ResolveUrl(this.AppRelativeTemplateSourceDirectory) + "Handler/ProductDetailHandler.ashx";
           

        }
        this.resolvedURL = ResolveUrl("~/");
        IncludeJS();



    }
    private void IncludeJS()
    {
        Page.ClientScript.RegisterClientScriptInclude("Product", ResolveUrl("~/Modules/ProductDetails/js/ProductSetting.js"));
        Page.ClientScript.RegisterClientScriptInclude("encoder", ResolveUrl("~/Modules/ProductDetails/js/ajaxupload.js"));
       

    }
}
