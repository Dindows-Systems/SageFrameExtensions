﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;

public partial class Modules_Product_ProductView :BaseAdministrationUserControl
{
    public string serviceURL,ResolvedURL;
    public int PortalID, UserModuleID;
    protected void Page_Load(object sender, EventArgs e)
    {
        this.serviceURL = ResolveUrl(this.AppRelativeTemplateSourceDirectory) + "Services/ProductDetailsWebService.asmx/";
        this.PortalID = GetPortalID;
        this.UserModuleID = Int32.Parse(SageUserModuleID);
		this.ResolvedURL = ResolveUrl("~/");
        IncludeCSS();
        includejs();

    }

    private void includejs()
    {
        Page.ClientScript.RegisterClientScriptInclude("ProductView", ResolveUrl("~/Modules/ProductDetails/js/ProductView.js"));
        Page.ClientScript.RegisterClientScriptInclude("Product", ResolveUrl("~/Modules/ProductDetails/js/tmpl.js"));
        Page.ClientScript.RegisterClientScriptInclude("encoder", ResolveUrl("~/Modules/ProductDetails/js/encoder.js"));
       
    }
    private void IncludeCSS()
    {
        IncludeCss("ProductDetails", "/Modules/ProductDetails/css/ProductDetails.css");
    }
}
