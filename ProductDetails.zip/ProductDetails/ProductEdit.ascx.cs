﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;

public partial class Modules_Product_ProductEdit :BaseAdministrationUserControl
{
    public int UserModuleID, PortalID;
    public string serviceURL, resolvedURL, handlerURL;
    protected void Page_Load(object sender, EventArgs e)
    {
        UserModuleID = Int32.Parse(SageUserModuleID);
        PortalID = GetPortalID;
        this.serviceURL = ResolveUrl(this.AppRelativeTemplateSourceDirectory) + "Services/ProductDetailsWebService.asmx/";
        this.resolvedURL = ResolveUrl("~/");
        this.handlerURL = ResolveUrl(this.AppRelativeTemplateSourceDirectory) + "Handler/ProductDetailHandler.ashx";
        InitializeCSS();
        InitializeJS();
        if (!IsPostBack)
        {
           
        }

    }


    private void InitializeJS()
    {

        IncludeJs("ProductEdit", false, "/Modules/ProductDetails/js/ProductEdit.js");
        IncludeJs("ProductDetails", false, "/Modules/ProductDetails/js/ajaxupload.js");
    }

    private void InitializeCSS()
    {
     IncludeCss("ProductDetails", "/Modules/ProductDetails/css/ProductDetails.css");
    }
}
