﻿$(function() {
    ProductSetting.Config.UserModuleID = ProductModuleID;
    ProductSetting.Config.PortalID = ProductPortalID;
    ProductSetting.Config.ServiceURL = ProductServiceURL;
    ProductSetting.Config.HandlerURL = ProductHandlerURL;
    ProductSetting.GetSettings();
    NoImageUploaderProduct();
    $(".integer").bind("keypress", function(e) {
        if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
            return false;
        }
    });
});

var ProductSetting = {
    Config: {
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        ServiceURL: '',
        HandlerURL: '',
        UserModuleID: '',
        PortalID: ''
    },

    GetSettings: function() {
        $.ajax({
            type: ProductSetting.Config.type,
            url: ProductSetting.Config.ServiceURL + "GetAllSettings",
            data: JSON2.stringify({ userModuleID: ProductSetting.Config.UserModuleID, portalID: ProductSetting.Config.PortalID }),
            contentType: ProductSetting.Config.contentType,
            dataType: ProductSetting.Config.dataType,
            success: function(data) {
                var value = eval(data.d);
                $("#chkShowProductDescription").attr("checked", $.parseJSON(value.ShowProductDescription.toLowerCase()));
                $("#chkShowProductPrice").attr("checked", $.parseJSON(value.ShowProductPrice.toLowerCase()));
                if (value.CategoryNoImage != "") {
                    $("#divCateogoryNoImage").html('<img src="' + resolvedURL + value.CategoryNoImage + '" height="90px" width="100px"/>');
                }
                else {
                    $("#divCateogoryNoImage").html('No default image for category.Please upload....');
                }
                if (value.ProductNoImage != "") {
                    $("#divProductNoImage").html('<img src="' + resolvedURL + value.ProductNoImage + '" height="90px" width="100px"/>');
                }
                else {
                    $("#divProductNoImage").html('No default image for Product.Please upload....');
                }
            },
        error: function() {
                alert('error');
            }
        });
    },
    error: function() {
        alert("Error");
    },
    SaveSetting: function() {
        var settingKeys = '';
        var settingValues = '';
        settingKeys += 'ProductNoImage#ShowProductDescription#ShowProductPrice';
        var isShowProductDesc = $("#chkShowProductDescription").attr("checked");
        var isShowProductPrice = $("#chkShowProductPrice").attr("checked");
        var prodNoImage = '';
        if ($("#divProductNoImage").find('img').attr("src") == undefined) {

            alert("Please upload product no image");
            return false;
        }
        else {
            prodNoImage = $("#divProductNoImage").find('img').attr("src").replace(resolvedURL, '');

        }
        settingValues += prodNoImage + "#" + isShowProductDesc + "#" + isShowProductPrice;

        $.ajax({
            type: ProductSetting.Config.type,
            url: ProductSetting.Config.ServiceURL + "SaveSettings",
            data: JSON2.stringify({ settingKeys: settingKeys, settingValues: settingValues, userModuleID: ProductSetting.Config.UserModuleID, portalID: ProductSetting.Config.PortalID }),
            contentType: ProductSetting.Config.contentType,
            dataType: ProductSetting.Config.dataType,
            success: function() {
                SageFrame.messaging.show(" Setting updated successfully", "Success");
            },
            error: function() {
                alert('error');
            }
        });
    }
};

$('.SaveSetting,.cssSaveSetting').live("click", function(e) {
    e.preventDefault();
    ProductSetting.SaveSetting();
});






function NoImageUploaderProduct() {
    var maxFileSizeProduct = 50000;
    var upload = new AjaxUpload($('#fluProductNoImage'), {
        action: ProductSetting.Config.HandlerURL,
        name: 'myfile[]',
        multiple: false,
        data: {},
        autoSubmit: true,
        responseType: 'json',
        onChange: function(file, ext) {
        },
        onSubmit: function(file, ext) {
            if (ext != "exe") {
                if (ext && /^(jpg|jpeg|jpe|gif|bmp|png|ico)$/i.test(ext)) {
                    this.setData({
                        'MaxFileSize': maxFileSizeProduct
                    });
                } else {
                    alert('<h1>Alert Message</h1><p>Not a valid image!</p>');
                    return false;
                }
            }
            else {
                alert('<h1>Alert Message</h1><p>Not a valid image!</p>');
                return false;
            }
        },
        onComplete: function(file, response) {
            var res = eval(response);
            if (res.Message != null && res.Status > 0) {
                $("#divProductNoImage").html('<img src="' + resolvedURL + res.Message + '"  height="90px" width="100px" alt="' + res.Message + '"/>');
               // AddNewImagesProduct(res);
                return false;
            }
            else {
                alert('error on upload');
                // csscody.error('<h1>Error Message</h1><p>' + res.Message + '</p>');
                return false;
            }
        }
    });
}

