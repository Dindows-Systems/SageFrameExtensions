﻿var arrResultToBind = new Array();
    
var options = {
    currPage: 1,
    optionsForRows: [5, 10, 25, 50, 100],
    rowsPerPage: 5,
    firstArrow: (new Image()).src = "",
    prevArrow: (new Image()).src = "Modules/ProductDetails/images/data-previous.png",
    lastArrow: (new Image()).src = "",
    nextArrow: (new Image()).src = "Modules/ProductDetails/images/data-next.png",
    topNav: false,
    ProductNoImage: 'Modules/ProductDetails/Images/NoDrugImg.png'
};
var pagingOptions = {
    current: 1,
    pageSize: 5
};
var theOptions = {
    question: "Are You Sure ?",
    yesAnswer: "Yes",
    cancelAnswer: "Cancel"
};
var UserSettingData = {
    ProductNoImage: '',
    ShowProductDescription: '',
    ShowProductPrice: ''
};
$(function() {
    GetAllcategory();
    GetUserSettingData();

    GetProductListFront(0, pagingOptions.current, pagingOptions.pageSize);
    divVisibility(true, false);
});

function GetUserSettingData() {
    $.ajax({
        type: "POST",
        async: false,
        url: ProductSercviceurl + "GetAllSettings",
        data: JSON2.stringify({ userModuleID: UserModuleId, portalID: PortalId }),
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function(data) {
            var value = eval(data.d);
           UserSettingData.ProductNoImage = resolvedurl + value.ProductNoImage;
           UserSettingData.ShowProductDescription = value.ShowProductDescription;
            UserSettingData.ShowProductPrice = value.ShowProductPrice;


        },
        error: function() {
            alert('error');
        }
    });
}
function GetAllcategory() {
    $.ajax({
        type: "POST",
        url: ProductSercviceurl + "GetCategoryListFront",
        data: JSON2.stringify({
            userModuleID: UserModuleId, portalID: PortalId
        }),
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function(data) {
            var htmlCategory = '';
            $.each(data.d, function(index, value) {
                htmlCategory += '<option value=' + value.CategoryID + '>' + value.Name + '</option>';

            });
            $('#ddlCategory').append(htmlCategory);
        },
        error: function() {
            // alert('error');
        }
    });

}

function GetProductListFront(categoryID, current, pageSize) {
    $.ajax({
        type: "POST",
        url: ProductSercviceurl + "GetProductListFront",
        data: JSON2.stringify({ categoryID: categoryID,
            userModuleID: UserModuleId, portalID: PortalId, current: current, pageSize: pageSize
        }),
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function(data) {

            var productName = '';
            var counter = 0;
            var totalPage = 0;
            var pageElements = '';
            arrResultToBind.length = 0;
            $(".cssClassMarketPlaceFrontProductListing #sfProductListing>ul").html('');
            $("#productPaging").show();
            var viewElem = '';
            viewElem += '<input type="radio" name="viewby" value="1"/> <label>Grid</label>';
            viewElem += '<input type="radio" name="viewby" value="2"/><label>List</label>';
            if (data.d.length > 0) {

                $(".viewmode a").bind("click", function() {
                    $("#hdnViewAs").val($(this).attr("type"));
                    BindProductResult();
                });

                $.each(data.d, function(index, value) {
                    totalPage = value.RowTotal;
                    //alert(productName.indexOf(value.Name));
                    if (productName.indexOf(value.Name) == -1) {
                        arrResultToBind.push(value);
                        productName = productName + value.Name + ',';
                    }
                    else {
                        counter++;
                    }
                });

                var pageNo = Math.ceil(totalPage / pageSize);
                var iscurrExist = false;
                pageElements += '<div id="Pagination" class="pagination">';
                for (var i = 1; i <= parseInt(pageNo); i++) {
                    if (i == current) {
                        iscurrExist = true;
                        pageElements += '<a href="#"><span class="current">' + i + '</span></a>';
                    }
                    else {
                        pageElements += '<a href="#"><span>' + i + '</span></a>';
                    }
                }
                pageElements += '</div>';
                pageElements += '<div class="sfViewperpage"> View Per Page';
                pageElements += '<select id="ddlProductPageSize" class="sfListmenu"><option value="5" selected="selected">5</option>';
                pageElements += '<option value="10">10</option><option value="15">15</option><option value="20">20</option>';
                pageElements += '<option value="25">25</option><option value="40">40</option></select></div>';

                $("#productPaging").show().html(pageElements);
                $("#ddlProductPageSize option[value='" + pageSize + "']").attr("selected", "selected");
                if (!iscurrExist) {
                    $("#Pagination").find('a:last').find('span').addClass('current');
                }

                $("#Pagination").find('a').bind("click", function(e) {
                    e.preventDefault();
                    $("#Pagination").find('a span').removeAttr('class');
                    $(this).find('span').addClass('current');
                    $(this).attr("disabled", "disabled");
                    var curr = $(this).find('span[class="current"]').html();
                    var pgSize = $("#ddlProductPageSize").val();
                    GetProductListFront(categoryID, curr, pgSize);
                });
                $("#Pagination").find('a>span[class="current"]').parent('a').unbind("click");
                $("#ddlProductPageSize").bind("change", function() {
                    var items_per_page = $(this).val();
                    var curr = pagingOptions.current;
                    GetProductListFront(categoryID, curr, items_per_page);
                });
                BindProductResult();

            }
            else {
                $(".cssClassMarketPlaceFrontProductListing #sfProductListing>ul").html('<b>no products found !!</b>');
                $("#productPaging").hide();
                $(".cssClassMarketPlaceFrontProductListing #sfProductListing .sfViewas").html('');

            }

        },
        error: function() {

        }

    });
    function BindProductResult() {
        var viewAsOption = $("#hdnViewAs").val();
        if (arrResultToBind.length > 0) {
            switch (viewAsOption) {
                case '1':
                    ProductGridView();

                    break;
                case '2':
                    ProductListView();
                    break;

            }

        }
					
        if (UserSettingData.ShowProductPrice == "false") {
            $('.pPrice').hide();
			//$('.sfPrice').hide();

        }
		
         if (UserSettingData.ShowProductDescription == "false") {
            $('.cssShortDescription').hide();
        }
		
    }
}

function ProductListView() {
    $("#sfProductListing>ul").html('');

    $.each(arrResultToBind, function(index, value) {
        if (value.ImagePath == "") {
            value.ImagePath = options.ProductNoImage;
        }
        else if (value.AlternateText == "") {
            value.AlternateText = value.Name;
        }

        var ccPrice = '$' + value.Price;
        var items = [{ imagePath: value.ImagePath, alt: value.AlternateText, name: value.Name,
            productID: value.ProductID, price: ccPrice,
            shortDescription: value.ShortDescription}];

            $("#MarketPlaceList").tmpl(items).appendTo("#sfProductListing>ul");
        });



        $(".cssClassProductReadMore").bind("click", function(e) {
            e.preventDefault();
            var productID = parseInt($(this).attr("id").replace(/[^0-9]/gi, ''));
            GetProductDetails(productID);
            divVisibility(false, true);
        });


    }
    function ProductGridView() {
        $("#sfProductListing>ul").html('');

        $.each(arrResultToBind, function(index, value) {

            if (value.ImagePath == "") {
                value.ImagePath = options.ProductNoImage;
            }
            else if (value.AlternateText == "") {
                value.AlternateText = value.Name;
            }

            var ccPrice = '$' + value.Price;

            var items = [{ imagePath: value.ImagePath, alt: value.AlternateText, name: value.Name,
                productID: value.ProductID, price: ccPrice
            , shortDescription: value.ShortDescription}];

                $("#MarketPlaceGrid").tmpl(items).appendTo("#sfProductListing>ul");
            });
            $("#sfProductListing>ul>li:even").addClass('sfCateven');
            $("#sfProductListing>ul>li:odd").addClass('sfCatodd');
            $(".cssClassProductReadMore").bind("click", function(e) {
                e.preventDefault();
                var productID = parseInt($(this).attr("id").replace(/[^0-9]/gi, ''));
                divVisibility(false, true);
                GetProductDetails(productID);

            });

        }


        function GetProductDetails(productID) {
            $.ajax({
                type: "POST",
                async: false,
                url: ProductSercviceurl + "GetProductInfoByProductID",
                data: JSON2.stringify({ productID: productID, userModuleID: UserModuleId,
                    portalID: PortalId
                }),
                contentType: "application/json;charset=utf-8",
                dataType: "json",
                success: function(data) {
                    $("#sfProductDescription .sfDetails").html('');
                    $("#sfProductDescription .sfDetailInformation").html('');
                    var bodyElements = '';
                    var value = eval(data.d);
                    if (value.ImagePath == "") {
                        value.ImagePath = UserSettingData.ProductNoImage;
                    }
                    else {
                        value.ImagePath = value.ImagePath.replace('small', 'large');
                    }
                    if (value.AlternateText == "") {
                        value.AlternateText = value.Name;
                    }
                    $("#title").html(value.Name);
                    bodyElements += '<div id="sfDecimg"><img class="sfMain" src="' + value.ImagePath + '" alt="' + value.AlternateText + '" width="370px" height="200px"/>';
                    bodyElements += '</div>';
                  if (UserSettingData.ShowProductPrice == "true") {
                        bodyElements += '<p class="sfPrice"><label>Price: </label> $' + value.Price + '</p>';
                    }

                    $("#sfProductDescription .sfDetails").html(bodyElements);
                    bodyElements = '';
                    bodyElements += '<h2>Summary</h2>';
                    bodyElements += '' + Encoder.htmlDecode(value.ShortDescription) + '';
                    bodyElements += '<h2> Description</h2>';
                    bodyElements += '' + Encoder.htmlDecode(value.FullDescription) + '';

                    $("#sfProductDescription .sfDetailInformation").html(bodyElements);


                },
                error: function() {
                    //alert('error productdetails');
                }
            });
        }

        function divVisibility(Productlist, ProductDetail) {
            if (Productlist) {
                $('.cssClassMarketPlaceFrontProductListing').show();
                $('.cssClassMarketPlaceFrontProductDetails').hide();

            }
            else {
                $('.cssClassMarketPlaceFrontProductListing').hide();
                $('.cssClassMarketPlaceFrontProductDetails').show();
            }
        }
        function fnBackButtonClick() {
            $('.cssClassMarketPlaceFrontProductListing').show();
            $('.cssClassMarketPlaceFrontProductDetails').hide();
        }

        $("#ddlCategory").live("change", function() {
            var Categoryid = $(this).val();
            GetProductListFront(Categoryid, pagingOptions.current, pagingOptions.pageSize);
        });