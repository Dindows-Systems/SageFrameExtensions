﻿var pagingOptions = {
    current: 1,
    pageSize: 5
};
var theOptions = {
    question: "Are You Sure ?",
    yesAnswer: "Yes",
    cancelAnswer: "Cancel"
};
var ModuleAttribute = {

    Category: 'category',
    Product: 'product'

};
var AdminDefaultData = {
    ProductNoImage: 'Modules/ProductDetails/Images/NoDrugImg.png'
};
$(function() {
    divVisibility(true, false);
    divToggle(ModuleAttribute.Category, true, false);

    GetCategoryList(pagingOptions.current, pagingOptions.pageSize);
    ImageUploaderProduct();

});

$('a img[name="Add"],a>span[name="Add"]').live("click", function(e) {
    e.preventDefault();
    var imgType = $(this).attr("type");
    if (imgType == ModuleAttribute.Category) {
        $("#hdnCategoryID").val('0');
		CategoryFormClear();
        divToggle(ModuleAttribute.Category, false, true);
    }
    else if (imgType == ModuleAttribute.Product) {
    $("#hdnProductID").val('0');
	ProductFormClear();
        GetAllCategory();
        divToggle(ModuleAttribute.Product, false, true);
    }



});
$('a img[name="Save"],a>span[name="Save"]').live("click", function(e) {
    e.preventDefault();

    var imgType = $(this).attr("type");
    if (imgType == 'category') {
        SaveCategory();

        // return false;
    }
    if (imgType == ModuleAttribute.Product) {
        SaveProduct();
    }
});


$('a img[name="Cancel"],a>span[name="Cancel"]').live("click", function(e) {
    e.preventDefault();
    var imgType = $(this).attr("type");
    if (imgType == ModuleAttribute.Category) {
        $("#hdnCategoryID").val('0');
        divToggle(ModuleAttribute.Category, true, false);
    }
    if (imgType == ModuleAttribute.Product) {
        $("#hdnProductID").val('0');
        divToggle(ModuleAttribute.Product, true, false);
    }

});


function GetAllCategory() {
    $.ajax({
        type: "POST",
        url: ProductServiceURL + "GetAllCategory",
        data: JSON2.stringify({ userModuleID: ProductUserModuleID, portalID: ProductPortalID }),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function(data) {
            var lstCategoryElements = '';
            if (data.d.length > 0) {
                $.each(data.d, function(index, value) {
                    lstCategoryElements += '<option value=' + value.CategoryID + '>' + value.Name + '</option>';
                });
                $("#lstCategory").html(lstCategoryElements);
            }
        },
        error: function() {
            alert('error in getting category');
        }
    });
}
function SaveCategory() {
    var categoryID = $("#hdnCategoryID").val();
    var categoryName = $.trim($('#txtCategoryName').val());
    // $("#txtCategoryDescription").val(Encoder.htmlEncode(editorList[3].Editor.getData()));
    var categoryDescription = $("#txtCategoryDescription").val();
    var isActive = $("#chkCategoryActive").attr("checked");
    var params = { categoryID: categoryID, name: categoryName, description: categoryDescription
        , isActive: isActive, userModuleID: ProductUserModuleID, portalID: ProductPortalID
    };
    // alert(params);
    var myData = JSON2.stringify(params);

    $.ajax({
        type: "POST",
        url: ProductServiceURL + "SaveCategory",
        data: myData,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function() {
            GetCategoryList(pagingOptions.current, pagingOptions.pageSize);
            divToggle(ModuleAttribute.Category, true, false);
            SageFrame.messaging.show(" Category saved successfully", "Success");
        },
        error: function() {
            alert('error');

        }

    });


}

function SaveProduct() {

    var catIDs = '';
    var productID = $("#hdnProductID").val();
    var name = $("#txtProductName").val();
    var price = $.trim($("#txtProductPrice").val());
    if (price <= 0) {
        alert("Price must be greater than zero");
        return false;
    }
    var shortDescription = $("#txtProductShortDescription").val();
    var fullDescription = $("#txtProductFullDescription").val();
    var imagePath = '';
    if ($("#divProductIcon").html().length > 0) {
        imagePath = $("#divProductIcon").find('img').attr("src").replace(resolvedURL, '');
    }
    var size = 0;
    var fileNameSize = '';
    var fileName = '';
    var alternateText = $("#txtProductAlternateText").val();

    var lstCategory = $("#lstCategory>option");
    $.each(lstCategory, function() {
        if ($(this).attr("selected")) {
            catIDs += $(this).attr("value") + ',';
        }
    });
    if (catIDs.length > 0) {
        catIDs = catIDs.substring(0, catIDs.length - 1);
    }
    else {
        alert("Choose at least one category !!");
        return false;
    }
    //                    alert(catIDs);
    var isActive = $("#chkProductActive").attr("checked");
    var displayOrder = $("#txtProductDisplayOrder").val();

    //return false;
    var myData = JSON2.stringify({ productID: productID, name: name, price: price, shortDescription: shortDescription, fullDescription: fullDescription,
        imagePath: imagePath, alt: alternateText, categoryIDs: catIDs, isActive: isActive,
        userModuleID: ProductUserModuleID, portalID: ProductPortalID
    });
    //return false;
    $.ajax({
        type: "POST",
        url: ProductServiceURL + "SaveUpdateProduct",
        data: myData,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function() {
            GetProductList(pagingOptions.current, pagingOptions.pageSize);
            divToggle(ModuleAttribute.Product, true, false);
            SageFrame.messaging.show(" Item saved successfully", "Success");
        },
        error: function() {
            alert('error');

        }

    });


}

//product list
function GetProductList(current, pageSize) {
    var myData = JSON2.stringify({ current: current, pageSize: pageSize, userModuleID: ProductUserModuleID,
        portalID: ProductPortalID
    });
    $.ajax({
        type: "POST",
        async: false,
        url: ProductServiceURL + "GetProductList",
        data: myData,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function(data) {
            var rowTotal = 0;
            var pageElements = '';
            //var arrPageNo = new Array();
            $("#contentProduct").html('');
            var headElements = '';
            var bodyElements = '';
            if (data.d.length > 0) {
                headElements += '<table cellspacing="0" cellpadding="0" border="0" width="100%"><thead class="cssClassHeadingOne"><th>Name</th><th>Categoryname</th><th>Price</th><th>IsActive</th> <th class="cssClassColumnEdit"></th><th class="cssClassColumnDelete"></th></thead></table>';
                $("#contentProduct").html(headElements);
                $.each(data.d, function(index, value) {
                    rowTotal = value.RowTotal;
                    bodyElements += '<tr><td>' + value.Name + '</td><td>' + value.CategoryName + '</td><td>' + value.Price + '</td><td>' + value.IsActive + '</td><td><a href="#" id="EditProduct_' + value.ProductID + '" class="cssClassEditProduct"><img src="' + resolvedURL + 'Administrator/Templates/default/images/btnedit.png" alt="Edit" /></a></td><td><a href="#" id="DeleteProduct_' + value.ProductID + '" class="cssClassDeleteProduct"><img src="' + resolvedURL + 'Administrator/Templates/default/images/btndelete_.png" alt="Delete" /></a></td></tr>';
                });
                $("#contentProduct>table").append(bodyElements);

                var totalPage = Math.ceil(rowTotal / pageSize);
                var isCurrenExist = false;
                pageElements += '<div id="divPageNo" class="pageNo">';

                for (var i = 1; i <= totalPage; i++) {
                    if (i == current) {
                        isCurrenExist = true;
                        pageElements += '<a href="#"><span class="current">' + i + '</span></a>';
                    }
                    else {
                        pageElements += '<a href="#"><span>' + i + '</span></a>';
                    }
                }

                pageElements += '</div>';
                pageElements += '<div class="PageSize"><select id="ddlPageSize" class="cssClassDropDown">';
                pageElements += '<option value="5">5</option><option value="10">10</option><option value="25">25</option><option value="40">40</option>';
                pageElements += '</select></div>';
                $("#contentProduct").append(pageElements);
                $("#ddlPageSize>option[value='" + pageSize + "']").attr("selected", "selected");
                if (!isCurrenExist) {
                    $("#divPageNo").find('a:last').find('span').addClass('current');
                }
                $("#divPageNo>a").bind("click", function(e) {
                    var obj = $(this);
                    e.preventDefault();
                    $("#divPageNo>a span").removeAttr('class');
                    var curr = parseInt($(this).find('span').html());

                    var pageSize = $("#ddlPageSize").val();
                    GetProductList(curr, pageSize);
                });
                $("#divPageNo>a span[class='current']").parent('a').unbind("click").attr("disabled", "disabled");
                $("#ddlPageSize").bind("change", function() {
                    var curr = pagingOptions.current;
                    var pageSize = $(this).val();
                    GetProductList(curr, pageSize);
                });

            }
            else {
                bodyElements = 'no products found';
                $("#contentProduct").html(bodyElements);
            }

            $(".cssClassEditProduct").bind("click", function(e) {
                e.preventDefault();
                var productID = parseInt($(this).attr("id").replace(/[^0-9]/gi, ''));
                var myData = JSON2.stringify({ productID: productID, userModuleID: ProductUserModuleID, portalID: ProductPortalID });
                $.ajax({
                    type: "POST",
                    async: false,
                    url: ProductServiceURL + "GetProductInfoByProductID",
                    data: myData,
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: function(data) {
                        $(".cssClassGeneralInfoAdmin").html('');
                        var value = eval(data.d);
                        $("#hdnProductID").val(value.ProductID);
                        $("#txtProductName").val(value.Name);
                        $("#txtProductPrice").val(value.Price);
                        if (value.ImagePath == "") {

                            value.ImagePath = AdminDefaultData.ProductNoImage;
                        }
                        if (value.AlternateText == "") {
                            value.AlternateText = value.Name;
                        }
                        $("#divProductIcon").html('<img src="' + resolvedURL + value.ImagePath + '" alt="' + value.AlternateText + '"  height="90px" width="100px"/>');
                        $("#txtProductAlternateText").val(value.AlternateText);
                        $('#txtProductShortDescription').val(value.ShortDescription);
                        $('#txtProductFullDescription').val(value.FullDescription);
                        $("#chkProductActive").attr("checked", value.IsActive);

                        $(".cssClassUserInformation").html('you are now updating product');
                        GetAllCategory();
                        GetCategoryOfProduct(productID);
                        divToggle(ModuleAttribute.Product, false, true);
                    },
                    error: function() {
                        alert('error product edit');
                    }
                });


            });
        },
        error: function() {
            alert('error on edit product');
        }
    });
    $(".cssClassDeleteProduct").bind("click", function(e) {
        e.preventDefault();
        var productID = parseInt($(this).attr("id").replace(/[^0-9]/gi, ''));
        if ($(this).next('.question').length <= 0)
            $(this).after('<div class="question">' + theOptions.question + '<br/> <span class="yes">' + theOptions.yesAnswer + '</span><span class="cancel">' + theOptions.cancelAnswer + '</span></div>');

        $(this).next('.question').animate({ opacity: 1 }, 300);
        $('.yes').bind('click', function() {

            $.ajax({
                type: "POST",
                async: false,
                url: ProductServiceURL + "DeleteProduct",
                data: JSON2.stringify({ productID: productID, userModuleID: ProductUserModuleID, portalID: ProductPortalID }),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function(data) {
                    var curr = $("#divPageNo a>span[class='current']").html();
                    var pageSize = $("#ddlPageSize").val();
                    GetProductList(pagingOptions.current, pagingOptions.pageSize);
                    SageFrame.messaging.show(" Item Deleted successfully", "Success");
                },
                error: function() {
                    alert('error on delete product');
                }
            });
        });

        $('.cancel').bind('click', function() {
            $(this).parents('.question').fadeOut(300, function() {
                $(this).remove();
            });
        });

    });

}



function GetCategoryList(current, pageSize) {
    var mydata = JSON2.stringify({ current: current, pageSize: pageSize, userModuleID: ProductUserModuleID, portalID: ProductPortalID });
    $.ajax({
        type: "POST",
        async: false,
        url: ProductServiceURL + "GetCategoryDetails",
        data: mydata,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function(data) {
            $("#contentCategory").html('');
            var pageElements = '';
            var rowTotal = 0;
            var totalPage = 0;
            var headElements = '';
            var catElements = '';
            if (data.d.length > 0) {
                headElements += '<table cellspacing="0" cellpadding="0" border="0" width="100%"><thead class="sfHeading">';
                headElements += '<th>Name</th><th>IsActive</th><th>AddedOn</th><th class="cssClassColumnEdit"></th><th class="cssClassColumnDelete"></th></thead>';
                headElements += '</table>';
                $("#contentCategory").html(headElements);
                $.each(data.d, function(index, value) {
                    rowTotal = value.RowTotal;
                    catElements += '<tr><td><label>' + value.Name + '<label></td><td>' + value.IsActive + ' </td><td>  ' + value.AddedOn + ' </td><td>  <a href="#" class="cssClassEditCategory" id=EditCategory_"' + value.CategoryID + '"><img src="' + resolvedURL + 'Administrator/Templates/default/images/btnedit.png" alt="Edit" /></a></td><td><a href="#" class="cssClassDeleteCategory" id=DeleteCategory_"' + value.CategoryID + '"><img src="' + resolvedURL + 'Administrator/Templates/default/images/btndelete_.png" alt="Delete" /></a></td></tr>';

                });
                $("#contentCategory>table").append(catElements);

                //////////////////////////////////////////////////////////////////

                var totalPage = Math.ceil(rowTotal / pageSize);
                var isCurrenExist = false;
                pageElements += '<div id="divCatPageNo" class="pageNo">';
                //                                if (current > 1) {
                //                                    pageElements += '<a href="#"><span>Prev</span></a>';
                //                                }
                for (var i = 1; i <= totalPage; i++) {
                    if (i == current) {
                        isCurrenExist = true;
                        pageElements += '<a href="#"><span class="current">' + i + '</span></a>';
                    }
                    else {
                        pageElements += '<a href="#"><span>' + i + '</span></a>';
                    }
                }
                //                                if (current < totalPage) {
                //                                    pageElements += '<a href="#"><span>Next</span></a>';
                //                                }
                pageElements += '</div>';
                pageElements += '<div class="PageSize"><select id="ddlCatPageSize" class="cssClassDropDown">';
                pageElements += '<option value="5">5</option><option value="10">10</option><option value="25">25</option><option value="40">40</option>';
                pageElements += '</select></div>';
                $("#contentCategory").append(pageElements);
                ////////////////////////////////////////////
                $("#ddlCatPageSize>option[value='" + pageSize + "']").attr("selected", "selected");
                if (!isCurrenExist) {
                    $("#divCatPageNo").find('a:last').find('span').addClass('current');
                }

                $("#ddlCatPageSize>option[value='" + pageSize + "']").attr("selected", "selected");
                if (!isCurrenExist) {
                    $("#divCatPageNo").find('a:last').find('span').addClass('current');
                }
                $("#divCatPageNo>a").bind("click", function(e) {
                    var obj = $(this);
                    e.preventDefault();
                    $("#divCatPageNo>a span").removeAttr('class');
                    var curr = parseInt($(this).find('span').html());
                    var pageSize = $("#ddlCatPageSize").val();
                    GetCategoryList(curr, pageSize);
                });
                $("#divCatPageNo>a span[class='current']").parent('a').unbind("click").attr("disabled", "disabled");
                $("#ddlCatPageSize").bind("change", function() {
                    var curr = pagingOptions.current;
                    var pageSize = $(this).val();
                    GetCategoryList(curr, pageSize);
                });

                /////////////////////////////////////////////////////////////////
                // $('#contentCategory>table').tablePagination(options);


                $(".cssClassEditCategory").bind("click", function(e) {
                    e.preventDefault();
                    var categoryID = parseInt($(this).attr("id").replace(/[^0-9]/gi, ''));
                    $("#hdnCategoryID").val(categoryID);
                    var myData = JSON2.stringify({ categoryID: categoryID, userModuleID: ProductUserModuleID, portalID: ProductPortalID });
                    $.ajax({
                        type: "POST",
                        async: false,
                        url: ProductServiceURL + "GetCategoryInfoByCategoryID",
                        data: myData,
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: function(data) {
                            var value = eval(data.d);
                            $("#hdnCategoryID").val(value.CategoryID);
                            $('#txtCategoryName').val(value.Name);
                            $('#txtCategoryDescription').val(value.Description);

                            $("#chkCategoryActive").attr("checked", value.IsActive);
                            $(".cssClassUserInformation").html('you are now updating category');
                            divToggle(ModuleAttribute.Category, false, true);
                        },
                        error: function() {
                            alert('errorediting');
                        }

                    });
                });
                $(".cssClassDeleteCategory").bind("click", function(e) {
                    e.preventDefault();
                    var categorID = parseInt($(this).attr("id").replace(/[^0-9]/gi, ''));
                    var myData = JSON2.stringify({ categoryID: categorID,
                        userModuleID: ProductUserModuleID, portalID: ProductPortalID
                    });

                    if ($(this).next('.question').length <= 0)
                        $(this).after('<div class="question">' + theOptions.question + '<br/> <span class="yes">' + theOptions.yesAnswer + '</span><span class="cancel">' + theOptions.cancelAnswer + '</span></div>');

                    $(this).next('.question').animate({ opacity: 1 }, 300);

                    $('.yes').bind('click', function() {
                        $.ajax({
                            type: "POST",
                            async: false,
                            url: ProductServiceURL + "DeleteCategory",
                            data: myData,
                            contentType: "application/json; charset=utf-8",
                            dataType: "json",
                            success: function() {
                                GetCategoryList(pagingOptions.current, pagingOptions.pageSize);
                                SageFrame.messaging.show(" Category deleted successfully", "Success");
                            },
                            error: function() {
                                alert('errordelete');
                            }
                        });
                    });


                    $('.cancel').bind('click', function() {
                        $(this).parents('.question').fadeOut(300, function() {
                            $(this).remove();
                        });
                    });
                });
            }
            else {
                catElements = 'No Categories Found';
                $("#contentCategory").html(catElements);
            }

        },

        error: function() {
            alert('last error');
        }

    });
}


function divToggle(type, showList, showForm) {
    if (type == ModuleAttribute.Category) {
        divVisibility(true, false);
        if (showList) {
            $(".cssClassMarketPlaceCategoryAddForm").hide();
            $(".cssClassProductCategoryListing").show();

        }
        if (showForm) {
            $(".cssClassProductCategoryListing").hide();
            $(".cssClassMarketPlaceCategoryAddForm").show();
        }
    }
    if (type == ModuleAttribute.Product) {
        divVisibility(false, true);
        if (showList) {
            $(".cssClassMarketPlaceProductAddForm").hide();
            $(".cssClassMarketPlaceAdminProductListing").show();

        }
        if (showForm) {
            $(".cssClassMarketPlaceAdminProductListing").hide();
            $(".cssClassMarketPlaceProductAddForm").show();
        }
    }
}

function divVisibility(ShowAdminCategory, ShowAdminProduct) {

    if (ShowAdminCategory) {
        $(".cssClassMarketPlaceAdminCategory").show();
    }
    else {
        $(".cssClassMarketPlaceAdminCategory").hide();
    }
    if (ShowAdminProduct) {
        $(".cssClassMarketPlaceAdminProduct").show();
    }
    else {
        $(".cssClassMarketPlaceAdminProduct").hide();
    }
}

$('.cssClassMarketPlaceAdminPanel').find('a').live("click", function(event) {
    event.preventDefault();
    $(".question").remove();
    $('.cssClassMarketPlaceAdminPanel').find('a').removeClass('sfActive');
    $(this).addClass('sfActive');
    var tabName = $(this).attr("name");

    if (tabName == 'AdminCategoryTab') {
        divToggle(ModuleAttribute.Category, true, false);

        //MarketPlaceConfig.GetCategoryList();
    }
    else if (tabName == 'AdminProductTab') {
        //GetAllCategory();
        GetProductList(pagingOptions.current, pagingOptions.pageSize);

        divToggle(ModuleAttribute.Product, true, false);
    }

});
function ImageUploaderProduct() {
    var maxFileSizeProduct = 5000;
    var upload = new AjaxUpload($('#fluProductImage'), {
        action: handlerURL,
        name: 'myfile[]',
        multiple: false,
        data: {},
        autoSubmit: true,
        responseType: 'json',
        onChange: function(file, ext) {
            //alert('changed');
        },
        onSubmit: function(file, ext) {
            if (ext != "exe") {
                if (ext && /^(jpg|jpeg|jpe|gif|bmp|png|ico)$/i.test(ext)) {
                    this.setData({
                        'MaxFileSize': maxFileSizeProduct
                    });
                } else {
                    alert('Not a valid image! Please upload the valid image');
                    return false;
                }
            }
            else {
                alert('Not a valid image! Please upload the valid image');
                return false;
            }
        },
        onComplete: function(file, response) {
            var res = eval(response);
            if (res.Message != null && res.Status > 0) {
                AddNewImagesProduct(res);
                return false;
            }
            else {
                alert('error on upload');
                //csscody.error('<h1>Error Message</h1><p>' + res.Message + '</p>');
                return false;
            }
        }
    });
}
function AddNewImagesProduct(res) {
    $("#divProductIcon").html('<img src="' + resolvedURL + res.Message + '"  height="90px" width="100px"/>');
}


function GetCategoryOfProduct(ProductID) {
    $.ajax({
        type: "POST",
        url: ProductServiceURL + "GetCategoryByProductID",
        data: JSON2.stringify({ productID: ProductID, userModuleID: ProductUserModuleID, portalID: ProductPortalID }),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function(data) {
            $.each(data.d, function(index, value) {
                var lstCategory = $("#lstCategory>option[value='" + value.CategoryID + "']");
                lstCategory.attr("selected", "selected");

            });
        },
        error: function() {
            alert('error getcategoryproduct');
        }
    });
}
function CategoryFormClear() {
    $('#txtCategoryName').val('');
    $('#txtCategoryDescription').val('');

}

function ProductFormClear() {
    $("#txtProductName").val('');
    $("#txtProductPrice").val('');
    $("#divProductIcon").html('');
    $("#txtProductAlternateText").val('');
    $('#txtProductShortDescription').val('');
    $('#txtProductFullDescription').val('');


}
          