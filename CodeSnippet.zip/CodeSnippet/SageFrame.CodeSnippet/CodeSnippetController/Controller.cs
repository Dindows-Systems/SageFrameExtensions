﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SageFrame.CodeSnippet.CodeSnippetdataProvider;
using SageFrame.CodeSnippet.CodeSnippetEntities;
namespace SageFrame.CodeSnippet.CodeSnippetController
{
    public class Controller
    {
        public void ModifyCode(CodeSnippetInfo objCode)
        {
            DataProvider objDataProvider = new DataProvider();
            objDataProvider.ModifyCode(objCode);
        }
        public List<CodeSnippetInfo> GetSnippetList(CodeSnippetInfo objCode)
        {
            DataProvider objDataProvider = new DataProvider();
            return objDataProvider.GetSnippetList(objCode);
        }

        public List<CodeSnippetInfo> GetAllSnippetList()
        {
            DataProvider objDataProvider = new DataProvider();
            return objDataProvider.GetAllSnippetList();
        }
        public CodeSnippetInfo GetCount(CodeSnippetInfo objCode)
        {
            DataProvider objDataProvider = new DataProvider();
            return objDataProvider.GetCount(objCode);
        }
        public void DeleteCode(int codeID)
        {
            DataProvider objDataProvider = new DataProvider();
            objDataProvider.DeleteCode(codeID);
        }
    }
}
