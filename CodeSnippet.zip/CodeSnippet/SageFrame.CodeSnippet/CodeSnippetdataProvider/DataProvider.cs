﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SageFrame.Web;
using SageFrame.CodeSnippet.CodeSnippetEntities;
using SageFrame.Web.Utilities;
namespace SageFrame.CodeSnippet.CodeSnippetdataProvider
{
    public class DataProvider
    {
        public void ModifyCode(CodeSnippetInfo objCodeSnippet)
        {
            SQLHandler sagesql = new SQLHandler();
            try
            {
                List<KeyValuePair<string, object>> ParamCollection = new List<KeyValuePair<string, object>>();
                ParamCollection.Add(new KeyValuePair<string, object>("@codeID", objCodeSnippet.CodeID));
                ParamCollection.Add(new KeyValuePair<string, object>("@code", objCodeSnippet.Code));
                ParamCollection.Add(new KeyValuePair<string, object>("@comment", objCodeSnippet.Comment));
                ParamCollection.Add(new KeyValuePair<string, object>("@tag", objCodeSnippet.Tag));
                ParamCollection.Add(new KeyValuePair<string, object>("@tittle", objCodeSnippet.Tittle));
                ParamCollection.Add(new KeyValuePair<string, object>("@userName", objCodeSnippet.userName));
                ParamCollection.Add(new KeyValuePair<string, object>("@userModuleID", objCodeSnippet.UserModuleID));
                ParamCollection.Add(new KeyValuePair<string, object>("@portalID", objCodeSnippet.PortalID));
                sagesql.ExecuteNonQuery("dbo.usp_CodeSnippetModify", ParamCollection);
            }
            catch (Exception)
            {

                throw;
            }
        }
        public List<CodeSnippetInfo> GetSnippetList(CodeSnippetInfo objCodeSnippet)
        {
            List<CodeSnippetInfo> objSnippetList = new List<CodeSnippetInfo>();
            List<KeyValuePair<string, object>> ParaMeterCollection = new List<KeyValuePair<string, object>>();
            ParaMeterCollection.Add(new KeyValuePair<string, object>("@userModuleID", objCodeSnippet.UserModuleID));
            ParaMeterCollection.Add(new KeyValuePair<string, object>("@portalID", objCodeSnippet.PortalID));
            ParaMeterCollection.Add(new KeyValuePair<string, object>("@codeID", objCodeSnippet.CodeID));
            ParaMeterCollection.Add(new KeyValuePair<string, object>("@tag", objCodeSnippet.Tag));
            ParaMeterCollection.Add(new KeyValuePair<string, object>("@pageno", objCodeSnippet.PageNo));
            ParaMeterCollection.Add(new KeyValuePair<string, object>("@range", objCodeSnippet.Range));
            List<CodeSnippetInfo> objListStory = new List<CodeSnippetInfo>();
            SQLHandler sagesql = new SQLHandler();
            try
            {
                objSnippetList = sagesql.ExecuteAsList<CodeSnippetInfo>("dbo.usp_CodeSnippetGetList", ParaMeterCollection);
            }
            catch (Exception e)
            {
                throw e;
            }
            return objSnippetList;
        }

        public List<CodeSnippetInfo> GetAllSnippetList()
        {
            try
            {
                SQLHandler sagesql = new SQLHandler();
                return sagesql.ExecuteAsList<CodeSnippetInfo>("[dbo].[usp_CodeSnippetGetAllList]");
            }
            catch (Exception)
            {

                throw;
            }

        }
        public CodeSnippetInfo GetCount(CodeSnippetInfo objCode)
        {
            CodeSnippetInfo objSnippet = new CodeSnippetInfo();
            List<KeyValuePair<string, object>> ParaMeterCollection = new List<KeyValuePair<string, object>>();
            ParaMeterCollection.Add(new KeyValuePair<string, object>("@userModuleID", objCode.UserModuleID));
            ParaMeterCollection.Add(new KeyValuePair<string, object>("@portalID", objCode.PortalID));
            ParaMeterCollection.Add(new KeyValuePair<string, object>("@tag", objCode.Tag));
            List<CodeSnippetInfo> objListStory = new List<CodeSnippetInfo>();
            SQLHandler sagesql = new SQLHandler();
            try
            {
                objSnippet = sagesql.ExecuteAsObject<CodeSnippetInfo>("dbo.usp_CodeSnippetCount", ParaMeterCollection);
            }
            catch (Exception e)
            {
                throw e;
            }
            return objSnippet;
        }
        public void DeleteCode(int codeID)
        {
            SQLHandler sagesql = new SQLHandler();
            try
            {
                List<KeyValuePair<string, object>> ParamCollection = new List<KeyValuePair<string, object>>();
                ParamCollection.Add(new KeyValuePair<string, object>("@codeID", codeID));
                sagesql.ExecuteNonQuery("dbo.usp_CodeSnippetDelete", ParamCollection);
            }
            catch (Exception)
            {

                throw;
            }
        }

    }
}
