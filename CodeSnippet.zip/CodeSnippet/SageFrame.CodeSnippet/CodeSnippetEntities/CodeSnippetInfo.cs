﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SageFrame.CodeSnippet.CodeSnippetEntities
{
    public class CodeSnippetInfo
    {
        public int CodeID { get; set; }
        public string Code { get; set; }
        public string Tittle { get; set; }
        public string Tag { get; set; }
        public int Count { get; set; }
        public int Range { get; set; }
        public int PageNo { get; set; }
        public string Comment { get; set; }
        public int UserModuleID { get; set; }
        public int PortalID { get; set; }
        public DateTime PostDate { get; set; }
        public string Date
        {
            get
            {
                return PostDate.ToShortDateString();
            }
        }
        public string userName { get; set; }
        public CodeSnippetInfo() { }
    }
}
