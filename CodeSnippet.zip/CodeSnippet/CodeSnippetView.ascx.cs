﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.Security;

public partial class Modules_CodeSnippets_CodeSnippetView : BaseAdministrationUserControl
{
    public string modulePath;
    public string UserName;
    public int UserModuleID, PortalID;
    public bool CheckRoles=false;
    protected void Page_Load(object sender, EventArgs e)
    {
        modulePath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "globalVariables", " var WorkLogPath='" + ResolveUrl(modulePath) + "';", true);
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "globalVariables1", " var SageFrameUserName='" + GetUsername + "';", true);
        PortalID = GetPortalID;
        UserName = GetUsername;
        UserModuleID = Int32.Parse(SageUserModuleID);
        IncludeCss("CodeSnippetcss", "/Modules/CodeSnippet/css/CodeSnippet.css");
        IncludeJs("CodeSnippetjs", "/Modules/CodeSnippet/js/CodeSnippet.js", "/Modules/CodeSnippet/js/Code.js");
        CheckRole();
        
    }
    public void CheckRole()
    {
        RoleController _role = new RoleController();
        string[] roles = _role.GetRoleNames(GetUsername, GetPortalID).ToLower().Split(',');
        if (roles.Contains(SystemSetting.SUPER_ROLE[0].ToLower()) || roles.Contains(SystemSetting.SITEADMIN.ToLower()))
        {
            CheckRoles =true;
           
        }
        else
            CheckRoles = false;
    }
}
