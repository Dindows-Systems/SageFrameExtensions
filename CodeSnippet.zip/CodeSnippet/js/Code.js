﻿
(function($)
{
    $.Code = function(Setting)
    {
	var fetchOnce=0;
	var totalPage =0;
        var Options = $.extend({
            portalID: 1,
            userModuleID: 1,
            userID: 1,
            Range: 5,
            userName: '',
            CheckRoles: false
        }, Setting);
        HightLightCode = {
            config: {
                isPostBack: false,
                async: false,
                cache: false,
                type: 'POST',
                contentType: "application/json; charset=utf-8",
                data: '{}',
                dataType: 'json',
                baseURL: WorkLogPath + "Services/CodeSnippetService.asmx/",
                method: "",
                url: "",
                ajaxCallMode: 0
            },
            ajaxSuccess: function(msg)
            {
                switch (HightLightCode.config.ajaxCallMode) {
                    case 1:
                        break;
                    case 2:
                        var html = '';
                        html += '<ul>';
                        $.each(msg.d, function(index, data)
                        {
			    fetchOnce = index;
                            var link = '';
                            if (SageFrameUserName == "superuser") {
                                link = '<li><a class="Link" name="' + data.CodeID + '">' + data.Tittle + '</a><span class="deleteLink">X<span></li>';
                            }
                            else {
                                link = '<li><a class="Link" name="' + data.CodeID + '">' + data.Tittle + '</a></li>';
                            }
                            html += link;
                        });
                        html += '</ul>';
                        $('#divData').html(html);
			if( totalPage==1 && fetchOnce <=  Options.Range)
	                {
	                    $('.Paging').hide();
	                }
                        HightLightCode.OnListClick();
                        break;
                    case 3:
                        var language;
                        var language_shortcut;
                        $.each(msg.d, function(index, data)
                        {
                            $('#divSnippetLefta').hide();
                            $('#divSnippetLeftb').show();
                            $('#spanTittle').text(data.Tittle);
                            $('#preText2').text(data.Code);
                            $('#spanID').text(data.CodeID);
                            language = data.Tag;
                            $('#selectLanguageList option').each(function(index, data)
                            {
                                var t = $(this).val();
                                if ($(this).val().trim() == language.trim()) {
                                    language_shortcut = $(this).text();
                                }
                            });
                            $('#spanTag').text(language_shortcut);
                            $('#spanComment').text(data.Comment);
                        });
                        HightLightCode.CodeHighLight(language, "preText2");
                        break;
                    case 4:
                        TotalRow = msg.d.Count;			
                        HightLightCode.Paging(TotalRow, Options.Range);
                        break;
                    case 5:
                        HightLightCode.Count();
                        $('#divSnippetList').find('li a:first').trigger('click');
                        break;
                }
            },
            ajaxFailure: function(data) { alert('Not Ok!'); },
            ajaxCall: function(config)
            {
                $.ajax({
                    type: HightLightCode.config.type,
                    contentType: HightLightCode.config.contentType,
                    cache: HightLightCode.config.cache,
                    async: HightLightCode.config.async,
                    url: HightLightCode.config.url,
                    data: HightLightCode.config.data,
                    dataType: HightLightCode.config.dataType,
                    beforeSend: function()
                    {
                        $('#divAjaxLoading').show();
                    },
                    complete: function()
                    {
                        $('#divAjaxLoading').hide();
                    },
                    success: function(msg)
                    {
                        HightLightCode.ajaxSuccess(msg);
                    },
                    error: function(msg)
                    {
                        HightLightCode.ajaxFailure(msg);
                    }
                });
            },
            Paging: function(TotalRow, Range)
            {
                var number_Of_Page = 0;
                var remainder = TotalRow % Range;
                if (remainder > 0)
                    number_Of_Page = (TotalRow - remainder) / Range + 1;
                else
                    number_Of_Page = TotalRow / Range;
                var noOfPage = parseInt(number_Of_Page);
                var atOnce = 4;
                var limitPerShow = 8;
                var CurrentCase = 0;
                HightLightCode.PageList(CurrentCase, noOfPage, atOnce, limitPerShow, 0);
            },
            PageList: function(CurrentCase, noOfPage, atOnce, limitPerShow, CurrentValue)
            {
		totalPage = noOfPage;
                var p = '';
                if (noOfPage < limitPerShow) {
                    if (noOfPage < atOnce) {
                        for (var i = 0; i < noOfPage; i++) {
                            p += '<span class="Paging"> ' + (i + 1) + ' </span>';
                        }
                    }
                    else {
                        p += '<span id = "previous"> PREVIOUS </span>';
                        for (var i = 0; i < atOnce; i++) {
                            p += '<span class="Paging"> ' + (i + 1) + ' </span>';
                        }
                        p += '<span id = "next"> NEXT </span>';
                    }
                }
                else {
                    p += '<span id = "previous"> PREVIOUS </span>';
                    switch (CurrentCase) {
                        case 0:
                            for (var i = 0; i < atOnce; i++) {
                                p += '<span class="Paging"> ' + (i + 1) + ' </span>';
                            }
                            p += '<span class="gap">...</span>';
                            for (var i = 0; i < 2; i++) {
                                p += '<span class="Paging"> ' + (noOfPage - 1 + i) + ' </span>';
                            }
                            break;
                        case 1:
                            for (var i = 0; i < 2; i++) {
                                p += '<span class="Paging"> ' + (i + 1) + ' </span>';
                            }
                            p += '<span class="gap">...</span>';
                            for (var i = 0; i < atOnce; i++) {
                                p += '<span class="Paging"> ' + ((noOfPage - atOnce) + 1 + i) + ' </span>';
                            }
                            break;
                        default:
                            for (var i = 0; i < 2; i++) {
                                p += '<span class="Paging"> ' + (i + 1) + ' </span>';
                            }
                            p += '<span class="gap">...</span>';
                            var start = atOnce - 4;
                            var limit = noOfPage - start;
                            for (var i = start; i < limit; i++) {
                                p += '<span class="Paging"> ' + i + ' </span>';
                            }
                            p += '<span class="gap">...</span>';
                            for (var i = 0; i < 2; i++) {
                                p += '<span class="Paging"> ' + (noOfPage - 1 + i) + ' </span>';
                            }
                            break;
                    }
                    p += '<span id = "next"> NEXT </span>';
                }
                $('#divPaging').html(p);
                $('#next').die().live('click', function()
                {
                    var tempval;
                    var me;
                    $('.Paging').each(function(index, value)
                    {
                        if ($(this).hasClass('click')) {
                            me = $(this);
                            tempval = parseInt(me.text());
                        }
                    });
                    if (me.next().hasClass('gap')) {
                        if (CurrentCase == 0) {
                            if (tempval == atOnce) {
                                HightLightCode.PageList(tempval, noOfPage, atOnce, limitPerShow, (tempval + 1));
                            }
                        }
                        else if (CurrentCase == 1) { }
                        else {
                            if ((noOfPage - atOnce) < tempval) {
                                HightLightCode.PageList(1, noOfPage, atOnce, limitPerShow, (tempval + 1));
                            }
                            else {
                                $('.Paging').each(function(index, value)
                                {
                                    if (index == 0 || index == 1 || index == (noOfPage - 2) || index == (noOfPage - 2)) {
                                    }
                                    else {
                                        $(this).text(parseInt($(this).text()) + 1);
                                    }
                                });
                            }

                        }
                    }
                    else {
                        if (isNaN(me.next().text()) == false) {
                            me.next().addClass('click');
                            me.removeClass('click');
                            HightLightCode.GetSnippetList('First');
                        }
                    }
                });
                $('#previous').die().live('click', function()
                {
                    var tempval;
                    var me;
                    $('.Paging').each(function(index, value)
                    {
                        if ($(this).hasClass('click')) {
                            me = $(this);
                            tempval = parseInt(me.text());
                        }
                    });
                    if (me.prev().hasClass('gap')) {
                        if (CurrentCase == 1) {
                            if (tempval == (noOfPage - atOnce + 1)) {
                                HightLightCode.PageList(tempval, noOfPage, atOnce, limitPerShow, (tempval - 1));
                            }
                        }
                        else if (CurrentCase == 0) { }
                        else {
                            if ((atOnce + 1) > tempval) {
                                HightLightCode.PageList(0, noOfPage, atOnce, limitPerShow, (tempval - 1));
                            }
                            else {
                                $('.Paging').each(function(index, value)
                                {
                                    if (index == 0 || index == 1 || index == (noOfPage - 2) || index == (noOfPage - 2)) {
                                    }
                                    else {
                                        $(this).text(parseInt($(this).text()) - 1);
                                    }
                                });
                            }

                        }
                    }
                    else {
                        if (isNaN(me.prev().text()) == false) {
                            me.prev().addClass('click');
                            me.removeClass('click');
                            HightLightCode.GetSnippetList('First');
                        }
                    }
                });
                $('.Paging').die().live('click', function()
                {
                    if ($(this).attr('class') != "Paging click") {

                        var clickValue = parseInt($(this).text());
                        if (clickValue <= atOnce) {
                            HightLightCode.PageList(0, noOfPage, atOnce, limitPerShow, clickValue);
                        }
                        else if (clickValue > (noOfPage - atOnce) & clickValue <= noOfPage) {
                            HightLightCode.PageList(1, noOfPage, atOnce, limitPerShow, clickValue);
                        }
                        else {
                            $('.Paging').removeClass('click');
                            $(this).addClass('click');
                            HightLightCode.GetSnippetList('First');
                        }
                        $('#divSnippetList').find('li a:first').trigger('click');
                    }
                });
                $('.Paging').removeClass('click');
                if (CurrentCase == 0) {
                    if (CurrentValue == 0) {
                        $('.Paging:first').addClass('click');
                    }
                    else {
                        $('.Paging').each(function(index, value)
                        {
                            if (parseInt($(this).text()) == (CurrentValue)) {
                                $(this).addClass('click');
                            }
                        });
                    }
                }
                else if (CurrentCase == 1) {
                    $('.Paging').each(function(index, value)
                    {
                        if (parseInt($(this).text()) == CurrentValue) {
                            $(this).addClass('click');
                        }
                    });
                }
                else {
                    $('.Paging').each(function(index, value)
                    {
                        if (parseInt($(this).text()) == CurrentValue) {
                            $(this).addClass('click');
                        }
                    });
                }		
                HightLightCode.GetSnippetList('First');
            },
            OnListClick: function()
            {
                $('#divSnippetList li').click(function()
		{
		    $('#divSnippetList li').removeClass('active');
		    $(this).addClass('active');
                    var codeID = $(this).find("a.Link").attr('name');
                    HightLightCode.GetSnippetListByID(codeID);
                });
            },
            GetSnippetListByID: function(SnippetID)
            {
                if ($('#preText2').length > 0) {
                    $('#preText2').remove();
                }
                var pre = '<pre id="preText2">  </pre>';
                $('#divSnippetLeftb').append(pre);
                $('#spanTagBefore').before($('#preText2'));
                HightLightCode.config.ajaxCallMode = 3;
                HightLightCode.config.method = "GetSnippetList";
                HightLightCode.config.url = HightLightCode.config.baseURL + HightLightCode.config.method;
                HightLightCode.config.data = JSON2.stringify({
                    userModuleID: Options.userModuleID,
                    portalID: Options.portalID,
                    codeID: SnippetID,
                    language: "null",
                    codeID: SnippetID,
                    tag: 'null',
                    range: Options.Range,
                    pageNo: 0

                });
                HightLightCode.ajaxCall(HightLightCode.config);
            },
            GetSnippetList: function(click)
            {

                var tag = $('#selectLanguageList option:selected').val();
                var PageNo = 0;
                switch (click) {
                    case 'First':
                        $('.Paging').each(function(index, value)
                        {
                            if ($(this).hasClass('click')) {
                                PageNo = $(this).text();
                            }
                        });
                        break;
                    case 'last':
                        $('.Paging').removeClass('click');
                        $('.Paging').last().addClass('click');
                        PageNo = $('.Paging').last().text();
                        break;
                }
                HightLightCode.config.ajaxCallMode = 2;
                HightLightCode.config.method = "GetSnippetList";
                HightLightCode.config.url = HightLightCode.config.baseURL + HightLightCode.config.method;
                HightLightCode.config.data = JSON2.stringify({
                    userModuleID: Options.userModuleID,
                    portalID: Options.portalID,
                    tag: tag,
                    codeID: 0,
                    range: Options.Range,
                    pageNo: PageNo
                });
                HightLightCode.ajaxCall(HightLightCode.config);
            },

            GetSnippetID: function(name)
            {
                return decodeURI((RegExp(name + '=' + '(.+?)(&|$)').exec(location.search) || [, null])[1]);
            },
            CodeHighLight: function(language, preid)
            {
                $('pre#' + preid).snippet(language, {
                    style: "acid",
                    showNum: true,
                    transparent: false,
                    collapse: false,
                    menu: true,
                    showMsg: "Expand Code",
                    hideMsg: "Collapse Code",
                    clipboard: "",
                    startCollapsed: false,
                    startText: false,
                    box: "",
                    boxColor: "",
                    boxFill: ""
                });
            },
            Count: function()
            {
                HightLightCode.config.ajaxCallMode = 4;
                HightLightCode.config.method = "GetCount";
                HightLightCode.config.url = HightLightCode.config.baseURL + HightLightCode.config.method;
                HightLightCode.config.data = JSON2.stringify({
                    userModuleID: Options.userModuleID,
                    portalID: Options.portalID,
                    tag: $('#selectLanguageList option:selected').val()
                });
                HightLightCode.ajaxCall(HightLightCode.config);
            },
            CodeSnippet: function(language)
            {

                var language = ['C', 'C++', 'C#', 'HTML', 'FLEX', 'Java', 'Javascript', 'Javascript DOM', 'PERL', 'PHP', 'PYTHON', 'RUBY', 'SQL', 'XML'];
                var shortCutLanguage = ['C', 'cpp', 'csharp', 'html', 'flex', 'java', 'javascript', 'javascript_dom', 'perl', 'php', 'python', 'ruby', 'sql', 'xml'];
                var selectOption = '';
                $.each(language, function(index, data)
                {
                    selectOption += '  <option value="' + shortCutLanguage[index] + '">' + data + '</option>';
                });
                optionAll = '<option value="ALL">ALL</option>';
                $('#selectLanguageList').append(optionAll).append(selectOption);
                $('#selectLanguage').append(selectOption);
                HightLightCode.Count();
                //  HightLightCode.GetSnippetList('First');
                $('#selectLanguageList').unbind().bind('change', HightLightCode.Count);
                $('#btnSubmit').click(function()
                {
                    if (Options.userName != 'anonymoususer') {
                        var tittle = $('#txtTittle').val().trim();
                        var code = $('#txtAreaCode').val().trim();
                        var tag = $('#selectLanguage option:selected').val();
                        var comment = $('#txtComment').val();
                        var codeID = $('#spanID').text().trim();
                        HightLightCode.config.ajaxCallMode = 1;
                        HightLightCode.config.method = "ModifyCode";
                        HightLightCode.config.url = HightLightCode.config.baseURL + HightLightCode.config.method;
                        HightLightCode.config.data = JSON2.stringify({
                            userModuleID: Options.userModuleID,
                            portalID: Options.portalID,
                            userName: Options.userName,
                            tittle: tittle,
                            code: code,
                            codeID: codeID,
                            tag: tag,
                            comment: comment
                        });
                        HightLightCode.ajaxCall(HightLightCode.config);
                        $('#selectLanguageList option').each(function(index, data)
                        {
                            if ($(this).val() == tag.trim()) {
                                $('#selectLanguageList option').eq(index).attr('selected', 'selected');
                            }
                        });
                        HightLightCode.Count();
                        HightLightCode.GetSnippetList('last');
                        if (codeID == 0) {
                            $('#divSnippetList').find('li a:last').trigger('click');
                        }
                        else {
                            $('.Link').each(function()
                            {
                                if ($(this).attr('name') == codeID) {
                                    $(this).trigger('click');
                                }
                            });
                        }
                    }
                });
                $('#selectLanguageList').unbind().bind('change', function()
                {
                    HightLightCode.Count();
                    $('#divSnippetList').find('li a:first').trigger('click');
                });
                $('#aNew').click(function()
                {
                    $('#divSnippetLefta').show();
                    $('#divSnippetLeftb').hide();
                    $('#txtTittle').val('');
                    $('#txtAreaCode').val('');
                    $('#txtComment').val('');
                    $('#spanID').text('0');
                });
                $('#btnEdit').click(function()
                {
                    $('#divSnippetLefta').show();
                    $('#divSnippetLeftb').hide();
                    $('#txtTittle').val($('#spanTittle').text());

                    $('#txtComment').val($('#spanComment').text());
                    $('#selectLanguage option').each(function(index, data)
                    {
                        if ($(this).text() == $('#spanTag').text().trim()) {
                            $('#selectLanguage option').eq(index).attr('selected', 'selected');
                        }
                    });
                    var code = '';

                    $('#preText2 li').each(function(index, data)
                    {
                        code += $(this).text() + '\n';
                    });
                    $('#txtAreaCode').val(code);
                });
            },
            init: function()
            {
                var Author = SageFrameUserName; ;
                if (Author == 'anonymoususer') {
                    $('#btnSubmit').hide();
                }
                else {
                    $('#btnSubmit').show();
                    $('#aNew').show();
                }
                if (Options.CheckRoles == 'False') {
                    $('#btnEdit').hide();
                }
                else
                    $('#btnEdit').show();
                var SnippetID = "";
                HightLightCode.config.SnippetID = HightLightCode.GetSnippetID(SnippetID);
                if (HightLightCode.config.SnippetID == "null") {
                    HightLightCode.CodeSnippet();
                    $('#divSnippetList').find('li a:last').trigger('click');
                }
                else {
                    HightLightCode.CodeSnippet();
                    HightLightCode.GetSnippetListByID(HightLightCode.config.SnippetID);
                }
                $('.deleteLink').die().live('click', function()
                {
                    var codeID = $(this).prev().attr('name');
                    var isTrue = confirm('Do you want to delete ?');
                    if (isTrue) {
                        HightLightCode.config.ajaxCallMode = 5;
                        HightLightCode.config.method = "DeleteCode";
                        HightLightCode.config.url = HightLightCode.config.baseURL + HightLightCode.config.method;
                        HightLightCode.config.data = JSON2.stringify({
                            codeID: codeID
                        });
                        HightLightCode.ajaxCall(HightLightCode.config);
                    }
                });
            }
        };
        HightLightCode.init();
    };
    $.fn.CodeHighlight = function(Setting)
    {
        $.Code(Setting);
    };
} (jQuery));




    
