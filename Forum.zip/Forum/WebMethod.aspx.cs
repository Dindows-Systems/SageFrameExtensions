﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using System.IO;
using System.Web.Services;
using SageFrame.WebForum;


public partial class Modules_Forum_WebMethod : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }


    [WebMethod]
    public static string Result(ForumInfo objInfo)
    {
        return Results(objInfo);
    }
    [WebMethod]
    public static string Results(ForumInfo objInfo)
    {
        try
        {
            Page page = new Page();
            SageUserControl uC = (SageUserControl)page.LoadControl(objInfo.ControlName);

            page.Controls.Add(uC);

            StringWriter textWriter = new StringWriter();
            HttpContext.Current.Server.Execute(page, textWriter, false);
            return textWriter.ToString();
        }
        catch (Exception ex)
        {
            return ex.ToString();
        }
    }

}
