﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.WebForum;
using System.IO;
using SageFrame.Security;
using SageFrame.Security.Entities;

public partial class Modules_Forum_ForumEdit : BaseAdministrationUserControl
{
    string filePath = string.Empty;
    public string basePath = "";
    public string UserID = "";
    public string UserModuleID = "";
    List<ForumInfo> lstForum = new List<ForumInfo>();
    protected void Page_Load(object sender, EventArgs e)
    {
        InitializeJS();
        if (!IsPostBack)
        {
            BindData();
            AssignUrl();
            Session["usertypeUpdate"] = false;
            BindUserType();
            BindUserInfo();
        }
        string appPath = Request.ApplicationPath != "/" ? Request.ApplicationPath : "";
        basePath = ResolveUrl("~/Modules/Forum/");
        MembershipController member = new MembershipController();
        UserInfo user = member.GetUserDetails(GetPortalID, GetUsername.ToString());
        if (user.UserName != null)
        {
            UserID = user.UserID.ToString();

        }
        UserModuleID = SageUserModuleID;
    }
    public void AssignUrl()
    {
        imbAddCategory.ImageUrl = GetTemplateImageUrl("add.png", true);

    }
    private void InitializeJS()
    {
        Page.ClientScript.RegisterClientScriptInclude("json2", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/js/jquery-1.4.4.js"));
        Page.ClientScript.RegisterClientScriptInclude("json", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/js/json2.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryToolTipu", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery-ui-1.8.10.custom.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryAlert", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/alertbox.js"));

        IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/jquery-ui-all.css");
        IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/jquery-ui-1.7.2.custom.css");
        IncludeCss("Forummm", "/Modules/Forum/css/message.style.css");
        IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/popup.css");



    }
    protected void imbAddCategory_Click(object sender, EventArgs e)
    {
        if ((string)Session["update"] == "true")
        {
            string categoryID = txtIdHolder.Text;
            bool resultUpdate = false;
            if (txtCategoryName.Text != "" || txtCategoryName.Text != null)
            {
                resultUpdate = ForumDataProvider.UpdateDiscussionCategory(new ForumInfo(txtCategoryName.Text, int.Parse(categoryID)));
            }
            if (resultUpdate)
            {
                //messaging
                Session["update"] = string.Empty;
                BindData();
            }
            else
            {
                //messaging

            }

        }
        else
        {
            SageUserControl UserControl = new SageUserControl();
            string UserModuleID = SageUserModuleID;
            bool result = false;
            bool flag = true;
            if (txtCategoryName.Text != "")
            {
                List<ForumInfo> lst = ForumDataProvider.SelectDiscussionCategory(new ForumInfo(SageUserModuleID));
                int length = txtCategoryName.Text.Trim().Length;
                if (length > 0)
                {
                    string valueFirst = txtCategoryName.Text.Replace(" ", "");
                    foreach (ForumInfo attr in lst)
                    {

                        if (valueFirst.ToLower() == attr.CategoryName.Replace(" ", "").ToLower())
                        {

                            flag = false;

                        }
                        else
                        {

                        }

                    }
                    if (flag == true)
                    {
                        result = ForumDataProvider.AddDiscussionCategory(new ForumInfo(txtCategoryName.Text, UserModuleID));
                    }
                    else
                    {
                        ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/Forum/ModuleLocalText", "existCategory"), "", SageMessageType.Alert);

                    }
                }
                else
                {
                    ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/Forum/ModuleLocalText", "emptyField"), "", SageMessageType.Alert);

                }
            }
            else
            {
                ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/Forum/ModuleLocalText", "emptyField"), "", SageMessageType.Alert);

            }
            if (result)
            {
                BindData();
                //messaging
                ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/Forum/ModuleLocalText", "insertCategory"), "", SageMessageType.Success);
                txtCategoryName.Text = string.Empty;

            }
            else
            {
                //messaging
                //ShowMessage(SageMessageTitle.Information.ToString(), GetSageMessage("FeedBack", "insertCategory"), "", SageMessageType.Success);
            }
        }

    }
    protected void gdvCategory_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        switch (e.CommandName)
        {
            case "Select":

                int id = int.Parse(e.CommandArgument.ToString());
                List<ForumInfo> lst = ForumDataProvider.SelectDiscussionCategoryByID(new ForumInfo(id));
                foreach (ForumInfo objForum in lst)
                {
                    txtCategoryName.Text = objForum.CategoryName;
                    txtIdHolder.Text = objForum.CategoryID.ToString();
                }

                break;
            case "DeleteCategory":
                int catID = int.Parse(e.CommandArgument.ToString());
                string userModuleID = SageUserModuleID;
                bool result = ForumDataProvider.DeleteDiscussionCategory(new ForumInfo(userModuleID, catID));
                if (result)
                {

                    //messaging
                    BindData();
                    ShowMessage(SageMessageTitle.Information.ToString(), GetSageMessage("FeedBack", "SettingSavedSuccessfully"), "", SageMessageType.Success);

                }
                else
                {
                    //messaging

                }
                break;

        }
    }
    public void BindData()
    {
        List<ForumInfo> lst = ForumDataProvider.SelectDiscussionCategory(new ForumInfo(SageUserModuleID));
        gdvCategory.DataSource = lst;
        gdvCategory.DataBind();

    }
    protected void gdvCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["update"] = "true";

    }
    protected void ibmAddUserType_Click(object sender, EventArgs e)
    {
        if (!(bool)Session["usertypeUpdate"])
        {
            // bool result = ForumDataProvider.AddUserType(new ForumInfo(txtUserType.Text));
            //if (result)
            //{
            //    //messaging
            //    BindUserType();

            //}
            //else
            //{
            //    //messaging

            //}
        }
        else
        {
            //bool result=ForumDataProvider.UpdateUserType(new ForumInfo(txtUserType.Text,int.Parse(txtUserTypeIDHolder.Text)));
            //if (result)
            //    {
            //        //messaging
            //        BindUserType();   
            //        Session["usertypeUpdate"] = false;

            //    }
            //    else
            //    {
            //        //messaging

            //    }
        }
    }
    protected void gdvUserType_SelectedIndexChanged(object sender, EventArgs e)
    {

        //Session["usertypeUpdate"] = true;

    }
    protected void gdvUserType_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        //switch (e.CommandName)
        //{ 

        //    case "Select":
        //        int UserTypeID = int.Parse(e.CommandArgument.ToString());
        //        List<ForumInfo> lst = ForumDataProvider.SelectUserTypeByID(new ForumInfo(UserTypeID));
        //        foreach (ForumInfo att in lst)
        //        {
        //            txtUserType.Text = att.UserType;
        //            txtUserTypeIDHolder.Text = att.UserTypeID.ToString();
        //        }
        //        break;
        //    case "DeleteUserType":
        //        int TypeID = int.Parse(e.CommandArgument.ToString());
        //        bool result = false;
        //        result = ForumDataProvider.DeleteUserType(new ForumInfo(TypeID));
        //        if (result)
        //        {
        //            //messaging
        //            BindUserType();
        //        }
        //        else
        //        {
        //            //messaging

        //        }
        //        break;



        //}

    }
    public void BindUserType()
    {
        List<ForumInfo> lst = ForumDataProvider.SelectUserType();
        //gdvUserType.DataSource = lst;
        //gdvUserType.DataBind();

    }
    public void BindUserInfo()
    {
        lstForum = ForumDataProvider.SelectUserInfoForAdmin();
        gdvUserInfo.DataSource = lstForum;
        gdvUserInfo.DataBind();
        foreach (ForumInfo att in lstForum)
        {
            if (att.IsBlock)
            {

                foreach (GridViewRow row in gdvUserInfo.Rows)
                {
                    RadioButton btn = (RadioButton)row.FindControl("rbtnDisable");
                    btn.Checked = true;
                }

            }
            else
            {
                foreach (GridViewRow row in gdvUserInfo.Rows)
                {

                    RadioButton btn = (RadioButton)row.FindControl("rbtnEnable");
                    btn.Checked = true;

                }
            }
        }
    }
    protected void gdvUserInfo_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        switch (e.CommandName)
        {
            case "ChangeStatus":

                string UserID = e.CommandArgument.ToString();
                foreach (GridViewRow row in gdvUserInfo.Rows)
                {

                    RadioButton rbtnDisable = (RadioButton)row.FindControl("rbtnDisable");
                    RadioButton rbtnEnable = (RadioButton)row.FindControl("rbtnEnable");
                    if (rbtnDisable.Checked)
                    {

                        bool result = ForumDataProvider.MakeUserDisable(new ForumInfo(UserID));
                        if (result)
                        {
                            //messaging

                        }
                        else
                        {
                            //messaging

                        }

                    }
                    if (rbtnEnable.Checked)
                    {
                        bool result = ForumDataProvider.MakeUserEnable(new ForumInfo(UserID));
                        if (result)
                        {
                            //messaging

                        }
                        else
                        {
                            //messaging

                        }
                    }
                }
                break;
        }
    }
    public string UploadImage(string titleName, FileUpload FileUpload)
    {

        //FileUpload FileUpload = (FileUpload)(ph.FindControl(uploadFile));
        string FileNameWithExtension = string.Empty;
        if (FileUpload.HasFile)
        {
            //Constant variables
            string absPath = Request.PhysicalApplicationPath + "Modules\\Forum\\AvtImg\\";
            // string absPath =ResolveUrl( basePath + "AvtImg/");
            int FileSize = FileUpload.PostedFile.ContentLength; //Get th file lenght
            if (FileSize < 1)
            {
                return FileNameWithExtension;
            }
            else
            {
                string contentType = FileUpload.PostedFile.ContentType; // Get the file type
                string FileExist = absPath + FileUpload.PostedFile.FileName; // Get the filename from the directory and compare
                string FileName = titleName; //Use title as the file name. Username is unique so no problem with this.
                string FileExtention = Path.GetExtension(FileUpload.PostedFile.FileName); //Get the posted file extension
                string result = "false";
                //filePath = string.Concat(absPath, FileName, "", FileExtention);
                filePath = string.Concat(absPath, FileName, "", FileExtention);
                if (FileExtention.Equals(".bmp") || FileExtention.Equals(".BMP") ||
                             FileExtention.Equals(".gif") || FileExtention.Equals(".GIF") ||
                             FileExtention.Equals(".jpg") || FileExtention.Equals(".JPG") ||
                             FileExtention.Equals(".jpeg") || FileExtention.Equals(".JPEG") ||
                             FileExtention.Equals(".png") || FileExtention.Equals(".PNG"))
                {

                    result = "true"; ;


                }
                else
                {

                    ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/Forum/ModuleLocalText", "wrongfile"), "", SageMessageType.Error);

                }
                //Joined the filename and extension to insert into the database.

                if (result == "true")
                {
                    try
                    {
                        //Save file to the specified directory
                        FileUpload.SaveAs(filePath);
                        FileNameWithExtension = FileName + FileExtention;

                    }
                    catch (Exception ex)
                    {

                        ProcessException(ex);

                    }
                }

                else
                {
                    FileNameWithExtension = "false";
                }

                return FileNameWithExtension;
            }
        }

        else
        {
            ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/Forum/ModuleLocalText", "emptyField"), "", SageMessageType.Error);
            return FileNameWithExtension;
        }

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {

        double titleName = GetUniform();
        string fileName = CreateFileName(5);
        string Image = UploadImage(fileName, FileUpd);
        if (Image != "false" && Image != "")
        {
            bool result = ForumDataProvider.InsertImage(Image, new ForumInfo(SageUserModuleID));
            if (result)
            {
                ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/Forum/ModuleLocalText", "insertImage"), "", SageMessageType.Success);
            }
        }
    }
    private static uint GetUint()
    {
        uint m_z = 0;
        uint m_w = 0;
        m_z = 36969 * (m_z & 65535) + (m_z >> 16);
        m_w = 18000 * (m_w & 65535) + (m_w >> 16);
        return (m_z << 16) + m_w;
    }
    public static double GetUniform()
    {
        uint u = GetUint();
        return (u + 1.0) * 2.328306435454494e-10;
    }
    private static string CreateFileName(int Length)
    {
        string allowedChars = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ0123456789!@$?_-";
        char[] chars = new char[Length];
        Random rd = new Random();

        for (int i = 0; i < Length; i++)
        {
            chars[i] = allowedChars[rd.Next(0, allowedChars.Length)];
        }

        return new string(chars);
    }
    protected void gdvUserInfo_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvUserInfo.PageIndex = e.NewPageIndex;
        BindUserInfo();

    }

}


