﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.Security;
using SageFrame.Security.Entities;

public partial class Modules_Forum_TestForum : BaseAdministrationUserControl
{
   public string  UserModuleID = ""; //1;
    protected void Page_Init(object sender, EventArgs e)
    {

       
        try
       
        {
            MembershipController member = new MembershipController();
            UserInfo user = member.GetUserDetails(GetPortalID, GetUsername.ToString());
            if (user.UserName == null)
            {
                SageUserControl itemDetails = (SageUserControl)LoadControl("~/Modules/Forum/ForumControlView/GuestCategoryList.ascx");
                itemDetails.EnableViewState = true;
                itemDetails.SageUserModuleID = SageUserModuleID;
                phdetailBrowseholder.Controls.Add(itemDetails);
            }
            else
            {
                SageUserControl itemDetails = (SageUserControl)LoadControl("~/Modules/Forum/ForumControlView/ProfilePage.ascx");
                itemDetails.EnableViewState = true;
                itemDetails.SageUserModuleID = SageUserModuleID;
                phdetailBrowseholder.Controls.Add(itemDetails);
            }
            IncludeCss("FormBuilder", "/Modules/Forum/module.css", "/Modules/Forum/css/message.style.css");
            IncludeJs("FormBuilder", "/Modules/Forum/ForumControlView/js/session.js","/js/jquery.pagination.js", "/Modules/Forum/ForumControlView/js/alertbox.js");
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        } 
    }
    
    protected void Page_Load(object sender, EventArgs e)
    {
        InitializeJS();
        Session["UserModuleID"] = SageUserModuleID;
       
    }


    private void InitializeJS()
    {
        
        Page.ClientScript.RegisterClientScriptInclude("JQuery", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery.bgiframe"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryTool", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery.bxSlider.min.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryToolTip", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery.easing.1.3.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryToolTips", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery.bxSlider.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryToolTipg", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery.lightbox-0.5.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryToolTipu", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery-ui-1.8.10.custom.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryToolTipuz", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/syntax.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryToolTipuz", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/session.js"));
        IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/jquery-ui-all.css");
        IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/jquery-ui-1.7.2.custom.css");
        IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/syntax.css");
    }
               
}
