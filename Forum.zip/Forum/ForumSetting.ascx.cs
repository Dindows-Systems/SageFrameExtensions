﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.Security;
using SageFrame.Security.Entities;
using SageFrame.SageFrameClass;
using System.Text.RegularExpressions;

public partial class Modules_Forum_ForumSetting :BaseAdministrationUserControl
{
    public string UserName = "";
    public int PortalID = 0;
    public string UserModuleID = "";
    public string basePath = "";
    protected void Page_Load(object sender, EventArgs e)
    {


        string appPath = Request.ApplicationPath != "/" ? Request.ApplicationPath : "";
        basePath = ResolveUrl("~/Modules/Forum/");
        UserName = GetUsername;
        PortalID = GetPortalID;
        UserModuleID = SageUserModuleID;


    }
}
