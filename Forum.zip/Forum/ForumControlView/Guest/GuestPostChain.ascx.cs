﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.Security;
using SageFrame.Security.Entities;

public partial class Modules_Forum_ForumControlView_GuestPostChain : BaseAdministrationUserControl
{
    public string basePath = "";
    public string UserID = "";
    public string PreID = "";
    public string NextID = "";
    public string ModulePath = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        string appPath = Request.ApplicationPath != "/" ? Request.ApplicationPath : "";
        basePath = ResolveUrl("~/Modules/Forum/AvtImg/Thumbnails/small/");
        ModulePath = ResolveUrl("~/Modules/Forum/");
        MembershipController member = new MembershipController();
        UserInfo user = member.GetUserDetails(GetPortalID, GetUsername.ToString());
        if (user.UserName != null)
        {
            UserID = user.UserID.ToString();

        }
        else
        {
            UserID = "ed8d72d1-e880-4b2a-9b80-858acb6dbddd";
        }
        PreID = (string)Session["PreThreadID"];
        NextID=(string)Session["NextThreadID"];

    }
}