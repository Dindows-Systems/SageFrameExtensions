﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.Security;
using SageFrame.Security.Entities;

public partial class Modules_Forum_ForumControlView_EditPostChain : BaseAdministrationUserControl
{
     public string basePath = "";
     public string UserID = "";
     public string Flag = "";
    
     protected void Page_Load(object sender, EventArgs e)
    {
        string appPath = Request.ApplicationPath != "/" ? Request.ApplicationPath : "";
        basePath = ResolveUrl("~/Modules/Forum/");
        MembershipController member = new MembershipController();

        UserInfo user = member.GetUserDetails(GetPortalID, GetUsername.ToString());
        if (user.UserName != null)
        {
            UserID = user.UserID.ToString();

        }
        if ((string)Session["FlagMd"] != null)
        {
            Flag = (string)Session["FlagMd"];
        }
    }
}
