﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;

public partial class Modules_Forum_ForumControlView_ViewThank :BaseAdministrationUserControl
{
    public string basePath = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        InitializeJS();
        //lblDate.Text = DateTime.Now.ToString();
        string appPath = Request.ApplicationPath != "/" ? Request.ApplicationPath : "";
        basePath = ResolveUrl("~/Modules/Forum/");

    }
    private void InitializeJS()
    {

        //ArrayList jsArrColl = new ArrayList();
        //jsArrColl.Add(Request.ApplicationPath.ToString() + "/Modules/Forum/js/jquery-ui-1.8.10.custom.js");
        //jsArrColl.Add(Request.ApplicationPath.ToString() + "/Editors/ckeditor/adapters/jquery.js");
        //Page.ClientScript.RegisterClientScriptInclude("JQueryToolTip", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "js/jquery.tooltip.js"));
        IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/jquery-ui-1.7.2.custom.css");
        //IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/jquery.ui.all.css");

    }
}
