﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using System.Collections;
using SageFrame.Security;
using SageFrame.Security.Entities;
using SageFrame.WebForum;
using System.IO;

public partial class Modules_Forum_ForumControlView_ProfilePage : BaseAdministrationUserControl
{
    string filePath = string.Empty;
    public string basePath = "";
    public string UserID = "";
    public string UserModuleID = "";
    public string handlerURL, resolvedURL;
	public int PortalID = 0;

    List<ForumInfo> lstForum = new List<ForumInfo>();
   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            InitializeJS();
        }
       
        string appPath = Request.ApplicationPath != "/" ? Request.ApplicationPath : "";
        basePath = ResolveUrl("~/Modules/Forum/");       
        this.handlerURL = ResolveUrl(this.AppRelativeTemplateSourceDirectory) + "Handler/ForumImageHandler.ashx";
        MembershipController member = new MembershipController();
        UserInfo user = member.GetUserDetails(GetPortalID,GetUsername.ToString());
        if (user.UserName != null)
        {
            UserID = user.UserID.ToString();
            
        
        }
         PortalID = GetPortalID;

    }
    private void InitializeJS()
    {      

        IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/popup.css");
        IncludeJs("ForumUploadImage", false, "/Modules/Forum/ForumControlView/js/ajaxupload.js");

        ArrayList jsArrColl = new ArrayList();
        jsArrColl.Add(Request.ApplicationPath.ToString() + "/Editors/ckeditor/ckeditor.js");
        jsArrColl.Add(Request.ApplicationPath.ToString() + "/Editors/ckeditor/adapters/jquery.js");
        IncludeScriptFile(jsArrColl);
        
    }

   
}
