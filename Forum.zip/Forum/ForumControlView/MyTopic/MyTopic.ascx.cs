﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.Security;
using SageFrame.Security.Entities;

public partial class Modules_Forum_ForumControlView_MyTopic : BaseAdministrationUserControl
{
    public string basePath = "";
    public string UserID = "";
    protected string UserName = ""; 
    protected void Page_Load(object sender, EventArgs e)
    {
        InitializeJS();
        //lblDate.Text = DateTime.Now.ToString();
        string appPath = Request.ApplicationPath != "/" ? Request.ApplicationPath : "";
        basePath = ResolveUrl("~/Modules/Forum/");
        MembershipController member = new MembershipController();
        UserInfo user = member.GetUserDetails(GetPortalID, GetUsername.ToString());
        if (user.UserName != null)
        {
            UserID = user.UserID.ToString();
            UserName = user.UserID.ToString();

        }

    }
    private void InitializeJS()
    {

        //ArrayList jsArrColl = new ArrayList();
        //jsArrColl.Add(Request.ApplicationPath.ToString() + "/Modules/Forum/js/jquery-ui-1.8.10.custom.js");
        //jsArrColl.Add(Request.ApplicationPath.ToString() + "/Editors/ckeditor/adapters/jquery.js");
        //Page.ClientScript.RegisterClientScriptInclude("JQueryToolTip", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "js/jquery.tooltip.js"));
        IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/jquery-ui-1.7.2.custom.css");
       IncludeCssFile(AppRelativeTemplateSourceDirectory + "module.css");

    }
}

