﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using SageFrame.Web;
using SageFrame.Security;
using SageFrame.Security.Entities;
using SageFrame.Web.Utilities;
using System.Data.SqlClient;
using SageFrame.WebForum;

public partial class Modules_Forum_ForumControlView_CategoryList : BaseAdministrationUserControl
{
    public string basePath = "";
    public string UserID = "";
    public string UserModuleID ="";
    public int PortalID = 0;
    public string userName = "";
    public string UserRoleName = "";
    public string UserDesc = "";
    public bool IsModeratorUser;
  


    protected void Page_Load(object sender, EventArgs e)
    {
        string a = this.ID;
        InitializeJS();

        //lblDate.Text = DateTime.Now.ToString();
        string appPath = Request.ApplicationPath != "/" ? Request.ApplicationPath : "";
        basePath = ResolveUrl("~/Modules/Forum/");
        MembershipController member = new MembershipController();
        UserInfo user = member.GetUserDetails(GetPortalID, GetUsername.ToString());
        if (user.UserName != null)
        {
            UserID = user.UserID.ToString();
            userName = user.UserName;

        }
        //UserDesc=
        UserDesc = GetUsername.ToString();
        PortalID = GetPortalID;
        UserModuleID =SageUserModuleID;
       // Session["UsermoduleID"] = SageUserModuleID;
        UserID = user.UserID.ToString();
        RoleController _role = new RoleController();
        string[] roles = _role.GetRoleNames(GetUsername, GetPortalID).ToLower().Split(',');
        if (roles.Contains(SystemSetting.SUPER_ROLE[0].ToLower()))
        {
            UserRoleName = SystemSetting.SUPER_ROLE[0].ToLower();
        }
		 else if (roles.Contains(SystemSetting.SITEADMIN.ToString()))
        {
            UserRoleName = SystemSetting.SITEADMIN.ToString();
        }
        IsModeratorUser = CheckModerator();

    }

    //private void IncludeCss()
    //{
    //    IncludeCssFile(AppRelativeTemplateSourceDirectory + "module.css");

    //}
   private void InitializeJS()
    {
        IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/popup.css");
       IncludeCssFile(AppRelativeTemplateSourceDirectory + "module.css");
        ArrayList jsArrColl = new ArrayList();
        jsArrColl.Add(Request.ApplicationPath.ToString() + "/Editors/ckeditor/ckeditor.js");
        jsArrColl.Add(Request.ApplicationPath.ToString() + "/Editors/ckeditor/adapters/jquery.js");
        jsArrColl.Add(Request.ApplicationPath.ToString() + "/Modules/Forum/ForumControlView/js/ajaxupload.js");
        IncludeScriptFile(jsArrColl);
    }

    private bool CheckModerator()
    {
        bool flag = false;
        List<ForumInfo> lst = new List<ForumInfo>();
        lst = SelectRoleModerator(UserModuleID);

        foreach (ForumInfo user in lst) // Loop through all strings
        {
            int aIsModerator = String.Compare(userName, user.Username);
            if (aIsModerator == 0)
            {

                flag = true;
                break;
            }
            else
            {
                flag = false;
                // break;
            }
        }
        return flag;

    }


    public List<ForumInfo> SelectRoleModerator(string UserModuleID)
    {
        try
        {
            SageFrame.Web.Utilities.SQLHandler sagesql = new SageFrame.Web.Utilities.SQLHandler();
            List<KeyValuePair<string, object>> parameterColl = new List<KeyValuePair<string, object>>();
            parameterColl.Add(new KeyValuePair<string, object>("@UserModuleID", UserModuleID));
            List<ForumInfo> lst = sagesql.ExecuteAsList<ForumInfo>("[usp_ForumSelectModeratorUser]", parameterColl);
            return lst;
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    public static UserInfo GetUserRoles(string UserID)
    {
        string sp = "[dbo].[usp_ForumGetUserRoles]"; // new storeprocedures
        SQLHandler sagesql = new SQLHandler();

        List<KeyValuePair<string, object>> ParamCollInput = new List<KeyValuePair<string, object>>();
        ParamCollInput.Add(new KeyValuePair<string, object>("@UserID", UserID));


        List<UserInfo> lstUser = new List<UserInfo>();
        try
        {
            SqlDataReader reader;
            reader = sagesql.ExecuteAsDataReader(sp, ParamCollInput);
            while (reader.Read())
            {
                UserInfo obj = new UserInfo();
                obj.RoleNames = reader["RoleID"].ToString();
                obj.IsActive = true;
                lstUser.Add(obj);
            }
            reader.Close();
            UserInfo userObj = lstUser.Count > 0 ? lstUser[0] : new UserInfo(false);
            return userObj;

        }
        catch (Exception ex)
        {

            throw (ex);
        }

    }
}
