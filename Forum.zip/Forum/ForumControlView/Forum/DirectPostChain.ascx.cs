﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SageFrame.Web;
using SageFrame.Security;
using SageFrame.WebForum;
using SageFrame.Web.Utilities;
using System.Data.SqlClient;
using System.Collections.Generic;
public partial class Modules_Forum_ForumControlView_DirectPostChain :BaseAdministrationUserControl
{
    public string basePath = "";
    public string UserID = "";
    public string UserName = "";
    public string ModulePath = "";
    public string UserRoleName = "";
    public string UserModuleID ="";
    public bool IsModeratorUser;
    protected void Page_Load(object sender, EventArgs e)
    {
        IncludeCss();
        string appPath = Request.ApplicationPath != "/" ? Request.ApplicationPath : "";
        basePath = ResolveUrl("~/Modules/Forum/AvtImg/Thumbnails/small/");
        ModulePath = ResolveUrl("~/Modules/Forum/");
        MembershipController member = new MembershipController();
        SageFrame.Security.Entities.UserInfo user = member.GetUserDetails(GetPortalID, GetUsername.ToString());
        if (user.UserName != null)
        {
            UserID = user.UserID.ToString();
            UserName = user.UserName.ToString();

        }

        RoleController _role = new RoleController();
        string[] roles = _role.GetRoleNames(GetUsername, GetPortalID).ToLower().Split(',');
        if (roles.Contains(SystemSetting.SUPER_ROLE[0].ToLower()))
        {
            UserRoleName = SystemSetting.SUPER_ROLE[0].ToLower();
        }
		 else if (roles.Contains(SystemSetting.SITEADMIN.ToString()))
        {
            UserRoleName = SystemSetting.SITEADMIN.ToString();
        }
        UserModuleID = SageUserModuleID;
        IsModeratorUser = CheckModerator();
    }

    private void IncludeCss()
    {
        IncludeCssFile(AppRelativeTemplateSourceDirectory + "module.css");
    
    }

    private bool CheckModerator()
    {
        bool flag = false;
        List<ForumInfo> lst = new List<ForumInfo>();
        lst = SelectRoleModerator(UserModuleID);

        foreach (ForumInfo user in lst) // Loop through all strings
        {
            int aIsModerator = String.Compare(UserName, user.Username);
            if (aIsModerator == 0)
            {

                flag = true;
                break;
            }
            else
            {
                flag = false;
                // break;
            }
        }
        return flag;

    }

    public List<ForumInfo> SelectRoleModerator(string UserModuleID)
    {
        try
        {
            SageFrame.Web.Utilities.SQLHandler sagesql = new SageFrame.Web.Utilities.SQLHandler();
            List<KeyValuePair<string, object>> parameterColl = new List<KeyValuePair<string, object>>();
            parameterColl.Add(new KeyValuePair<string, object>("@UserModuleID", UserModuleID));
            List<ForumInfo> lst = sagesql.ExecuteAsList<ForumInfo>("[usp_ForumSelectModeratorUser]", parameterColl);
            return lst;
        }
        catch (Exception e)
        {
            throw e;
        }
    }
}
