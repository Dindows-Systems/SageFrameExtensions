﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.Security;
using SageFrame.Security.Entities;

public partial class Modules_Forum_ForumControlView_Inbox : BaseAdministrationUserControl
{
    public string basePath = "";
    public string UserID = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        InitializeJS();
        //lblDate.Text = DateTime.Now.ToString();
        string appPath = Request.ApplicationPath != "/" ? Request.ApplicationPath : "";
        basePath = ResolveUrl("~/Modules/Forum/");
        MembershipController member = new MembershipController();
        UserInfo user = member.GetUserDetails(GetPortalID, GetUsername.ToString());
        if (user.UserName != null)
        {
            UserID = user.UserID.ToString();

        }

    }
    
    private void InitializeJS()
    {
        //string absPath = Request.PhysicalApplicationPath + "Modules\\JobModule\\js\\jquery.tooltip.js";
        // Page.ClientScript.RegisterClientScriptInclude("toolTip", Request.PhysicalApplicationPath + "Modules\\JobModule\\js\\jquery.tooltip.js");

        //string fPath = "js\\jquery.tooltip.js";
        //string FilePath = MapPath(fPath);
        //Page.ClientScript.RegisterClientScriptInclude("jtip", FilePath);
        Page.ClientScript.RegisterClientScriptInclude("JQuery", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery.bgiframe"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryTool", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery.bxSlider.min.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryToolTip", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery.easing.1.3.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryToolTips", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery.bxSlider.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryToolTipg", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery.lightbox-0.5.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryToolTipu", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery-ui-1.8.10.custom.js"));

        Page.ClientScript.RegisterClientScriptInclude("JqueryJson", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery.revealPopup.js"));

        IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/jquery-ui-all.css");
        IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/jquery-ui-1.7.2.custom.css");

    }
}
