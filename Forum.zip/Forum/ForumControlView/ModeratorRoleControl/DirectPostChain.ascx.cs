﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SageFrame.Web;
using SageFrame.Security;

public partial class Modules_Forum_ForumControlView_DirectPostChain :BaseAdministrationUserControl
{
    public string basePath = "";
    public string UserID = "";  
    protected void Page_Load(object sender, EventArgs e)
    {
        string appPath = Request.ApplicationPath != "/" ? Request.ApplicationPath : "";
        basePath = ResolveUrl("~/Modules/Community/Handler/Images/");
        MembershipController member = new MembershipController();
        SageFrame.Security.Entities.UserInfo user = member.GetUserDetails(GetPortalID, GetUsername.ToString());
        if (user.UserName != null)
        {
            UserID = user.UserID.ToString();

        }
    }
}
