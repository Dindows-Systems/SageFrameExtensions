﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using SageFrame.Web;
using SageFrame.Security;
using SageFrame.Security.Entities;

public partial class Modules_Forum_ForumControlView_CategoryList :BaseAdministrationUserControl
{
    public string basePath = "";
    public string UserID = "";
    public string UserModuleID = "";
    public int PortalID = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        string a=this.ID;
        InitializeJS();
        //lblDate.Text = DateTime.Now.ToString();
        string appPath = Request.ApplicationPath != "/" ? Request.ApplicationPath : "";
        basePath = ResolveUrl("~/Modules/Forum/");
        MembershipController member = new MembershipController();
        UserInfo user = member.GetUserDetails(GetPortalID,GetUsername.ToString());
        if (user.UserName != null)
        {
            UserID = user.UserID.ToString();

        }
        UserModuleID = SageUserModuleID;
        PortalID = GetPortalID;
    }
    private void InitializeJS()
    {
        IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/popup.css");
        IncludeCssFile(AppRelativeTemplateSourceDirectory + "module.css");
        ArrayList jsArrColl = new ArrayList();
        jsArrColl.Add(Request.ApplicationPath.ToString() + "/Editors/ckeditor/ckeditor.js");
        jsArrColl.Add(Request.ApplicationPath.ToString() + "/Editors/ckeditor/adapters/jquery.js");
        IncludeScriptFile(jsArrColl);
    }
}
