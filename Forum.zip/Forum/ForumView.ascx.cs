﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.Security;
using SageFrame.Security.Entities;
using SageFrame.Web.Utilities;
using System.Data.SqlClient;
public partial class Modules_Forum_ForumView :BaseAdministrationUserControl
{

    //public string UserModuleID = ""; //1;
    public string UserID = "";
    public string UserRoles = "";
    protected void Page_Init(object sender, EventArgs e)
    {
        try
        {
            MembershipController member = new MembershipController();
            UserInfo user = member.GetUserDetails(GetPortalID, GetUsername.ToString());
            UserID = user.UserID.ToString();
            UserInfo userRoles = GetUserRoles(user.UserID.ToString());
            UserRoles = userRoles.RoleNames;
            //UserModuleID = SageUserModuleID;
            if (user.UserName == null)
            {              
                SageUserControl itemDetails = (SageUserControl)LoadControl("~/Modules/Forum/ForumControlView/Guest/GuestCategoryList.ascx");
                itemDetails.EnableViewState = true;
                itemDetails.SageUserModuleID = SageUserModuleID;
                phdetailBrowseholder.Controls.Add(itemDetails);
               
            }
            else
            {
                //if (userRoles.IsActive)
                //{
                //    // if moderator is true. then load edit own and other permission page. make it.
                //    SageUserControl itemDetails = (SageUserControl)LoadControl("~/Modules/Forum/ForumControlView/Forum/CategoryList.ascx");
                    
                //    itemDetails.EnableViewState = true;
                //    itemDetails.SageUserModuleID = SageUserModuleID;
                //    phdetailBrowseholder.Controls.Add(itemDetails);
                //}
                //else
                //{
                //SageUserControl itemDetails = (SageUserControl)LoadControl("~/Modules/Forum/ForumControlView/Forum/ThreadList.ascx");
                SageUserControl itemDetails = (SageUserControl)LoadControl("~/Modules/Forum/ForumControlView/Forum/CategoryList.ascx");             
                   
                    itemDetails.EnableViewState = true;
                    itemDetails.SageUserModuleID = SageUserModuleID;
                    phdetailBrowseholder.Controls.Add(itemDetails);
                //}
            }
            IncludeCss("Forum", "/Modules/Forum/module.css", "/Modules/Forum/css/message.style.css");

            IncludeJs("Forum", "/Modules/Forum/ForumControlView/js/session.js", "/js/jquery.pagination.js", "/Modules/Forum/ForumControlView/js/alertbox.js");
            
            IncludeJs("Forum", "/Modules/SmartBlog/JS/shCore.js", "/Modules/SmartBlog/JS/shBrushJScript.js", "/Modules/SmartBlog/JS/shBrushCSharp.js", "/Modules/SmartBlog/JS/shBrushCss.js", "/Modules/SmartBlog/JS/shBrushSql.js");
            IncludeCss("Forum",  "/Modules/SmartBlog/css/shCoreDefault.css");
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    public static UserInfo GetUserRoles(string UserID)
    {
        string sp = "[dbo].[usp_ForumGetUserRoles]"; // new storeprocedures
        SQLHandler sagesql = new SQLHandler();

        List<KeyValuePair<string, object>> ParamCollInput = new List<KeyValuePair<string, object>>();
        ParamCollInput.Add(new KeyValuePair<string, object>("@UserID", UserID));


        List<UserInfo> lstUser = new List<UserInfo>();
        try
        {
            SqlDataReader reader;
            reader = sagesql.ExecuteAsDataReader(sp, ParamCollInput);
            while (reader.Read())
            {
                UserInfo obj = new UserInfo();
                obj.RoleNames = reader["RoleID"].ToString();
                obj.IsActive = true;
                lstUser.Add(obj);
            }
            reader.Close();
            UserInfo userObj = lstUser.Count > 0 ? lstUser[0] : new UserInfo(false);
            return userObj;

        }
        catch (Exception ex)
        {

            throw (ex);
        }

    }
    
    protected void Page_Load(object sender, EventArgs e)
    {
        InitializeJS();
        Session["UserModuleID"] = SageUserModuleID;

    }


    private void InitializeJS()
    {        
        Page.ClientScript.RegisterClientScriptInclude("JQuery", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery.bgiframe.js")); 
        Page.ClientScript.RegisterClientScriptInclude("JQueryTool", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery.bxSlider.min.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryToolTip", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery.easing.1.3.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryToolTips", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery.bxSlider.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryToolTipg", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery.lightbox-0.5.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryToolTipu", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/jquery-ui-1.8.10.custom.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryToolTipuz", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/syntax.js"));
        //Page.ClientScript.RegisterClientScriptInclude("JQueryToolTipuz", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/ForumControlView/js/session.js"));
       
        IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/jquery-ui-all.css");
        IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/jquery-ui-1.7.2.custom.css");
        IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/syntax.css");
    }
               

}
