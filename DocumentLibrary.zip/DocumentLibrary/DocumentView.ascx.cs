﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.DocumentLibrary;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Collections;

public partial class DocumentView : BaseUserControl
{ 
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PageLoadLogic();
            LoadImageUrls();
            LoadAllCategory();
        }
        IncludeCss("DocumentLibrary", "/Modules/DocumentLibrary/module.css");
    }

    private void LoadAllCategory()
    {
        try
        {
             int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            DocumentLibraryController con = new DocumentLibraryController();
            var objCatInfo = con.GetCategoryListByPermission(UserModuleID, GetPortalID, GetUsername);
            ddlCategory.DataSource = objCatInfo;
            ddlCategory.DataTextField = "Title";
            ddlCategory.DataValueField = "CategoryID";
            ddlCategory.DataBind();
            ddlCategory.Items.Insert(0, "..choose category..");
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void LoadImageUrls()
    {
        imbReturnBackToCategory.ImageUrl = GetTemplateImageUrl("imgback.png", true);
        imbSearchDocument.ImageUrl = GetTemplateImageUrl("imgsearch.png", true);
        imbBackToCategory.ImageUrl = GetTemplateImageUrl("imgview.png", true);
        imbbackCategory.ImageUrl = GetTemplateImageUrl("imgback.png", true);
        
    }

    private void PageLoadLogic()
    {
        try
        {
             int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            DocumentLibraryController con = new DocumentLibraryController();
            List<CategoryInfo> objListCatInfo = con.GetCategoryListByPermission(UserModuleID, GetPortalID,GetUsername);
           if(objListCatInfo.Count>0)
           {
               rptShowCategory.DataSource = objListCatInfo;
               rptShowCategory.DataBind();
               DivVisibility(true, false,false);
            }
            else
            {
                divSearchDocument.Visible = false;               
                lblNoResultsMessage.Visible = true;
                lblNoResultsMessage.Text = SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "NoCategory");
           }
        }
        catch (Exception ex)
        {
            ProcessException(ex);

        }
    }

    public string GetSettingsByKey(string Key)
    {
        try
        {
            Hashtable hst = new Hashtable();
            if (HttpContext.Current.Cache["DocumentLibrarySetting"] != null)
            {
                hst = (Hashtable)HttpContext.Current.Cache["DocumentLibrarySetting"];
            }
            else
            {
                int UserModuleID = 0;
                if (!string.IsNullOrEmpty(SageUserModuleID))
                {
                    UserModuleID = Int32.Parse(SageUserModuleID);
                }
                DocumentLibraryController con = new DocumentLibraryController();
                List<DocumentLibrarySettingInfo> objDocSettingInfo = con.GetAllDocumentSetting(UserModuleID, GetPortalID);
                foreach (DocumentLibrarySettingInfo objInfo in objDocSettingInfo)
                {
                    hst.Add(objInfo.SettingKey, objInfo.SettingValue);
                }
                HttpContext.Current.Cache.Insert("DocumentLibrarySetting", hst);
            }
            return hst[Key].ToString();
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    private void DivVisibility(bool showCategory,bool showDocument,bool allDocuments)
    {
        divShowCategory.Visible = showCategory;
        divShowDocument.Visible = showDocument;
        divAllDocuments.Visible = allDocuments;
        lblChooseCategory.Visible = false;
    }

    private void GetAllDocuments(int ID)
    {
        try
        {
             int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            DocumentLibraryController con = new DocumentLibraryController();
            List<DocumentInfo> objListDocInfo = con.GetDocumentListByPermission(ID, UserModuleID, GetPortalID, GetUsername);            
          if(objListDocInfo.Count>0)
          {
              rptShowDocument.DataSource = objListDocInfo;
                rptShowDocument.DataBind();
                DivVisibility(false, true,false);
            }
            else
            {
                DivVisibility(false, false,false);
                divBackToCategory.Visible = true;
                divSearchDocument.Visible = false;               
                lblNoResultsMessage.Text = SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "NoDocument");
                lblNoResultsMessage.Visible = true;
          }
           
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    
    }

    protected void rptShowCategory_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        int ID = Int32.Parse(e.CommandArgument.ToString());
        ImageButton imbCategoryIcon = (ImageButton)e.Item.FindControl("imbCategoryIcon");
        if (e.CommandName == "ViewDocument")
        {
            GetAllDocuments(ID);
        }
    }

    protected void rptShowDocument_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
            int ID = Int32.Parse(commandArgs[0].ToString());
            string documentName = commandArgs[1].ToString();
            string documentPath = commandArgs[2].ToString();
            string documentSize = commandArgs[3].ToString();
            string documentExtension = "." + commandArgs[4].ToString();
            bool isTrackUserInfo = bool.Parse(commandArgs[5].ToString());
            string actualFile = documentPath.Substring(documentPath.LastIndexOf("\\") + 1);
            string filePath = string.Empty;
            if (isTrackUserInfo)
            {
                string userIP = HttpContext.Current.Request.UserHostAddress;
                DocumentLibraryController con = new DocumentLibraryController();
                con.GetDocumentUserInfo(ID, UserModuleID, GetPortalID, GetUsername, userIP);
            }
            switch (e.CommandName)
            {
                case "Download":
                    {
                        filePath = Server.MapPath(documentPath);
                        FileInfo file = new FileInfo(filePath);
                        if (file.Exists)
                        {
                            Response.ClearContent();
                            Response.AppendHeader("Content-Disposition", "attachment; filename=" + actualFile);
                            Response.AddHeader("Content-Length", documentSize);
                            Response.ContentType = ReturnExtension(documentExtension);
                            Response.TransmitFile(filePath);
                        }
                        Response.End();
                    }
                    break;
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private string ReturnExtension(string fileExtension)
    {
        switch (fileExtension)
        {
            case ".htm":
            case ".html":
            case ".log":
                return "text/HTML";
            case ".txt":
                return "text/plain";
            case ".doc":
                return "application/ms-word";
            case ".tiff":
            case ".tif":
                return "image/tiff";
            case ".asf":
                return "video/x-ms-asf";
            case ".avi":
                return "video/avi";
            case ".zip":
                return "application/zip";
            case ".xls":
            case ".csv":
                return "application/vnd.ms-excel";
            case ".gif":
                return "image/gif";
            case ".jpg":
            case "jpeg":
                return "image/jpeg";
            case ".bmp":
                return "image/bmp";
            case ".wav":
                return "audio/wav";
            case ".mp3":
                return "audio/mpeg3";
            case ".mpg":
            case "mpeg":
                return "video/mpeg";
            case ".rtf":
                return "application/rtf";
            case ".asp":
                return "text/asp";
            case ".pdf":
                return "application/pdf";
            case ".fdf":
                return "application/vnd.fdf";
            case ".ppt":
                return "application/mspowerpoint";
            case ".dwg":
                return "image/vnd.dwg";
            case ".msg":
                return "application/msoutlook";
            case ".xml":
            case ".sdxl":
                return "application/xml";
            case ".xdp":
                return "application/vnd.adobe.xdp+xml";
            default:
                return "application/octet-stream";
        }
    }

    public int GetDownloadCounts(string documentID)
    {
        try
        {
            int ID = Int32.Parse(documentID);
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            DocumentLibraryController con = new DocumentLibraryController();
            int downloadCount = con.GetDownloadCount(ID, UserModuleID, GetPortalID);
            return downloadCount;
        }
        catch (Exception ex)
        {
            ProcessException(ex);
            return 0;
        }
    }

    protected void rptShowDocument_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            } 
            bool showDownloadLink =bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowDownloadLink));
            bool showDownloadStatistics = bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowDownloadStatistics));
            bool showDocumentSize = bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowDocumentSize));
            bool showDocumentExtension = bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowDocumentExtension));
            bool showDocumentDescription = bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowDocumentDescription));
            bool showVersion = bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowVersion));
            if( e.Item.ItemType == ListItemType.Header)
            {
                HtmlTableCell tdExtension = (HtmlTableCell)e.Item.FindControl("tdExtension");
                HtmlTableCell tdSize = (HtmlTableCell)e.Item.FindControl("tdSize");
                HtmlTableCell tdVersion = (HtmlTableCell)e.Item.FindControl("tdVersion");
                HtmlTableCell tdDescription = (HtmlTableCell)e.Item.FindControl("tdDescription");
                HtmlTableCell tdDownloadStatistics = (HtmlTableCell)e.Item.FindControl("tdDownloadStatistics");
                if (showDownloadStatistics == false)
                {
                    tdDownloadStatistics.Visible = false;
                }
                 if (showDocumentSize == false)
                {
                    tdSize.Visible = false;
                }
                 if (showDocumentExtension == false)
                {
                    tdExtension.Visible = false;
                }
                 if (showDocumentDescription == false)
                {
                    tdDescription.Visible = false;
                }
                 if (showVersion == false)
                {
                    tdVersion.Visible = false;
                }
            }
             if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType ==
              ListItemType.AlternatingItem)
            {
                int ID = (Int32)DataBinder.Eval(e.Item.DataItem, "DocumentID"); 
                DocumentLibraryController con = new DocumentLibraryController();
                DocumentInfo objInfo = con.GetDocumentInfoById(ID, UserModuleID, GetPortalID);
                bool isOpenInNewWindow = objInfo.IsOpenInNewWindow;
                HtmlTableCell tdItemExtension = (HtmlTableCell)e.Item.FindControl("tdItemExtension");
                HtmlTableCell tdItemSize = (HtmlTableCell)e.Item.FindControl("tdItemSize");
                HtmlTableCell tdItemVersion = (HtmlTableCell)e.Item.FindControl("tdItemVersion");
                HtmlTableCell tdItemDescription = (HtmlTableCell)e.Item.FindControl("tdItemDescription");
                HtmlTableCell tdItemDownloadCount = (HtmlTableCell)e.Item.FindControl("tdItemDownloadCount");
                HtmlTableCell tdItemDownload = (HtmlTableCell)e.Item.FindControl("tdItemDownload");
                HtmlAnchor ItemDocumentName = (HtmlAnchor)e.Item.FindControl("lnkItemDocumentName");
                if (isOpenInNewWindow)
                {
                    ItemDocumentName.Attributes.Add("target", "_blank");
                }
                else
                {
                    ItemDocumentName.Attributes.Add("target", "_self");
                }
                  string userIP = HttpContext.Current.Request.UserHostAddress;
                  ItemDocumentName.Attributes.Add("onclick", string.Format(" return IncreamentViewCount('{0}','{1}','{2}','{3}','{4}','{5}');", ID, GetUsername, userIP, UserModuleID, GetPortalID, ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/DocumentLibraryWebService.asmx/UpdateViewCount")));

                if (showDownloadLink == false)
                {
                    tdItemDownload.Visible = false;
                }
                 if (showDownloadStatistics == false)
                {
                    tdItemDownloadCount.Visible = false;
                }
                 if (showDocumentSize == false)
                {
                   tdItemSize.Visible = false;
                }
                if (showDocumentExtension == false)
                {
                    tdItemExtension.Visible = false;
                }
                 if (showDocumentDescription == false)
                {
                    tdItemDescription.Visible = false;
                }
                 if (showVersion == false)
                {
                    tdItemVersion.Visible = false;
                }
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    protected void rptShowCategory_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
             bool showCategoryDescription = bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowCategoryDescription));
                bool showCategoryIcon = bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowCategoryIcon));          
            if (e.Item.ItemType == ListItemType.Header)
            {
                HtmlTableCell tdHeaderCategoryImage = (HtmlTableCell)e.Item.FindControl("tdHeaderCategoryImage");
                HtmlTableCell tdHeaderCategoryDescription = (HtmlTableCell)e.Item.FindControl("tdHeaderCategoryDescription");
                if (showCategoryDescription == false)
                {
                    tdHeaderCategoryDescription.Visible = false;
                }
                if (showCategoryIcon == false)
                {
                    tdHeaderCategoryImage.Visible = false;
                }
            }
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType ==
       ListItemType.AlternatingItem)
            {
                HtmlTableCell tdCategoryIcon = (HtmlTableCell)e.Item.FindControl("tdCategoryIcon");
                HtmlTableCell tdCategoryDescription = (HtmlTableCell)e.Item.FindControl("tdCategoryDescription");
                ImageButton imbViewDocuments = (ImageButton)e.Item.FindControl("imbViewDocuments");
                imbViewDocuments.ImageUrl = GetTemplateImageUrl("imgpreview.png", true);
                
                if (showCategoryDescription == false)
                {
                    tdCategoryDescription.Visible = false;
                }
                if (showCategoryIcon == false)
                {
                    tdCategoryIcon.Visible = false;
                }
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    protected void imbReturnBackToCategory_Click(object sender, ImageClickEventArgs e)
    {
        DivVisibility(true, false,false);
        divBackToCategory.Visible = false;
        divSearchDocument.Visible = true;
        lblNoResultsMessage.Visible = false;
        ClearAll();
    }

    private void ClearAll()
    {
        txtDocumentName.Text = string.Empty;
    }

    private void SearchDocument()
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            string documentName = txtDocumentName.Text;
            if (ddlCategory.SelectedIndex == 0)
            {               
                lblChooseCategory.Visible = true;
                lblChooseCategory.Text = lblNoResultsMessage.Text = SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "ChooseCategory");
            }
            else
            {
                int categoryID = Int32.Parse(ddlCategory.SelectedValue);
                DocumentLibraryController con = new DocumentLibraryController();
                List<DocumentInfo> objListDocInfo = con.GetAllDocumentListBySearch(documentName, categoryID, UserModuleID, GetPortalID);
                if (objListDocInfo.Count > 0)
                {
                    DivVisibility(false, false, true);
                    rptAllDocuments.DataSource = objListDocInfo;
                    rptAllDocuments.DataBind();
                    lblNoResultsMessage.Visible = false;
                    divBackToCategory.Visible = false;
                    lblChooseCategory.Visible = false;
                }
                else
                {
                    DivVisibility(false, false, false);
                    divBackToCategory.Visible = true;
                    lblNoResultsMessage.Text = SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "NoResultsFound");
                    lblNoResultsMessage.Visible = true;
                }
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    protected void imbSearchDocument_Click(object sender, ImageClickEventArgs e)
    {
        SearchDocument();
       
    }

    protected void rptAllDocuments_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            string[] commandArgs = e.CommandArgument.ToString().Split(new char[] { ',' });
            int ID = Int32.Parse(commandArgs[0].ToString());
            string documentName = commandArgs[1].ToString();
            string documentPath = commandArgs[2].ToString();
            string documentSize = commandArgs[3].ToString();
            string documentExtension = "." + commandArgs[4].ToString();
            bool isTrackUserInfo = bool.Parse(commandArgs[5].ToString());
            string actualFile = documentPath.Substring(documentPath.LastIndexOf("\\") + 1);
            string filePath = string.Empty;
            if (isTrackUserInfo)
            {
                string userIP = HttpContext.Current.Request.UserHostAddress;
                DocumentLibraryController con = new DocumentLibraryController();
                con.GetDocumentUserInfo(ID, UserModuleID, GetPortalID, GetUsername, userIP);
            }
            switch (e.CommandName)
            {
                case "Download":
                    {
                        filePath = Server.MapPath(documentPath);
                        FileInfo file = new FileInfo(filePath);
                        if (file.Exists)
                        {
                            Response.ClearContent();
                            Response.AppendHeader("Content-Disposition", "attachment; filename=" + actualFile);
                            Response.AddHeader("Content-Length", documentSize);
                            Response.ContentType = ReturnExtension(documentExtension);
                            Response.TransmitFile(filePath);
                        }
                        Response.End();
                    }
                    break;
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }
    
    protected void rptAllDocuments_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            bool showDownloadLink = bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowDownloadLink));
            bool showDownloadStatistics = bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowDownloadStatistics));
            bool showDocumentSize = bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowDocumentSize));
            bool showDocumentExtension = bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowDocumentExtension));
            bool showDocumentDescription = bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowDocumentDescription));
            bool showVersion = bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowVersion));

            if (e.Item.ItemType == ListItemType.Header)
            {
                HtmlTableCell tdExtension = (HtmlTableCell)e.Item.FindControl("tdExtension");
                HtmlTableCell tdSize = (HtmlTableCell)e.Item.FindControl("tdSize");
                HtmlTableCell tdVersion = (HtmlTableCell)e.Item.FindControl("tdVersion");
                HtmlTableCell tdDescription = (HtmlTableCell)e.Item.FindControl("tdDescription");
                HtmlTableCell tdDownloadStatistics = (HtmlTableCell)e.Item.FindControl("tdDownloadStatistics");
                if (showDownloadStatistics == false)
                {
                    tdDownloadStatistics.Visible = false;
                }
                if (showDocumentSize == false)
                {
                    tdSize.Visible = false;
                }
                if (showDocumentExtension == false)
                {
                    tdExtension.Visible = false;
                }
                if (showDocumentDescription == false)
                {
                    tdDescription.Visible = false;
                }
                if (showVersion == false)
                {
                    tdVersion.Visible = false;
                }
            }
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType ==
             ListItemType.AlternatingItem)
            {
                int ID = (Int32)DataBinder.Eval(e.Item.DataItem, "DocumentID");
                DocumentLibraryController con = new DocumentLibraryController();
                DocumentInfo objInfo = con.GetDocumentInfoById(ID, UserModuleID, GetPortalID);
                bool isOpenInNewWindow = objInfo.IsOpenInNewWindow;
                HtmlTableCell tdItemExtension = (HtmlTableCell)e.Item.FindControl("tdItemExtension");
                HtmlTableCell tdItemSize = (HtmlTableCell)e.Item.FindControl("tdItemSize");
                HtmlTableCell tdItemVersion = (HtmlTableCell)e.Item.FindControl("tdItemVersion");
                HtmlTableCell tdItemDescription = (HtmlTableCell)e.Item.FindControl("tdItemDescription");
                HtmlTableCell tdItemDownloadCount = (HtmlTableCell)e.Item.FindControl("tdItemDownloadCount");
                HtmlTableCell tdItemDownload = (HtmlTableCell)e.Item.FindControl("tdItemDownload");
                HtmlAnchor ItemDocumentName = (HtmlAnchor)e.Item.FindControl("lnkItemDocumentName");
                if (isOpenInNewWindow)
                {
                    ItemDocumentName.Attributes.Add("target", "_blank");
                }
                else
                {
                    ItemDocumentName.Attributes.Add("target", "_self");
                }
                string userIP = HttpContext.Current.Request.UserHostAddress;
                ItemDocumentName.Attributes.Add("onclick", string.Format(" return IncreamentViewCount('{0}','{1}','{2}','{3}','{4}','{5}');", ID, GetUsername, userIP, UserModuleID, GetPortalID, ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/DocumentLibraryWebService.asmx/UpdateViewCount")));

                if (showDownloadLink == false)
                {
                    tdItemDownload.Visible = false;
                }
                if (showDownloadStatistics == false)
                {
                    tdItemDownloadCount.Visible = false;
                }
                if (showDocumentSize == false)
                {
                    tdItemSize.Visible = false;
                }
                if (showDocumentExtension == false)
                {
                    tdItemExtension.Visible = false;
                }
                if (showDocumentDescription == false)
                {
                    tdItemDescription.Visible = false;
                }
                if (showVersion == false)
                {
                    tdItemVersion.Visible = false;
                }
            }
        }

        catch (Exception ex)
        {
            ProcessException(ex);
        }
        
    }

    protected void imbBackToCategory_Click1(object sender, ImageClickEventArgs e)
    {
        DivVisibility(true, false, false);
        divSearchDocument.Visible = true;
    }

    protected void imbbackCategory_Click(object sender, ImageClickEventArgs e)
    {
        DivVisibility(true, false, false);
        ClearAll();
    }
}

