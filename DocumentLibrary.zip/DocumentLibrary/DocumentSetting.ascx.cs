﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.DocumentLibrary;
using System.Text;
using System.Collections;

public partial class DocumentSetting : BaseAdministrationUserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetImageUrls();
            ReadAllDocumentSettings();
            chkAllowMultipleCategory.Attributes.Add("onclick",string.Format("return multiplecategory('{0}');",chkAllowMultipleCategory.ClientID));
            txtCategoryIconMaxFileSize.Attributes.Add("onkeypress", "return KeyTypeCheck(event);");
            txtCategoryIconThumbnailSize.Attributes.Add("onkeypress", "return KeyTypeCheck(event);");
        }
    }

    private void GetImageUrls()
    {
        imbSaveDocumentSettings.ImageUrl = GetTemplateImageUrl("imgsave.png", true);
    }

    private void ReadAllDocumentSettings()
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            DocumentLibraryController con = new DocumentLibraryController();
            List<DocumentLibrarySettingInfo> objSettingInfo = con.GetAllDocumentSetting(UserModuleID, GetPortalID);
            foreach (DocumentLibrarySettingInfo objInfo in objSettingInfo)
            {
                string strKey = objInfo.SettingKey;
                switch (strKey)
                {
                    case "ShowDownloadLink":
                        chkShowDownloadLink.Checked = bool.Parse(objInfo.SettingValue);
                        break;
                    case "ShowDownloadStatistics":
                        chkShowDownloadStatistics.Checked = bool.Parse(objInfo.SettingValue);
                        break;
                    case "AllowMultipleCategory":
                        chkAllowMultipleCategory.Checked = bool.Parse(objInfo.SettingValue);
                        break;
                    case "ShowCategoryDescription":
                        chkShowCategoryDescription.Checked = bool.Parse(objInfo.SettingValue);
                        break;
                    case "ShowDocumentSize":
                        chkShowDocumentSize.Checked = bool.Parse(objInfo.SettingValue);
                        break;
                    case "ShowDocumentExtension":
                        chkShowDocumentExtension.Checked = bool.Parse(objInfo.SettingValue);
                        break;
                    case "ShowDocumentDescription":
                        chkShowDocumentDescription.Checked = bool.Parse(objInfo.SettingValue);
                        break;
                    case "ShowVersion":
                        chkShowDocumentVersion.Checked = bool.Parse(objInfo.SettingValue);
                        break;
                    case "ShowCategoryIcon":
                        chkShowCategoryIcon.Checked = bool.Parse(objInfo.SettingValue);
                        break;
                    case "CategoryIconExtension":
                        txtCategoryIconExtension.Text = objInfo.SettingValue;
                        break;
                    case "CategoryIconMaxsize":
                        txtCategoryIconMaxFileSize.Text = objInfo.SettingValue;
                        break;
                    case "CategoryIconThumbnailSize":
                        txtCategoryIconThumbnailSize.Text = objInfo.SettingValue;
                        break;

                }
            }
            if (chkShowCategoryIcon.Checked == false)
            {
                divCategorySettings.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void SaveDocumentSettings()
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            StringBuilder sbSettingKey = new StringBuilder();
            StringBuilder sbSettingValue = new StringBuilder();
            sbSettingKey.Append("ShowDownloadLink" + '#');
            sbSettingValue.Append(chkShowDownloadLink.Checked + "#");
            sbSettingKey.Append("ShowDownloadStatistics" + '#');
            sbSettingValue.Append(chkShowDownloadStatistics.Checked + "#");
            sbSettingKey.Append("AllowMultipleCategory" + "#");
            sbSettingValue.Append(chkAllowMultipleCategory.Checked + "#");
            sbSettingKey.Append("ShowCategoryDescription" + "#");
            sbSettingValue.Append(chkShowCategoryDescription.Checked + "#");
            sbSettingKey.Append("ShowDocumentSize" + "#");
            sbSettingValue.Append(chkShowDocumentSize.Checked + "#");
            sbSettingKey.Append("ShowDocumentExtension" + "#");
            sbSettingValue.Append(chkShowDocumentExtension.Checked + "#");
            sbSettingKey.Append("ShowDocumentDescription" + "#");
            sbSettingValue.Append(chkShowDocumentDescription.Checked+"#");
            sbSettingKey.Append("ShowVersion" + "#");
            sbSettingValue.Append(chkShowDocumentVersion.Checked+ "#");
            sbSettingKey.Append("ShowCategoryIcon" + "#");
            sbSettingValue.Append(chkShowCategoryIcon.Checked + "#");
            sbSettingKey.Append("CategoryIconExtension" + "#");
            sbSettingValue.Append(txtCategoryIconExtension.Text.Trim()+"#");
            sbSettingKey.Append("CategoryIconMaxsize" + "#");
            sbSettingValue.Append(txtCategoryIconMaxFileSize.Text.Trim() + "#");
            sbSettingKey.Append("CategoryIconThumbnailSize");
            sbSettingValue.Append(txtCategoryIconThumbnailSize.Text.Trim());
            string SettingKeys = sbSettingKey.ToString();
            string SettingValues = sbSettingValue.ToString();
            DocumentLibraryController con = new DocumentLibraryController();
            con.GetDocumentSettingUpdate(SettingKeys, SettingValues, UserModuleID, GetPortalID);
            ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "SettingsSavedSuccessfully"), "", SageMessageType.Success); 
            Hashtable hst = new Hashtable();
            List<DocumentLibrarySettingInfo> objDocSettingInfo = con.GetAllDocumentSetting(UserModuleID, GetPortalID);
            foreach (DocumentLibrarySettingInfo objInfo in objDocSettingInfo)
            {
                hst.Add(objInfo.SettingKey, objInfo.SettingValue);
            }
            HttpContext.Current.Cache.Insert("DocumentLibrarySetting", hst);
        }
        catch(Exception ex)
        {
            ProcessException(ex);
        }
    }

    protected void imbSaveDocumentSettings_Click(object sender, ImageClickEventArgs e)
    {
        SaveDocumentSettings();
    }

    protected void chkShowCategoryIcon_CheckedChanged(object sender, EventArgs e)
    {
        if (chkShowCategoryIcon.Checked)
        {
            divCategorySettings.Visible = true;
      
        }
        else
        {
            divCategorySettings.Visible = false;
          
        }
    }
}
