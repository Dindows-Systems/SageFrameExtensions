﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.DocumentLibrary;
using System.IO;
using System.Web.UI.HtmlControls;
using SageFrame.RolesManagement;
using System.Data;
using System.Drawing;
using System.Collections;
using SageFrame.UserManagement;
using SageFrame.Security;


public partial class DocumentEdit : BaseAdministrationUserControl
{
    bool isAllowMultipleCategory;
    string superUser, siteAdmin;
    protected void Page_Init(object sender, EventArgs e)
    {
        PlaceHolderLogic();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (!IsPostBack)
        {
           
            PageLoadLogic();
            LoadAllCategory();
            PopulateRoles();
            AddImageUrls();
            LoadAllCategoryContent();
            PopulateUsers();
            populate();
           
        }
    }

    private void SelectSuperRoles()
    {
        string[] array = SystemSetting.SYSTEM_SUPER_ROLES;
        string SiteAdmin = array[0].ToString().ToUpper();
        string SuperUser = array[1].ToString().ToUpper();
        for (int i = 0; i < lstCategoryRoleAccess.Items.Count; i++)
        {
            if (lstCategoryRoleAccess.Items[i].Text.ToUpper() == SuperUser  )
            {
                lstCategoryRoleAccess.Items[i].Attributes.Add("disabled", "true");
                superUser = lstCategoryRoleAccess.Items[i].Value;
            }
            if (lstCategoryRoleAccess.Items[i].Text.ToUpper() == SiteAdmin)
            {
                lstCategoryRoleAccess.Items[i].Attributes.Add("disabled", "true");
                siteAdmin = lstCategoryRoleAccess.Items[i].Value;
            }
          
        }

        for (int i = 0; i < lstDocumentRolePermission.Items.Count; i++)
        {
            if (lstDocumentRolePermission.Items[i].Text.ToUpper() == SuperUser)
            {
                lstDocumentRolePermission.Items[i].Attributes.Add("disabled", "true");
                superUser = lstCategoryRoleAccess.Items[i].Value;
            }
            if (lstDocumentRolePermission.Items[i].Text.ToUpper() == SiteAdmin)
            {
                lstDocumentRolePermission.Items[i].Attributes.Add("disabled", "true");
                siteAdmin = lstCategoryRoleAccess.Items[i].Value;
            }
        }
    }
    
    private void PlaceHolderLogic()
    {
        isAllowMultipleCategory = bool.Parse(GetSettingsByKey(DocumentLibrarySettings.AllowMultipleCategory));
        if (isAllowMultipleCategory)
        {
            ListBox lstChooseCategory = new ListBox();
            lstChooseCategory.ID = "lstChooseCategory";
            phdCategory.Controls.Add(lstChooseCategory);
            lstChooseCategory.SelectionMode = ListSelectionMode.Multiple;
        }
        else
        {
            DropDownList lstChooseCategory = new DropDownList();
            lstChooseCategory.ID = "lstChooseCategory";
            lstChooseCategory.Attributes.Add("OnChange", "OnCategorySelected()");
            phdCategory.Controls.Add(lstChooseCategory);
        }        
    }

    public string GetSettingsByKey(string Key)
    {
        try
        {
            Hashtable hst = new Hashtable();
            if (HttpContext.Current.Cache["DocumentLibrarySetting"] != null)
            {
                hst = (Hashtable)HttpContext.Current.Cache["DocumentLibrarySetting"];
            }
            else
            {
                int UserModuleID = 0;
                if (!string.IsNullOrEmpty(SageUserModuleID))
                {
                    UserModuleID = Int32.Parse(SageUserModuleID);
                }
                DocumentLibraryController con = new DocumentLibraryController();
                List<DocumentLibrarySettingInfo> objDocSettingInfo = con.GetAllDocumentSetting(UserModuleID, GetPortalID);
                foreach (DocumentLibrarySettingInfo objInfo in objDocSettingInfo)
                {
                    hst.Add(objInfo.SettingKey, objInfo.SettingValue);
                }
                HttpContext.Current.Cache.Insert("DocumentLibrarySetting", hst);
            }           
            return hst[Key].ToString();
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    private void PageLoadLogic()
    {
        try
        {
            txtDisplayOrder.Attributes.Add("onkeypress", "return KeyTypeCheck(event);");
            rfvAllowedDocumentSize.Attributes.Add("onkeypress", "return KeyTypeCheck(event);");
            if (isAllowMultipleCategory)
            {
                trAllowedDocumentSize.Visible = false;
                trSupportExtension.Visible = false;
            }
            else
            {
                txtAllowedDocumentSize.Attributes.Add("onkeypress", "return KeyTypeCheck(event);");
                rfvSupportedExtension.ControlToValidate = "txtSupportedExtension";
                rfvSupportedExtension.ValidationGroup = "vdCategory";
                rfvSupportedExtension.ErrorMessage = "Extension is required";
                rfvAllowedDocumentSize.ControlToValidate = "txtAllowedDocumentSize";
                rfvAllowedDocumentSize.ValidationGroup = "vdCategory";
                rfvAllowedDocumentSize.ErrorMessage = "Size is required";
                imbSaveCategory.ValidationGroup = "vdCategory";
            }
            isAllowMultipleCategory=bool.Parse(GetSettingsByKey(DocumentLibrarySettings.AllowMultipleCategory));
            string AllowedExtension = GetSettingsByKey(DocumentLibrarySettings.CategoryIconExtension);
            bool showCategoryIcon = bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowCategoryIcon));
            if (!showCategoryIcon)
            {
                trCategoryIcon.Visible = false;
                trIconAlternateText.Visible = false;
                trShowCurrentCategoryIcon.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }          
 
    private void PopulateUsers()
    {
        try
        {
            DocumentLibraryController con=new DocumentLibraryController();
            var users =con.GetAllUsersByPortalID ("","", GetPortalID, GetUsername);
            lstCategoryUserAccess.DataSource = users;
            lstCategoryUserAccess.DataTextField = "UserName";
            lstCategoryUserAccess.DataValueField = "UserName";
            lstCategoryUserAccess.DataBind();                
           
        }
             catch (Exception ex)
        {
            ProcessException(ex);
        }

    }

    private void populate()
    {
        try
        {
            DocumentLibraryController con = new DocumentLibraryController();
            var users = con.GetAllUsersByPortalID("", "", GetPortalID, GetUsername);
            lstDocumentUserPermission.DataSource = users;
            lstDocumentUserPermission.DataTextField = "UserName";
            lstDocumentUserPermission.DataValueField = "UserName";
            lstDocumentUserPermission.DataBind();
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }

    private void LoadAllCategoryContent()
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
           
                DocumentLibraryController con = new DocumentLibraryController();
                List<CategoryInfo> objListCatInfo = con.GetCategoryList(UserModuleID, GetPortalID);
                if (objListCatInfo.Count > 0)
                {
                    rptShowCategory.DataSource = objListCatInfo;
                    rptShowCategory.DataBind();
                    DivVisibility(false, false, true, false, false);
                    divNewDocument.Visible = true;
                }
                else if (objListCatInfo.Count == 0)
                {
                    divNewDocument.Visible = false;
                    DivVisibility(false, false, false, false, false);
                    ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "NoCategory"), "", SageMessageType.Alert);
                }
            
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void AddImageUrls()
    {
        imbAddNewDocument.ImageUrl = GetTemplateImageUrl("imgadd.png", true);
        imbAddNewCategory.ImageUrl = GetTemplateImageUrl("imgadd.png", true);
        imbSaveCategory.ImageUrl = GetTemplateImageUrl("imgsave.png", true);
        imbSaveDocument.ImageUrl = GetTemplateImageUrl("imgsave.png", true);
        imbCancelCategory.ImageUrl = GetTemplateImageUrl("imgcancel.png", true);
        imbCancelDocument.ImageUrl = GetTemplateImageUrl("imgcancel.png", true);
        imbBackToCategory.ImageUrl = GetTemplateImageUrl("imgview.png", true);
        imbReturnBackToCategory.ImageUrl = GetTemplateImageUrl("imgback.png", true);
    }

    private void PopulateRoles()
    {
        DataTable dtRoles = new DataTable();
        dtRoles.Columns.Add("Role");
        dtRoles.Columns.Add("RoleId");
        dtRoles.AcceptChanges();
        RoleController _role=new RoleController();
        var roles = _role.GetPortalRoles(GetPortalID, 1, GetUsername);
        foreach (var role in roles)
        {
            string roleName = role.RoleName;
            string roleId = role.RoleID.ToString();
            if (SystemSetting.SYSTEM_ROLES.Contains(roleName, StringComparer.OrdinalIgnoreCase))
            {
                DataRow dr = dtRoles.NewRow();
                dr["Role"] = roleName;
                dr["RoleId"] = roleId;
                dtRoles.Rows.Add(dr);
            }
            else
            {
                string rolePrefix = GetPortalSEOName + "_";
                roleName = roleName.Replace(rolePrefix, "");
                DataRow dr = dtRoles.NewRow();
                dr["Role"] = roleName;
                dr["RoleId"] = roleId;
                dtRoles.Rows.Add(dr);
            }
        }
        lstCategoryRoleAccess.DataSource = dtRoles;
        lstCategoryRoleAccess.DataTextField = "Role";
        lstCategoryRoleAccess.DataValueField = "RoleId";
        lstCategoryRoleAccess.DataBind();
        lstDocumentRolePermission.DataSource = dtRoles;
        lstDocumentRolePermission.DataTextField = "Role";
        lstDocumentRolePermission.DataValueField = "RoleId";
        lstDocumentRolePermission.DataBind();
    }

    private void LoadAllCategory()
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            isAllowMultipleCategory = bool.Parse(GetSettingsByKey(DocumentLibrarySettings.AllowMultipleCategory));            
            DocumentLibraryController con = new DocumentLibraryController();
            List<CategoryInfo> oblListCatInfo = con.GetCategoryNameList(UserModuleID, GetPortalID);
            if (isAllowMultipleCategory)
            {
                ListBox lstChooseCategory = (ListBox)phdCategory.FindControl("lstChooseCategory");
                lstChooseCategory.DataSource = oblListCatInfo;
                lstChooseCategory.DataTextField = "Title";
                lstChooseCategory.DataValueField = "CategoryID";
                lstChooseCategory.DataBind();
            }
            else
            {
                DropDownList lstChooseCategory = (DropDownList)phdCategory.FindControl("lstChooseCategory");
                lstChooseCategory.DataSource = oblListCatInfo;
                lstChooseCategory.DataTextField = "Title";
                lstChooseCategory.DataValueField = "CategoryID";
                lstChooseCategory.DataBind();
               
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void DivVisibility(bool addCategory,bool addDocument, bool showCategory, bool showDocument,bool showCurrentCategoryIcon)
    {
        divAddCategory.Visible = addCategory;
        divAddDocument.Visible = addDocument;
        divShowCategory.Visible = showCategory;
        divShowDocument.Visible = showDocument;
        trShowCurrentCategoryIcon.Visible = showCurrentCategoryIcon;
    }

    private void EditCategory(int ID)
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            DocumentLibraryController con = new DocumentLibraryController();
            CategoryInfo objCatInfo = con.GetCategoryInfoById(ID, UserModuleID, GetPortalID);
            txtCategoryTitle.Text = objCatInfo.Title;
            txtCategoryDescription.Text = objCatInfo.Description;
            txtSupportedExtension.Text = objCatInfo.SupportedExtension;
            txtIconAlternateText.Text = objCatInfo.IconAlternateText;
            txtAllowedDocumentSize.Text = objCatInfo.AllowedDocumentSize;
            imgCurrentCategoryIcon.ImageUrl = objCatInfo.CategoryIcon;
            hdnCategoryID.Value = ID.ToString();
            hdnCategoryPath.Value = objCatInfo.CategoryIcon;
            iaFrmCategoryEdit.Value = "1";
            SelectSuperRoles();
            
            bool isShowCategoryIcon=bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowCategoryIcon));
            if (isShowCategoryIcon)
            {
                DivVisibility(true, false, false, false, true);
            }
            else
            {
                DivVisibility(true, false, false, false, false);
                trShowCurrentCategoryIcon.Visible = false;
            }

        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void ClearAll()
    {
        iaFrmCategoryEdit.Value = "0";
        iaFrmDocumentEdit.Value = "0";
        hdnCategoryID.Value = "0";
        hdnDocumentID.Value = "0";
        hdfCategoryID.Value = "0";
        hdnDocumentExtension.Value = "0";
        hdnDocumentSize.Value = "0";
        hdnCategoryPath.Value = "0";
        hdnDocumentPath.Value = "0";
        txtCategoryTitle.Text = string.Empty;
        txtCategoryDescription.Text = string.Empty;
        txtSupportedExtension.Text = string.Empty;
        txtIconAlternateText.Text = string.Empty;
        txtDocumentName.Text = string.Empty;
        txtDocumentDescription.Text = string.Empty;
        txtVersion.Text = string.Empty;

    }

    public string GetDocumentLibraryImageUrl(string imageName, bool isServerControl)
    {
        string path = string.Empty;
        string strpath="~Modules/DocumentLibrary/ImageFiles/";
        string actualPath=Server.MapPath(strpath);
        if(!Directory.Exists(actualPath))
        {
            Directory.CreateDirectory(actualPath);
        }
        if (isServerControl == true)
        {
            path = "~/Modules/DocumentLibrary/ImageFiles/" + imageName;
        }
            
        else
        {
            path = this.Page.ResolveUrl("~/Modules/DocumentLibrary/ImageFiles/" + imageName);
        }
        return path;
    }

    private void DeleteCategory(int ID)
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            DocumentLibraryController con = new DocumentLibraryController();
            con.DeleteCategoryById(ID, UserModuleID, GetPortalID, GetUsername);
            ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "DataDeletedSuccessfully"), "", SageMessageType.Success);
            LoadAllCategoryContent();
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }

    }

    private void ManageCategory(int ID)
    {
        try
        {

            hdfCategoryID.Value = ID.ToString();
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            DocumentLibraryController con = new DocumentLibraryController();
            List<DocumentInfo> objListDocInfo = con.GetDocumentListByCategory(ID,UserModuleID, GetPortalID);
            if (objListDocInfo.Count>0)
            {
                rptShowDocument.DataSource = objListDocInfo;
                rptShowDocument.DataBind();
                DivVisibility(false, false, false, true, false);
                
            }
            else if(objListDocInfo.Count==0)
            {
                DivVisibility(false, false, false, false, false);
                divBackToCategory.Visible = true;
                ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "NoDocument"), "", SageMessageType.Alert); 
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void SaveDocument()
    {
        try
        {
            SelectSuperRoles();
            bool isFormValid = false;
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            DocumentLibraryController con = new DocumentLibraryController();
            DocumentInfo objDocInfo = new DocumentInfo();
            objDocInfo.DocumentID = Int32.Parse(hdnDocumentID.Value);
            objDocInfo.Name = txtDocumentName.Text.Trim();
            objDocInfo.Description = txtDocumentDescription.Text.Trim();
            objDocInfo.Version = txtVersion.Text.Trim();
            if (txtDisplayOrder != null)
            {
                objDocInfo.DisplayOrder = Int32.Parse(txtDisplayOrder.Text.Trim());
            }
            else
            {
                objDocInfo.DisplayOrder = 0;
            }
            objDocInfo.IsTrackUserInfo = chkIsTrackUserInfo.Checked;
            objDocInfo.IsOpenInNewWindow = chkIsOpenInNewWindow.Checked;
            ArrayList arrRoles = new ArrayList();
            for (int i = 0; i < lstDocumentRolePermission.Items.Count; i++)
            {
                if (lstDocumentRolePermission.Items[i].Selected)
                {
                    arrRoles.Add(lstDocumentRolePermission.Items[i].Value);
                }
            }
            arrRoles.Add(superUser);
            arrRoles.Add(siteAdmin);
            string[] strRoles = new string[arrRoles.Count];
            arrRoles.CopyTo(strRoles);
            string finalStringRoles = string.Join("#", strRoles);
            ArrayList arrUsers = new ArrayList();
            for (int i = 0; i < lstDocumentUserPermission.Items.Count;i++)
            {
                if (lstDocumentUserPermission.Items[i].Selected)
                {
                    arrUsers.Add(lstDocumentUserPermission.Items[i].Value);
                }
            }
            
            string[] strUsers = new string[arrUsers.Count];
            arrUsers.CopyTo(strUsers);
            string finalStringUsers = string.Join("#", strUsers);
            string categories = string.Empty;


            string finalCategoryIDs = string.Empty;
            ListItemCollection listItems = new ListItemCollection();
            if (isAllowMultipleCategory)
            {
                ListBox lstChooseCategory = (ListBox)phdCategory.FindControl("lstChooseCategory");
                listItems = lstChooseCategory.Items;
            }
            else
            {
                DropDownList lstChooseCategory = (DropDownList)phdCategory.FindControl("lstChooseCategory");
                listItems = lstChooseCategory.Items;
            }
            for (int i = 0; i < listItems.Count; i++)
            {
                if (listItems[i].Selected)
                {
                   
                    finalCategoryIDs += listItems[i].Value + "#";
                }
            }

            if (finalCategoryIDs.Length >0)
            {
                finalCategoryIDs = finalCategoryIDs.Substring(0, finalCategoryIDs.Length - 1);
                
            
                string documentSavePath=string.Empty;
                if (fluDocumentPath.HasFile || int.Parse(hdnDocumentID.Value) > 0)
                {
                    if (fluDocumentPath.HasFile)
                    {
                        string fileType = string.Empty;
                        long documentSize = fluDocumentPath.PostedFile.ContentLength;
                        string uploadedFile = fluDocumentPath.PostedFile.FileName;
                        string uploadPath = "~\\Modules\\DocumentLibrary\\Documents\\";
                       
                        documentSavePath = Server.MapPath("~/Modules/DocumentLibrary/Documents/");
                        FileInfo objFileInfo = new FileInfo(uploadedFile);
                        fileType = objFileInfo.Extension; 
                        fileType = fileType.Replace(".", "").ToLower();
                        objDocInfo.Extension = fileType;
                        objDocInfo.Size = documentSize.ToString();
                        if (!Directory.Exists(documentSavePath))
                        {
                            Directory.CreateDirectory(documentSavePath);
                        }
                        string documentPath = documentSavePath + uploadedFile;
                        string saveFilePath = uploadPath + uploadedFile;
                        objDocInfo.DocumentPath = saveFilePath;                        
                        if (isAllowMultipleCategory)
                        {
                            isFormValid = true;
                            fluDocumentPath.SaveAs(documentPath);
                        }
                        else
                        {
                            int CategoryID = Int32.Parse(finalCategoryIDs);
                            CategoryInfo objCategoryInfo = con.GetCategoryInfoById(CategoryID, UserModuleID, GetPortalID);
                            long CategoryAllowSize = long.Parse(objCategoryInfo.AllowedDocumentSize);
                            string strSuportedExtension = objCategoryInfo.SupportedExtension;
                            hdnSelectedCategoryExtension.Value = objCategoryInfo.SupportedExtension;
                            if (CategoryAllowSize == 0 && strSuportedExtension == "")
                            {
                                fluDocumentPath.SaveAs(documentPath);
                                isFormValid = true;
                            }
                            else
                            {
                                if (documentSize <= CategoryAllowSize)
                                {
                                    if (strSuportedExtension.Contains(fileType))
                                    {
                                        fluDocumentPath.SaveAs(documentPath);
                                        isFormValid = true;
                                    }
                                    else
                                    {
                                        ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "CategoryDocumentExtension"), "", SageMessageType.Alert);
                                        
                                    }
                                }
                                else
                                {
                                    ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "CategoryDocumentSize"), "", SageMessageType.Alert);
                                }
                            }
                        }
                    }
                    else 
                    {
                        objDocInfo.DocumentPath = hdnDocumentPath.Value;
                        objDocInfo.Extension = hdnDocumentExtension.Value;
                        objDocInfo.Size = hdnDocumentSize.Value;
                        con.GetDocumentAddUpdate(objDocInfo, UserModuleID, GetPortalID, GetUsername, finalCategoryIDs, finalStringRoles, finalStringUsers);
                        ManageCategory(Int32.Parse(hdfCategoryID.Value));
                        ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "DataSavedSuccessfully"), "", SageMessageType.Success);
                        if (Int32.Parse(hdfCategoryID.Value) == 0)
                        {
                            DivVisibility(false, false, true, false, false);
                        }
                        else
                        {
                            DivVisibility(false, false, false, true, false);
                        }
                        ClearAll();
                    }
                    if (isFormValid)
                    {
                        
                        con.GetDocumentAddUpdate(objDocInfo, UserModuleID, GetPortalID, GetUsername, finalCategoryIDs, finalStringRoles, finalStringUsers);

                        ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "DataSavedSuccessfully"), "", SageMessageType.Success);
                        if (Int32.Parse(hdfCategoryID.Value)==0)
                        {
                            DivVisibility(false, false, true, false, false);
                        }
                        else
                        {
                            
                            ManageCategory(Int32.Parse(hdfCategoryID.Value));
                            DivVisibility(false, false, false, true, false);
                        }
                        ClearAll();
                    }
                }
                else
                {
                    ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "ChooseDocument"), "", SageMessageType.Alert); 
                }
            }
            else
            {
                ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "ChooseCategory"), "", SageMessageType.Alert);
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void EditDocument(int ID)
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            DocumentLibraryController con = new DocumentLibraryController();
            DocumentInfo objDocInfo = con.GetDocumentInfoById(ID, UserModuleID, GetPortalID);
            txtDocumentName.Text = objDocInfo.Name;
            txtDocumentDescription.Text = objDocInfo.Description;
            txtVersion.Text = objDocInfo.Version;
            txtDisplayOrder.Text = objDocInfo.DisplayOrder.ToString();
            hdnDocumentID.Value = ID.ToString();
            hdnDocumentPath.Value = objDocInfo.DocumentPath;
            hdnDocumentExtension.Value = objDocInfo.Extension;
            hdnDocumentSize.Value = objDocInfo.Size;
            iaFrmDocumentEdit.Value = "1";
            SelectSuperRoles();
            DivVisibility(false,true,false,false,false);        
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void DeleteDocument(int ID)
    {
        try
        {
             int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            DocumentLibraryController con = new DocumentLibraryController();
            con.DeleteDocumentByID(ID, UserModuleID, GetPortalID,GetUsername);
            ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "DataDeletedSuccessfully"), "", SageMessageType.Success);
            ManageCategory(Int32.Parse(hdfCategoryID.Value));
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void SaveCategory()
    {
        try
        {
            SelectSuperRoles();
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
           long fileSize=0;
            DocumentLibraryController con = new DocumentLibraryController();
            CategoryInfo objCatInfo = new CategoryInfo();
            objCatInfo.Title = txtCategoryTitle.Text.Trim();
            objCatInfo.Description = txtCategoryDescription.Text.Trim();
            objCatInfo.IconAlternateText = txtIconAlternateText.Text.Trim();  
            if (isAllowMultipleCategory)
            {
                objCatInfo.AllowedDocumentSize = "0";
                objCatInfo.SupportedExtension = "";
            }
            else
            {
                objCatInfo.AllowedDocumentSize = txtAllowedDocumentSize.Text.Trim();
                objCatInfo.SupportedExtension = txtSupportedExtension.Text.Trim();
            }
            ArrayList arrRoles = new ArrayList();
            for (int i = 0; i < lstCategoryRoleAccess.Items.Count; i++)
            {
                if (lstCategoryRoleAccess.Items[i].Selected)
                {
                    arrRoles.Add(lstCategoryRoleAccess.Items[i].Value);
                }
            }
            arrRoles.Add(superUser);
            arrRoles.Add(siteAdmin);
            string[] strRoles = new string[arrRoles.Count];
            arrRoles.CopyTo(strRoles);
            string finalStringRoles = string.Join("#", strRoles);
            ArrayList arrUsers = new ArrayList();
            for (int i = 0; i < lstCategoryUserAccess.Items.Count; i++)
            {
                if (lstCategoryUserAccess.Items[i].Selected)
                {
                    arrUsers.Add(lstCategoryUserAccess.Items[i].Value);
                }
            }
            string[] strUsers = new string[arrUsers.Count];
            arrUsers.CopyTo(strUsers);
            string finalStringUsers = string.Join("#", strUsers);
            bool isShowCategoryIcon=bool.Parse(GetSettingsByKey(DocumentLibrarySettings.ShowCategoryIcon));
            if (isShowCategoryIcon)
            {
                if (fluCategoryIcon.HasFile || Int32.Parse(hdnCategoryID.Value) > 0)
                {

                    if (Int32.Parse(hdnCategoryID.Value) > 0)
                    {
                        objCatInfo.CategoryID = Int32.Parse(hdnCategoryID.Value);
                    }
                    else
                    {
                        objCatInfo.CategoryID = 0;
                    }
                    if (fluCategoryIcon.HasFile)
                    {
                        string categoryIconExtensionSettings = GetSettingsByKey(DocumentLibrarySettings.CategoryIconExtension);
                        long CategoryIconSizeSettings = long.Parse(GetSettingsByKey(DocumentLibrarySettings.CategoryIconMaxsize));
                        string uploadedImage = fluCategoryIcon.PostedFile.FileName;
                        string uploadPath = "~\\Modules\\DocumentLibrary\\CategoryIcons\\Thumbnails\\";
                        string ThumbnailPath = Server.MapPath("~/Modules/DocumentLibrary/CategoryIcons/Thumbnails/");
                        if (!Directory.Exists(ThumbnailPath))
                        {
                            Directory.CreateDirectory(ThumbnailPath);
                        }
                        FileInfo objFileInfo = new FileInfo(uploadedImage);
                        string fileType = objFileInfo.Extension.ToLower();
                        fileType = fileType.Replace(".", "");
                        fileSize = fluCategoryIcon.PostedFile.ContentLength;
                        if (categoryIconExtensionSettings.Contains(fileType))
                        {
                            if (fileSize <= CategoryIconSizeSettings)
                            {
                                string virtualPath = "~/Modules/DocumentLibrary/CategoryIcons/";
                                string IconPath = Server.MapPath(virtualPath);
                                if (!Directory.Exists(IconPath))
                                {
                                    Directory.CreateDirectory(IconPath);
                                }
                                int ThumbnailSize = Int32.Parse(GetSettingsByKey(DocumentLibrarySettings.CategoryIconThumbnailSize));
                                string actualIconPath = IconPath + uploadedImage;
                                fluCategoryIcon.SaveAs(actualIconPath);
                                SaveThumbnailImages(actualIconPath, ThumbnailSize, ThumbnailPath, uploadedImage);
                                string saveFilePath = uploadPath + uploadedImage;
                                objCatInfo.CategoryIcon = saveFilePath;
                                con.GetCategoryAddUpdate(objCatInfo, UserModuleID, GetPortalID, GetUsername, finalStringRoles, finalStringUsers);
                                LoadAllCategoryContent();
                                ShowMessage(SageMessageTitle.Information.ToString(), "Data Saved Successfully!!", "", SageMessageType.Success);
                                DivVisibility(false, false, true, false, false);
                                ClearAll();
                            }
                            else
                            {
                                ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "CategoryIconSize"), "", SageMessageType.Alert);
                            }
                        }
                        else
                        {
                            ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "CategoryIconExtension"), "", SageMessageType.Alert);
                        }
                    }
                    else
                    {

                        objCatInfo.CategoryIcon = hdnCategoryPath.Value;
                        con.GetCategoryAddUpdate(objCatInfo, UserModuleID, GetPortalID, GetUsername, finalStringRoles, finalStringUsers);
                        ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "DataSavedSuccessfully"), "", SageMessageType.Success);
                        LoadAllCategoryContent();
                        DivVisibility(false, false, true, false, false);
                        ClearAll();
                    }
                }
                else
                {
                    ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "ChooseCategoryIcon"), "", SageMessageType.Alert);
                }
            }
            else
            {
                if (Int32.Parse(hdnCategoryID.Value) > 0)
                {
                    objCatInfo.CategoryID = Int32.Parse(hdnCategoryID.Value);
                }
                else
                {
                    objCatInfo.CategoryID = 0;
                }
                objCatInfo.IconAlternateText = "No-image";
                objCatInfo.CategoryIcon = "~\\Modules\\DocumentLibrary\\ImageFiles\\no-image.jpg";
                con.GetCategoryAddUpdate(objCatInfo, UserModuleID, GetPortalID, GetUsername, finalStringRoles, finalStringUsers);
                ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/DocumentLibrary/ModuleLocalText", "DataSavedSuccessfully"), "", SageMessageType.Success);
                LoadAllCategoryContent();
                DivVisibility(false, false, true, false, false);
                ClearAll();


            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    public void SaveThumbnailImages(string ImageFilePath, int TargetSize, string TargetLocation, string fileName)
    {
        try
        {
            if (!Directory.Exists(TargetLocation))
            {
                Directory.CreateDirectory(TargetLocation);
            }
            string SavePath = string.Empty;
            SavePath = TargetLocation + fileName;
            PictureManager.CreateThmnail(ImageFilePath, TargetSize, SavePath);
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    public string GeDocumentLibraryImageUrl(string imageName, bool isServerControl)
    {
        string path = string.Empty;
        if (isServerControl == true)
        {
            path = "~/Modules/DocumentLibrary/ImageFiles/" + imageName;
        }
        else
        {
            path = this.Page.ResolveUrl("~/Modules/DocumentLibrary/ImageFiles/" + imageName);
        }
        return path;
    }

    protected void imbAddNewDocument_Click(object sender, ImageClickEventArgs e)
    {
        lstCategoryUserAccess.ClearSelection();
        lstDocumentRolePermission.ClearSelection();
        lstDocumentRolePermission.ClearSelection();
        SelectSuperRoles();
        LoadAllCategory();
        DivVisibility(false,true,false,false,false);
    }

    protected void imbAddNewCategory_Click(object sender, ImageClickEventArgs e)
    {
        lstCategoryRoleAccess.ClearSelection();
        lstCategoryUserAccess.ClearSelection();
        SelectSuperRoles();
        LoadAllCategory();
        DivVisibility(true,false,false,false,false);
        ClearAll();        
    }

    protected void imbSaveCategory_Click(object sender, ImageClickEventArgs e)
    {
        SaveCategory();
    }

    protected void imbSaveDocument_Click(object sender, ImageClickEventArgs e)
    {
        SaveDocument();
    }

    protected void imbCancelCategory_Click(object sender, ImageClickEventArgs e)
    {
       
        DivVisibility(false, false, true, false, false);
        ClearAll();
        LoadAllCategoryContent();
    }

    protected void imbCancelDocument_Click(object sender, ImageClickEventArgs e)
    {
        if (int.Parse(hdnDocumentID.Value) >0)
        {
            ClearAll();
            DivVisibility(false, false, false, true, false);
        }
        else
        {
            ClearAll();
            DivVisibility(false,false,true,false,false);
        }
    }

    protected void rptShowCategory_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        int ID = Int32.Parse(e.CommandArgument.ToString());
        switch (e.CommandName)
        {
            case "Edit":
                EditCategory(ID);
                break;
            case "Delete":
                DeleteCategory(ID);
                break;
            case "Manage":
                ManageCategory(ID);
                break;

        }

    }

    protected void rptShowDocument_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        int ID = Int32.Parse(e.CommandArgument.ToString());
        switch (e.CommandName)
        {
            case "Edit":
                EditDocument(ID);
                break;
            case "Delete":
                DeleteDocument(ID);
                break;
        }
    }

    protected void rptShowCategory_ItemDataBound(object source, RepeaterItemEventArgs e)
    {
        //if (e.Item.ItemType == ListItemType.Header)
        //{
        //    HtmlTableCell tdHeaderSupportExtension = (HtmlTableCell)e.Item.FindControl("tdHeaderSupportExtension");
        //    HtmlTableCell tdHeaderDocumentSize = (HtmlTableCell)e.Item.FindControl("tdHeaderDocumentSize");
        //    if (true)
        //    {
        //        //tdHeaderSupportExtension.Visible = false;
        //       // tdHeaderDocumentSize.Visible = false;
        //    }
        //}
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            ImageButton imbEdit = (ImageButton)e.Item.FindControl("imbCategoryEdit");
            imbEdit.ImageUrl = GetTemplateImageUrl("imgedit.png", true);
            ImageButton imbDelete = (ImageButton)e.Item.FindControl("imbCategoryDelete");
            imbDelete.ImageUrl = GetTemplateImageUrl("imgdelete.png", true);
            imbDelete.Attributes.Add("onclick", "return confirm('Are you sure?');");
            ImageButton imbManage = (ImageButton)e.Item.FindControl("imbCategoryManage");
            imbManage.ImageUrl = GeDocumentLibraryImageUrl("imgmanage.png", true);
            HtmlTableCell tdItemSupportExtension = (HtmlTableCell)e.Item.FindControl("tdItemSupportExtension");
            HtmlTableCell tdItemDocumentSize = (HtmlTableCell)e.Item.FindControl("tdItemDocumentSize");
            //if (true)
            //{
            //    tdItemSupportExtension.Visible = false;
            //    tdItemDocumentSize.Visible = false;
            //}
            }
        }
   
    protected void rptShowDocument_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            ImageButton imbEdit = (ImageButton)e.Item.FindControl("imbDocumentEdit");
            imbEdit.ImageUrl = GetTemplateImageUrl("imgedit.png", true);
            ImageButton imbDelete = (ImageButton)e.Item.FindControl("imbDocumentDelete");
            imbDelete.ImageUrl = GetTemplateImageUrl("imgdelete.png", true);
            imbDelete.Attributes.Add("onclick", "return confirm('Are you sure?');");
        }
    }

    protected void imbBackToCategory_Click(object sender, ImageClickEventArgs e)
    {
        DivVisibility(false, false, true, false, false);
    }

    protected void imbReturnBackToCategory_Click(object sender, ImageClickEventArgs e)
    {
        DivVisibility(false, false, true, false, false);
        divBackToCategory.Visible = false;
    }
}
