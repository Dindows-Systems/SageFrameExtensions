﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SageFrame.SocialLink.Entities;
using SageFrame.Web.Utilities;

namespace SageFrame.SocialLink.SqldataProvider
{
    public class SocialLinkDataProvider
    {
        public void ModifyLink(SocialLinkInfo objSocialLink)
        {
            try
            {
                List<KeyValuePair<string, object>> ParaMeterCollection = new List<KeyValuePair<string, object>>();
                ParaMeterCollection.Add(new KeyValuePair<string, object>("@linkID", objSocialLink.LinkID));
                ParaMeterCollection.Add(new KeyValuePair<string, object>("@link", objSocialLink.Link));
                ParaMeterCollection.Add(new KeyValuePair<string, object>("@type", objSocialLink.Type));
                ParaMeterCollection.Add(new KeyValuePair<string, object>("@userName", objSocialLink.UserName));
                ParaMeterCollection.Add(new KeyValuePair<string, object>("@portalID", objSocialLink.PortalID));
                ParaMeterCollection.Add(new KeyValuePair<string, object>("@userModuleID", objSocialLink.UserModuleID));
                SQLHandler sagesql = new SQLHandler();
                sagesql.ExecuteNonQuery("dbo.usp_SocialLinkModify", ParaMeterCollection);
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        public List<SocialLinkInfo> GetLinks(SocialLinkInfo objSocialLink)
        {
            List<KeyValuePair<string, object>> ParaMeterCollection = new List<KeyValuePair<string, object>>();
            ParaMeterCollection.Add(new KeyValuePair<string, object>("@userName", objSocialLink.UserName));
            ParaMeterCollection.Add(new KeyValuePair<string, object>("@portalID", objSocialLink.PortalID));
            ParaMeterCollection.Add(new KeyValuePair<string, object>("@userModuleID", objSocialLink.UserModuleID));
            List<SocialLinkInfo> objLinkList = new List<SocialLinkInfo>();
            SQLHandler sagesql = new SQLHandler();
            try
            {
                objLinkList = sagesql.ExecuteAsList<SocialLinkInfo>("dbo.usp_SocialLinkSelect", ParaMeterCollection);
            }
            catch (Exception e)
            {
                throw e;
            }
            return objLinkList;
        }
        public void DeleteLink(SocialLinkInfo objSocialLink)
        {
            try
            {
                List<KeyValuePair<string, object>> ParaMeterCollection = new List<KeyValuePair<string, object>>();
                ParaMeterCollection.Add(new KeyValuePair<string, object>("@linkID", objSocialLink.LinkID));
                SQLHandler sagesql = new SQLHandler();
                sagesql.ExecuteNonQuery("dbo.usp_SocialLinkDelete", ParaMeterCollection);
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
