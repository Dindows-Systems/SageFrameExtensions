﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SageFrame.SocialLink.Entities
{
    public class SocialLinkInfo
    {
        public int LinkID { get; set; }
        public string Link { get; set; }
        public string Type { get; set; }
        public string UserName { get; set; }
        public int PortalID { get; set; }
        public int UserModuleID { get; set; }
    }
}
