﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SageFrame.SocialLink.Entities;
using SageFrame.SocialLink.SqldataProvider;

namespace SageFrame.SocialLink.Controller
{
    public class SocialLinkController
    {
        public void ModifyLink(SocialLinkInfo objSocialLink)
        {
            SocialLinkDataProvider objDataProvider = new SocialLinkDataProvider();
            objDataProvider.ModifyLink(objSocialLink);
        }
        public List<SocialLinkInfo> GetLinks(SocialLinkInfo objSocialLink)
        {
            SocialLinkDataProvider objDataProvider = new SocialLinkDataProvider();
            return objDataProvider.GetLinks(objSocialLink);
        }
        public void DeleteLink(SocialLinkInfo objSocialLink)
        {
            SocialLinkDataProvider objDataProvider = new SocialLinkDataProvider();
            objDataProvider.DeleteLink(objSocialLink);
        }
    }
}
