﻿$(function() {
    GetCategoryAll();
    $('ul.drawers').accordion({
        header: 'H2.drawer-handle',
        selectedClass: 'open',
        event: 'mouseover'
    });
    $('LI.drawer UL:first').addClass('open');
    $(".fileDownloadCustomRichExperience").jDownload({
        root: sagefilePath,
        dialogTitle: 'File download window:'
    });
});
var html = '';
function GetCategoryAll() {
    $.ajax({
        type: "POST",
        url: DownloadServiceURl + "GetAllCategory",
        data: JSON2.stringify({ userModuleID: UserModuleID, portalID: PortalID }),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function(data) {
            if (data.d == null || data.d == "") {
                html += "No document found";
            }
            else {
                $.each(data.d, function(index, value) {
                    html += '<li class="drawer">';
                    html += '<h2 class="drawer-handle">' + value.Name + '</h2>';
                    var categoryId = value.CategoryID;
                    getDocumentForThisCategory(categoryId);
                    html += '</li>';
                });
            }


           $("#documentlist").html(html);

        },
        error: function() {
        }
    });

}

function getDocumentForThisCategory(CategoryId) {
    $.ajax({
        type: "POST",
        url: DownloadServiceURl + "GetDocumentsByCategory",
        data: JSON2.stringify({ CategoryID: CategoryId }),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function(data) {
            if (data.d == null || data.d == "") {
                html += '<label>No document added yet for this category</label>';
            }
            else {
                html += '<ul>';
                $.each(data.d, function(index, value) {

                    html += '<li><label class="sfDocumentname">' + value.Name + '</label><a class="fileDownloadCustomRichExperience" href="uploads/document/' + value.DocumentPath + '" ><img src="' + resolvedURL + 'Modules/DocumentDownload/images/download.png"  alt="download"/></a></li>';
                });
                html += '</ul>';
            }
        },
        error: function() {
        }
    });




}