﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;

public partial class Modules_DocumentDownload_DocumentDownloadEdit : BaseAdministrationUserControl
{
    public string basePath = "";
    public int UserModuleID = 0;
    public int PortalID = 0;
    public string resolvedURL = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        basePath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
        string modulePath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DocumentDownloadGlobalVariable", " var DocumentUploadPath='" + ResolveUrl(modulePath) + "';", true);
        UserModuleID = Int32.Parse(SageUserModuleID);
        PortalID = GetPortalID;
        this.resolvedURL = ResolveUrl("~/");
        if (!IsPostBack)
        {
            IncludeJsFile();
            IncludeCss("document", "/Modules/DocumentDownload/css/module.css");
        }
    }
    private void IncludeJsFile()
    {
        IncludeJs("DocumentEdit", false, "/Modules/DocumentDownload/js/ajaxupload.js");
        //IncludeJs("validation", false, "/js/jquery.validate.js");
    }
}
