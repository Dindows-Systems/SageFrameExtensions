﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.DocumentDownload;
using System.Web.Services;
using System.IO;
public partial class Modules_DocumentDownload_DocumentDownloadView : BaseAdministrationUserControl
{
    public string serviceURL = "";
    public int UserModuleID, PortalID;
    public string resolvedURL = "";
    public string basePath = "";
    public string sagefilePath = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        sagefilePath = ResolveUrl("~") + "Modules/DocumentDownload/";
        serviceURL = ResolveUrl(this.AppRelativeTemplateSourceDirectory) + "Services/DocumentWebservice.asmx/";
        IncludeCss("document", "/Modules/DocumentDownload/css/module.css");
        IncludeJs("download", "/Modules/DocumentDownload/js/jquery.jdownload.js");
        IncludeJs("docu", "/Modules/DocumentDownload/js/DocumentDownload.js");
        IncludeJs("accordian2", "/Modules/DocumentDownload/js/jquery.accordian.js");

        UserModuleID = Int32.Parse(SageUserModuleID);
        PortalID = GetPortalID;
        this.resolvedURL = ResolveUrl("~/");
        basePath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
    }

   


}
