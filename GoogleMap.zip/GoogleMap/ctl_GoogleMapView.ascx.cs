﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using System.Text;
using System.Data;
using GoogleMapProvider;

public partial class Modules_GoogleMap_ctl_GoogleMapView : BaseUserControl
{
    public string MapScripts = string.Empty;
    public string strFileurl = string.Empty;
    public string GivenAddress = string.Empty;
    public string AddressInfos = string.Empty;

    public bool ShowZoomControls = true;
    public bool ShowMapTypeControls = true;
    public bool ShowInfoMarker = true;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string UserModuleID = SageUserModuleID;

            GoogleMapProcedures gm = new GoogleMapProcedures();
            DataTable dtSettingVlaues = gm.GetAllGoogleMapSettings(UserModuleID, GetPortalID.ToString());

            foreach (DataRow row in dtSettingVlaues.Rows)
            {
                switch (row["SettingKey"].ToString())
                {
                    case "GoogleMapAPIKey":
                        SetGoogleMapScriptFile(row["SettingValue"].ToString());
                        break;
                    case "Adresses":
                        SetAddress(row["SettingValue"].ToString());
                        break;
                    case "AddressInfo":
                        SetAddressInfo(row["SettingValue"].ToString());
                        break;
                    case "ShowZoomControls":
                        SetZoomControls(row["SettingValue"].ToString());
                        break;
                    case "ShowMapTypeControls":
                        SetMapTypeControls(row["SettingValue"].ToString());
                        break;
                    case "ShowInfoMarker":
                        SetInfoMarker(row["SettingValue"].ToString());
                        break;
                }
            }
        }
    }

    private void SetInfoMarker(string isInfoMarkerShown)
    {
        ShowInfoMarker = bool.Parse(isInfoMarkerShown);
    }

    private void SetMapTypeControls(string isMapTypeControlsShown)
    {
        ShowMapTypeControls = bool.Parse(isMapTypeControlsShown);
    }

    private void SetZoomControls(string isZoomControlsShown)
    {
        ShowZoomControls = bool.Parse(isZoomControlsShown);
    }

    private void SetAddress(string givenAddress)
    {
        GivenAddress = givenAddress;

    }

    private void SetAddressInfo(string givenAddressInfo)
    {
        AddressInfos = givenAddressInfo;
    }

    private void SetGoogleMapScriptFile(string googleMapAPIKey)
    {
        string KeyForGoogleMap = googleMapAPIKey;
        strFileurl = "<script src=\"http://maps.google.com/maps?file=api&amp;v=2.x&amp;key=" + KeyForGoogleMap + "\" type=\"text/javascript\"></script>";
    }
}

