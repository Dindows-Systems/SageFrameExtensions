﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using SageFrame.Web;
using System.Data;
using SageFrame.Web.Utilities;
using GoogleMapProvider;


    public partial class Modules_GoogleMap_ctl_GoogleMapSetting : BaseUserControl
    {
        string UserModuleID = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                UserModuleID = SageUserModuleID;
                if (!Page.IsPostBack)
                {
                    LoadGoogleMapSettingstoControl();
                    imbSaveGoogleMapSetting.ImageUrl = GetTemplateImageUrl("imgsave.png", true);
                }
            }
            catch (Exception ex)
            {
                ProcessException(ex);
            }
        }

        private void LoadGoogleMapSettingstoControl()
        {            
            GoogleMapProcedures gm = new GoogleMapProcedures();
            DataTable dtSettingVlaues = gm.GetAllGoogleMapSettings(UserModuleID, GetPortalID.ToString());
            foreach (DataRow row in dtSettingVlaues.Rows)
            {
                switch (row["SettingKey"].ToString())
                {
                    case "GoogleMapAPIKey":
                        txtGoogleMapAPIKey.Text = row["SettingValue"].ToString();
                        break;
                    case "Adresses":
                        txtAddresses.Text = row["SettingValue"].ToString();
                        break;
                    case "AddressInfo":
                        txtAddressesInfo.Text = row["SettingValue"].ToString();
                        break;
                    case "ShowZoomControls":
                        chkShowZoomControls.Checked = bool.Parse(row["SettingValue"].ToString());
                        break;
                    case "ShowMapTypeControls":
                        chkShowMapTypeControls.Checked = bool.Parse(row["SettingValue"].ToString());
                        break;
                    case "ShowInfoMarker":
                        chkShowInfoMarker.Checked = bool.Parse(row["SettingValue"].ToString());
                        break;
                }
            }
        }

        private void SaveSetting(string key, string value)
        {
            try
            {
                GoogleMapProcedures gm = new GoogleMapProcedures();
                gm.GoogleMapSettingsAddUpdate(UserModuleID, key, value, "1", GetPortalID.ToString(), GetUsername);
            }
            catch (Exception ex)
            {
                ProcessException(ex);
            }
        }

        protected void imbSaveGoogleMapSetting_Click(object sender, ImageClickEventArgs e)
        {            
                SaveSetting("GoogleMapAPIKey", txtGoogleMapAPIKey.Text);
                SaveSetting("Adresses", txtAddresses.Text);
                SaveSetting("AddressInfo", txtAddressesInfo.Text);
                SaveSetting("ShowZoomControls", chkShowZoomControls.Checked.ToString());
                SaveSetting("ShowMapTypeControls", chkShowMapTypeControls.Checked.ToString());
                SaveSetting("ShowInfoMarker", chkShowInfoMarker.Checked.ToString());
                ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/GoogleMap/ModuleLocalText", "SettingUpdatedSuccessfully"), "", SageMessageType.Success);
        }
    }

   

