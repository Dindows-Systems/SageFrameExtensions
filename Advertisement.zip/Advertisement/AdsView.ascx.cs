﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Advertisement.Controller;
using SageFrame.Web;
using System.IO;
using SageFrame.Web.Utilities;
using SageFrame.Advertisement.Entity;
using SageFrame.Modules;
using System.Data;
using SageFrame.Framework;
using SageFrame.Advertisement.Entity.setting;
using SageFrame.Advertisement.DataProvider;
using System.Text;

public partial class Modules_Advertisement_AdsView : BaseAdministrationUserControl
{
    public string IpAddres;
    public string Country;
    public string username;
    public string AdsHeight;
    public string AdsWidth;
    public string Viewtype;
    public Int32 UserModuleID = 0;
    public string swfFileName = "";
    public int PortalID = 0;
    public string NumberOfAds;
    public string IsDimension;
    public string AdsListType;
    public string AdsNextLineAfter;
    public string modulePath = "";
    public string SageURL = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            SageURL = string.Format("{0}{1}", Request.ApplicationPath == "/" ? "" : Request.ApplicationPath,SageURL);
            modulePath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "globalVariables", " var ServicePath='" + ResolveUrl(modulePath) + "';", true);
            if (!IsPostBack)
            {
               
                IncludeCss();
        
                GetAllVariable();
                GenerateDynamicContainer();
            }
			 UserModuleID = Int32.Parse(SageUserModuleID);
             PortalID = GetPortalID;
			 GetSetting();


            IncludeJs();
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    public void GenerateDynamicContainer()
    {
        int UserModID = int.Parse(SageUserModuleID);
        StringBuilder sb = new StringBuilder();
        string divId = "ulADs_" + UserModID;
        sb.Append("<ul id='"+divId+"'></ul>");
        ltrAdvertisement.Text = sb.ToString();
    }

    private void GetAllVariable()
    {
        IpAddres = System.Web.HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
        if (IpAddres == null)
        {
            IpAddres = System.Web.HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
        }
        IPAddressToCountryResolver obj = new IPAddressToCountryResolver();

        Convert.ToString(obj.GetCountry(IpAddres, out Country));
        username = GetUsername;
    }

    public void IncludeCss()
    {
           IncludeCss("Advertisement", "/Modules/Advertisement/Module.css");


    }
    private void IncludeJs()
    {

        Page.ClientScript.RegisterClientScriptInclude("JQuery_ADs", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/js/json2.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQuery_Advertisement", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/js/jsAdvertisement.js"));


    }



    #region Setting
    public void GetSetting()
    {
        try
        {
            AdsSettingInfo obj = GetAdsSettingList(GetPortalID, Int32.Parse(SageUserModuleID));
            AdsWidth = obj.AdsWidth;
            AdsHeight = obj.AdsHeight;
            Viewtype = obj.ViewType;
            NumberOfAds = obj.NumberOfAds;
            IsDimension = obj.IsDimension;
            AdsListType = obj.ListType;
            AdsNextLineAfter = obj.AdsNextLineAfter;
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }

    }

    public AdsSettingInfo GetAdsSettingList(int PortalID, int UserModuleID)
    {
        AdsDataProvider obj = new AdsDataProvider();
        return obj.GetAdsSettingList(PortalID, UserModuleID);
    }

    #endregion



}
