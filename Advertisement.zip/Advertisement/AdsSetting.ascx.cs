﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.Advertisement.Controller;
using SageFrame.Advertisement.Entity;
using SageFrame.Advertisement.DataProvider;
using SageFrame.Advertisement.Entity.setting;
using SageFrame.Web.Utilities;

public partial class Modules_Advertisement_AdsSetting : BaseAdministrationUserControl
{
    public string AdsWidth = "";
    public string AdsHeight = "";
    public string Viewtype = "";
    public string IsDimension = "";
    public string ListType = "";
    public string SaveImageURL = "";
    public string modulePath = "";
    public int UserModuleId;
    public string Username = "";
    public int PortalID;
    public string NumberOfAdsToShow;
    public string NextLineAfter;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
			 modulePath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
               Username = GetUsername;
			 UserModuleId = Int32.Parse(SageUserModuleID);
			 PortalID = GetPortalID;
			GetSetting();
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }

    }


    public void GetSetting()
    {
        try
        {
            AdsSettingInfo obj = GetAdsSettingList(GetPortalID, Int32.Parse(SageUserModuleID));
            AdsWidth = obj.AdsWidth;
            AdsHeight = obj.AdsHeight;
            Viewtype = obj.ViewType;
            IsDimension = obj.IsDimension;
            ListType = obj.ListType;
            NextLineAfter = obj.AdsNextLineAfter;
            NumberOfAdsToShow = obj.NumberOfAds;


            
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }

    }


    public AdsSettingInfo GetAdsSettingList(int PortalID, int UserModuleID)
    {
        AdsDataProvider objc = new AdsDataProvider();
        return objc.GetAdsSettingList(PortalID, UserModuleID);

    }

   


    
}
