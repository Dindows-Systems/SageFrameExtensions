﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.Advertisement.Controller;
using SageFrame.Advertisement.Entity;
using System.IO;
using SageFrame.Advertisement.DataProvider;
using System.Data;
using SageFrame.Web.Utilities;
using System.Drawing;
using System.Drawing.Drawing2D;


public partial class Modules_Advertisement_AdsEdit : BaseAdministrationUserControl
{
    public string swfExt = "";
    public Int32 UserModuleID = 0;
    public string swfFileName = "";
    public string modulePath = "";
    public int Numberclicked;
    public int Numbershown;
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            modulePath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "globalVariables", " var ImagePath='" + ResolveUrl(modulePath) + "';", true);
            if (!IsPostBack)
            {
                PanelVisibility(true, false);
                ImageURL();
                IncludeCss();
                LoadAdsOnGrid();
                LoadSagePage();
            }

        }
        catch (Exception ex)
        {
            ProcessException(ex);

        }
    }


    private void PanelVisibility(bool BannerInGrid, bool BannerForm)
    {
        pnlGridForAds.Visible = BannerInGrid;
        pnlAdsEditForm.Visible = BannerForm;
    }


    private void ImageURL()
    {
        try
        {
            btnSave.ImageUrl = GetTemplateImageUrl("btnsave.png", true);
            ibAdd.ImageUrl = GetTemplateImageUrl("imgadd.png", true);
            imgCancelReportView.ImageUrl = GetTemplateImageUrl("imgcancel.png", true);
            btnCancel.ImageUrl = GetTemplateImageUrl("imgcancel.png", true);
            btnSaveIsVisible.ImageUrl = GetTemplateImageUrl("btnsave.png", true);
            imgHistoryClear.ImageUrl = GetTemplateImageUrl("imgclearlog.png", true);
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }


    private void IncludeCss()
    {
        try
        {
            IncludeCss("Advertisement", "/Modules/Advertisement/Css/popup.css", "/Modules/Advertisement/Css/Module.css");           
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }


    public void ClearForm()
    {
        txtAdsName.Text = string.Empty;
        txtAdsStartDate.Text = string.Empty;
        txtDescription.Text = string.Empty;
        txtEmail.Text = string.Empty;
        txtWebsite.Text = string.Empty;
        txtAdsEndDate.Text = string.Empty;
        imgEditAdsImage.Visible = false;
    }




    public void LoadAdsOnGrid()
    {
        try
        {
    
            UserModuleID = int.Parse(SageUserModuleID);
            gvList.DataSource = AdsController.LoadAdsOnGrid(UserModuleID, GetPortalID);
            if (gvList.DataSource ==null)
            {
                divVisibleButton.Attributes.Add("style", "display:none");
                divPagedropdown.Attributes.Add("style","display:none");
            }
            gvList.DataBind();
			
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }


    #region Save Advertisement


    protected void btnSave_Click(object sender, EventArgs e)
    {
		if (rdbAdsType.SelectedValue == "0" && myUploadedFile.FileName == string.Empty && Session["Image"]==null )
		{
		ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/Advertisement/ModuleLocalText", "Pleaseuploadtheadvrtisefilefirst"), "", SageMessageType.Alert);
		}
		
		else{
        SaveAdvertisement();
        ClearForm();
        PanelVisibility(true, false);
		}

    }

    protected void SaveAdvertisement()
    {
        try
        {
		
	
            AdsInfo objInfo = new AdsInfo();

            if (Session["AdsID"] != null && Session["AdsID"].ToString() != string.Empty)
            {
                objInfo.AdsID = Int32.Parse(Session["AdsID"].ToString());
                Session.Contents.Remove("AdsID");
            }
            else
            {
                objInfo.AdsID = 0;
            }


            objInfo.AdsName = txtAdsName.Text;
            objInfo.AdsEmail = txtEmail.Text;
            if (txtWebsite.Text == "")
            {
                objInfo.AdsWebsite = "";
                objInfo.LinkedPage = ddlPagesLoad.SelectedValue;
            }
            else
            {
                objInfo.AdsWebsite = txtWebsite.Text;
                objInfo.LinkedPage = "";
            }
            objInfo.AdsDescription = txtDescription.Text;
            if (!string.IsNullOrEmpty(txtAdsStartDate.Text))
            {
                objInfo.AdsStartDate = Convert.ToDateTime(txtAdsStartDate.Text);
            }
            else
            {
                objInfo.AdsStartDate = CommonHelper.AvailableStartDateTime;
            }
            if (!string.IsNullOrEmpty(txtAdsEndDate.Text))
            {

                objInfo.AdsEndDate = Convert.ToDateTime(txtAdsEndDate.Text);
            }
            else
            {
                objInfo.AdsEndDate = CommonHelper.AvailableEndDateTime;
            }

            objInfo.IsVisible = "True";
            objInfo.UserModuleID = Int32.Parse(SageUserModuleID);
            objInfo.PortalID = GetPortalID;


            if (rdbAdsType.SelectedValue == "1")
            {
                objInfo.CustomAdvertisement = fckCustomAds.Text;
                objInfo.AdsImage = "";

            }
            else
            {
                if (myUploadedFile.FileName == string.Empty)
                {
			
                    objInfo.AdsImage = Session["Image"].ToString();
                    Session.Contents.Remove("Image");
                    swfExt = System.IO.Path.GetExtension(objInfo.AdsImage);
                }
                else
                {
                    objInfo.AdsImage = myUploadedFile.FileName;
                    swfExt = System.IO.Path.GetExtension(myUploadedFile.PostedFile.FileName);

                }

                if (swfExt == ".swf")
                {
                    if (myUploadedFile.FileContent.Length > 0)
                    {
                        string Path = GetUplaodImagePhysicalPath();
                        DirectoryInfo dirUploadImage = new DirectoryInfo(Path);
                        if (dirUploadImage.Exists == false)
                        {
                            dirUploadImage.Create();
                        }
                        string fileUrl = Path + myUploadedFile.PostedFile.FileName;
                        myUploadedFile.PostedFile.SaveAs(fileUrl);
                        swfFileName = Server.MapPath("~/Modules/Advertisement/falshObject/");
                        if (!Directory.Exists(swfFileName))
                        {
                            Directory.CreateDirectory(swfFileName);
                        }

                        if (myUploadedFile.HasFile)
                        {
                            myUploadedFile.SaveAs(System.IO.Path.Combine(swfFileName, myUploadedFile.FileName));

                        }

                    }

                }
                else
                {
                    string target = Server.MapPath("~/Modules/Advertisement/Upload");
                    if (!Directory.Exists(target))
                    {
                        Directory.CreateDirectory(target);
                    }
                    string thumbTarget = Server.MapPath("~/Modules/Advertisement/Upload/ThumbNail");
                    if (!Directory.Exists(thumbTarget))
                    {
                        Directory.CreateDirectory(thumbTarget);
                    }
                    System.Drawing.Image.GetThumbnailImageAbort thumbnailImageAbortDelegate = new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback);
                    if (myUploadedFile.HasFile)
                    {
                        myUploadedFile.SaveAs(System.IO.Path.Combine(target, myUploadedFile.FileName));
                        using (System.Drawing.Bitmap originalImage = new System.Drawing.Bitmap(myUploadedFile.PostedFile.InputStream))
                        {
                            using (System.Drawing.Image thumbnail = originalImage.GetThumbnailImage(80, 80, thumbnailImageAbortDelegate, IntPtr.Zero))
                            {
                                thumbnail.Save(System.IO.Path.Combine(thumbTarget, myUploadedFile.FileName));
                            }
                        }
                    }

                }
                objInfo.CustomAdvertisement = "";
            }
            objInfo.AdsDate = DateTime.Now;
            AdsController.SaveAdvertisement(objInfo);
            LoadAdsOnGrid();
            ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/Advertisement/ModuleLocalText", "SavedSuccessfully"), "", SageMessageType.Success);
			

        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    public bool ThumbnailCallback()
    {
        return false;
    }


    string GetUplaodImagePhysicalPath()
    {
        return System.Web.HttpContext.Current.Request.PhysicalApplicationPath + "Modules\\Advertisement\\image\\";
    }


    protected void btnPreview_Click(object sender, EventArgs e)
    {
    }
    #endregion

    #region GridViewResion

    protected void gvList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvList.PageIndex = e.NewPageIndex;
        LoadAdsOnGrid();

    }


    protected void gvList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int AdsID = Int32.Parse(e.CommandArgument.ToString());
        switch (e.CommandName.ToString())
        {
            case "Edit":
                Edit(AdsID);
                break;
            case "Delete":
                Delete(AdsID);
                break;
            case "ShowReport":
                pnlGridForAds.Visible = false;
                GetDetailsHistory(AdsID);
                break;

        }
    }


    public void Delete(int AdsID)
    {
        string FileName = GetFileName(AdsID);
        if (FileName != string.Empty)
        {
            DeleteImageFromFolder(FileName);
        }

        AdsController.DeleteAdsByID(AdsID);
        LoadAdsOnGrid();
        ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/Advertisement/ModuleLocalText", "DeletedSuccesfully"), "", SageMessageType.Success);
    }


    public string GetFileName(int AdsID)
    {
        AdsController objC = new AdsController();
        return objC.GetFileName(AdsID);


    }


    private void DeleteImageFromFolder(string FileName)
    {
        string extension = System.IO.Path.GetExtension(FileName);
        if (extension == ".swf")
        {
            string DeleteswfObject = Server.MapPath(modulePath + "flashObject/") + FileName;
            if (File.Exists(DeleteswfObject))
            {
                File.Delete(DeleteswfObject);
            }

        }
        else
        {
            string AdsImagePath = Server.MapPath(modulePath + "Upload/") + FileName;
            string ThumbnailAdsImagePath = Server.MapPath(modulePath + "Upload/ThumbNail/") + FileName;
            if (File.Exists(AdsImagePath))
            {
                File.Delete(AdsImagePath);
            }
            if (File.Exists(ThumbnailAdsImagePath))
            {
                File.Delete(ThumbnailAdsImagePath);
            }
        }
    }



    public void Edit(int AdsID)
    {
        PanelVisibility(false, true);
        imgEditAdsImage.Visible = true;
        AdsInfo objAdsInfo = AdsController.GetAdsInfoByID(AdsID);
        txtAdsName.Text = objAdsInfo.AdsName;
        txtEmail.Text = objAdsInfo.AdsEmail;
        txtWebsite.Text = objAdsInfo.AdsWebsite;
        txtDescription.Text = objAdsInfo.AdsDescription;
        txtAdsStartDate.Text = Convert.ToString(objAdsInfo.AdsStartDate);
        txtAdsEndDate.Text = Convert.ToString(objAdsInfo.AdsEndDate);
        if (objAdsInfo.AdsWebsite != string.Empty)
        {
            trddlPagesLoad.Attributes.Add("style", "display:none");
            trtxtWebUrl.Attributes.Add("style", "display:table-row");
            rdbReadMorePageType.SelectedValue = "1";
        }
        else if (objAdsInfo.LinkedPage != string.Empty)
        {
            rdbReadMorePageType.SelectedValue = "0";
            trddlPagesLoad.Attributes.Add("style", "display:table-row");
            trtxtWebUrl.Attributes.Add("style", "display:none");
            ddlPagesLoad.SelectedValue = objAdsInfo.LinkedPage;
        }
        if (objAdsInfo.AdsImage == "")
        {
            rdbAdsType.SelectedValue = "1";
            trCustomAds.Attributes.Add("style", "display:table-row");
            trImageAds.Attributes.Add("style", "display:none");
            fckCustomAds.Text = objAdsInfo.CustomAdvertisement;
        }
        else
        {
            rdbAdsType.SelectedValue = "0";
            trCustomAds.Attributes.Add("style", "display:none");
            trImageAds.Attributes.Add("style", "display:table-row");
            imgEditAdsImage.ImageUrl = modulePath + "Upload/ThumbNail/" + objAdsInfo.AdsImage;
            Session["Image"] = objAdsInfo.AdsImage;
        }

        Session["AdsID"] = AdsID; ;

    }


    public void GetDetailsHistory(int AdsID)
    {
        LoadAdsHistoryOngrid(AdsID);
        divAdsReport.Visible = true;

    }


    protected void gvList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            ImageButton imgBtn = e.Row.FindControl("imgDelete") as ImageButton;
            if (imgBtn != null)
            {
                imgBtn.Attributes.Add("onclick", "javascript:return " +
                    "confirm('Are you sure to delete?')");
            }
        }
    }



    protected void gvList_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }


    protected void gvList_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }





    protected void btnSaveIsVisible_Click(object sender, ImageClickEventArgs e)
    {
        foreach (GridViewRow grdRow in gvList.Rows)
        {
            int AdsId = 0;
            HiddenField hdfAdsID = grdRow.FindControl("hdfAdsID") as HiddenField;
            AdsId = Convert.ToInt32(hdfAdsID.Value);
            string isVisible = Convert.ToString(((CheckBox)grdRow.FindControl("chkHideShow")).Checked);
            AdsDataProvider objPro = new AdsDataProvider();
            objPro.SaveHideShow(AdsId, isVisible);
			
        }
		 ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/Advertisement/ModuleLocalText", "SavedSuccessfully"), "", SageMessageType.Success);

    }
    #endregion


    #region gdvAdsHistory


    public void LoadAdsHistoryOngrid(int AdsID)
    {
        
        gdvAdsReport.DataSource = AdsController.LoadAdsHistoryOngrid(AdsID);
        gdvAdsReport.DataBind();
        GetClickedRecord(AdsID);
        ViewState["AdsId"] = AdsID;
		
    }


    private void GetClickedRecord(int AdsID)
    {
        try
        {
            AdsInfo obji = GetClickedRecords(AdsID);
            Numberclicked = obji.NumberClicked;
            Numbershown = obji.NumberShown;
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }


    public AdsInfo GetClickedRecords(int AdsID)
    {
        AdsInfo Getsettin = new AdsInfo();
        try
        {

            List<KeyValuePair<string, object>> paramCol = new List<KeyValuePair<string, object>>();
            paramCol.Add(new KeyValuePair<string, object>("@AdsID", AdsID));
            SQLHandler sageSQL = new SQLHandler();
            Getsettin = sageSQL.ExecuteAsObject<AdsInfo>("[dbo].[usp_AdsvertisementGetClickedRecords]", paramCol);

        }

        catch (Exception ex)
        {
            ProcessException(ex);
        }

        return Getsettin;


    }


    protected void gdvAdsReport_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {

        gdvAdsReport.PageIndex = e.NewPageIndex;
        LoadAdsHistoryOngrid(Convert.ToInt32(ViewState["AdsId"]));
    }


    protected void ddlRecordsPerPage_SelectedIndexChanged(object sender, EventArgs e)
    {
        gdvAdsReport.PageSize = int.Parse(ddlRecordsPerPage.SelectedValue.ToString());
        LoadAdsHistoryOngrid(Convert.ToInt32(ViewState["AdsId"]));
    }


    protected void dddlShowRowsOfAdsPerPage_SelectedIndexChanged(object sender, EventArgs e)
    {
        gvList.PageSize = int.Parse(dddlShowRowsOfAdsPerPage.SelectedValue.ToString());
        LoadAdsOnGrid();
    }

    #endregion


    protected void ibAdd_Click(object sender, ImageClickEventArgs e)
    {
        ClearForm();
        PanelVisibility(false, true);
        Session.Contents.Remove("AdsID");
    }


    protected void gdvAdsReport_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }


    protected void imgCancelReportView_Click(object sender, ImageClickEventArgs e)
    {
        divAdsReport.Visible = false;
        pnlGridForAds.Visible = true;
    }


    protected void btnCancel_Click(object sender, ImageClickEventArgs e)
    {
        PanelVisibility(true, false);
    }


    private void LoadSagePage()
    {
        try
        {
            ddlPagesLoad.DataSource = AdsController.GetAllPagesOfSageFrame(GetPortalID); ;
            ddlPagesLoad.DataTextField = "TabPath";
            ddlPagesLoad.DataBind();
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }

    }


    protected void imgLogClear_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            ClearAdsHistory();
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }

    }


    private void ClearAdsHistory()
    {
        int Adsid = Convert.ToInt32(ViewState["AdsId"]);
        AdsController objC = new AdsController();
        objC.ClearAdsHistory(Adsid);
        LoadAdsHistoryOngrid(Adsid);
		ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/Advertisement/ModuleLocalText", "HistoryClearedSuccessfully"), "", SageMessageType.Success);

    }

}


