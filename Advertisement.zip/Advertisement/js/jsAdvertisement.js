﻿(function($) {
    $.createAdvertisementScript = function(p) {
        p = $.extend
        ({
            AdsHeight: '',
            AdsWidth: '',
            IPAddress: '192.168.3.10',
            CountryName: 'reserved',
            UserName: 'superuser',
            Viewtype: '',
            UsermoduleId: 1,
            PortalId: 1,
            NumberOfads: 2,
            AdsNextLineAfter: 1,
            AdsListType: '',
            baseURL: 'Services/Services.aspx/',
            Sageurl: '/sageframe'
        }, p);
        GetImageOnList();
        if (p.AdsListType == 'Horizontal') {
            $('#ulADs_' + p.UsermoduleId + '').attr('class', "cssClassHorizontal");
        }
        else {
            $('#ulADs_' + p.UsermoduleId + '').attr('class', "cssClassVertical");
        }
        function GetImageOnList() {
            $.ajax({
                type: "POST",
                url: p.baseURL + "Services/AdsModuleService.asmx/GetImageOnList",
                data: JSON2.stringify({ UserModuleID: p.UsermoduleId, PortalID: p.PortalId, NumberOfAds: p.NumberOfads, Viewtype: p.Viewtype }),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function(msg) {
                    var html = "";
                    var AdsCount = 0;
                    if (msg.d.length == 0) {
                        html += ('<div>No Advertise found</div>');
                    }
                    else {
                        $.each(msg.d, function(index, Data) {
                            AdsCount = AdsCount + 1;
                            if (Data.AdsImage.length == 0 || Data.CustomAdvertisement.length != 0) {
                                html += '<li id="' + Data.AdsID + '">' + Data.CustomAdvertisement + '</li>';
                            }
                            else {
                                var extension = Data.AdsImage.substr((Data.AdsImage.lastIndexOf('.') + 1));
                                SaveNumberOfTimeEachAdsShown(Data.AdsID);
                                if (extension == 'swf') {
                                    if (Data.LinkedPage == "") {
                                        html += ('<li><a id="' + Data.AdsID + ',' + Data.AdsWebsite + '" href="" ><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="" usemap=' + ServicePath + 'flashObject/' + Data.AdsImage + '><param name="movie" value="" />' +
                                '<param name="quality" value="high" /><embed src="' + p.baseURL + 'flashObject/' + Data.AdsImage + '"' + 'quality="high"' +
                                    'pluginspage="http://www.sageframe.com" type="application/x-shockwave-flash" height=\"' + p.AdsHeight + '\" width=\"' + p.AdsWidth + '\"/></embed></object></a></li>');
                                    }
                                    else {
                                        var f = "#";
                                        if (Data.LinkedPage != "") {
                                            f = Sageurl + Data.LinkedPage + ".aspx";
                                            html += ('<li><a id="' + Data.AdsID + ',' + f + '" href="" ><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="" usemap=' + ServicePath + 'flashObject/' + Data.AdsImage + '><param name="movie" value="" />' +
                                '<param name="quality" value="high" /><embed src="' + p.baseURL + 'flashObject/' + Data.AdsImage + '"' + 'quality="high"' +
                                    'pluginspage="http://www.sageframe.com" type="application/x-shockwave-flash" height=\"' + p.AdsHeight + '\" width=\"' + p.AdsWidth + '\"/></embed></object></a></li>');
                                        }
                                    }
                                }
                                else {
                                    if (Data.LinkedPage == "") {

                                        var WebLink = Data.AdsWebsite;
                                        html += ('<li><a id="' + Data.AdsID + ',' + Data.AdsWebsite + '" href="' + WebLink + '" onclick="return false;"><img src=' + p.baseURL + 'Upload/' + Data.AdsImage + ' title=' + '"' + Data.AdsDescription + '" height=\"' + p.AdsHeight + '\" width=\"' + p.AdsWidth + '\"/></a></li>');
                                    }
                                    else {
                                        var ext_Add = "#";
                                        if (Data.LinkedPage != "#") {
                                            ext_Add = p.Sageurl + Data.LinkedPage + ".aspx";
                                            html += ('<li><a id="' + Data.AdsID + ',' + ext_Add + '" href="' + ext_Add + '" onclick="return false;"><img src=' + p.baseURL + 'Upload/' + Data.AdsImage + ' title=' + '"' + Data.AdsDescription + '"  height=\"' + p.AdsHeight + '\" width=\"' + p.AdsWidth + '\"/></a></li>');
                                        }
                                    }
                                }
                            }
                            if (AdsCount == p.AdsNextLineAfter) {
                                AdsCount = 0;
                                html += '</br>';
                            }

                        });
                    }
                    $('#ulADs_' + p.UsermoduleId + '').append(html);
                },
                error: function() {
                    alert('Error occured getting  image');
                }

            });
            $('#ulADs_' + p.UsermoduleId + ' a').live("click", function() {
                var id = $(this).attr("id");
                var anchorID = id.split(",");
                var AdsId = anchorID[0];
                var Link = anchorID[1];
                if (id == "") {
                    return;
                }
                else {
                    UpdateClickedNumber(AdsId, Link);
                }


            });

        }

        function UpdateClickedNumber(AdsId, Link) {
            $.ajax({
                type: "POST",
                url: p.baseURL + "Services/AdsModuleService.asmx/UpdateAdsClickedCount",
                data: JSON2.stringify({ AdsID: AdsId, IPAdd: p.IPAddress, Country: p.CountryName, UserName: p.UserName }),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function(msg) {
                    window.location.href = Link;
                },
                error: function() {
                    alert('Error occured Updating Number Of Time Clicked');
                }
            });

        }
        function SaveNumberOfTimeEachAdsShown(AdsID) {
            $.ajax({
                type: "POST",
                url: p.baseURL + "Services/AdsModuleService.asmx/SaveNumberOfTimeEachAdsShown",
                data: JSON2.stringify({ AdsID: AdsID }),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function(msg) {

                },
                error: function() {
                    alert('Error occured Saving Number Of Time Each Ads Shown ');
                }
            });

        }
    };
    $.fn.GetAdvertisement = function(p) {
        $.createAdvertisementScript(p);
    };
})(jQuery);




