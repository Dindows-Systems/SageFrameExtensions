﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.VideoGallery;
using System.Data;
using SageFrame.VideoGallery.Entities;
using SageFrame.VideoGallery.DataProvider;
using System.IO;
using System.Xml;
using SageFrame.Web.Utilities;
using System.Diagnostics;
using System.Threading;
using System.Text;


public partial class Modules_VideoGallery_VideoGalleryView : BaseAdministrationUserControl
{
    public static char[] splitter = { ':' };
    public XmlNamespaceManager xmlN;
    public XmlNamespaceManager xmlN1;
    public string url = string.Empty;
    public string id;
    public string VideoUrlpath;
    public string height;
    public string width;
    public string ytHight;
    public string ytWidth;
    public int UserModuleID = 0;
    public int PortalID;   
    public string Enablesearch;   
    public string SageSelectedVideo;
    public string EnableSageDownload;
    public string TabIndex;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        VideoUrlpath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
        id = hidValue.ClientID;      
        PortalID = GetPortalID;
        UserModuleID = Int32.Parse(SageUserModuleID);
        if (!IsPostBack)
        {
            
            LoadYouTubeSelectedVideo();
            LoadSelectedEmbedYoutube();
            VideoController clt = new VideoController();
            url = clt.GetYTUrlID(PortalID, UserModuleID);
            GetSettingList(PortalID, UserModuleID);
            Literal1.Text = YouTubeScript.Get(url, 0, 500, 400);
            loadYtDefaultValue();
            LoadSageDefaultValue();
            if (SageSelectedVideo == "True" || EnableSageDownload == "True" || Enablesearch == "True")
            {
                if (Request.QueryString["RSS"] != null)
                {
                    GetVideoRSS();
                }
            }
            else
            {
                if (Request.QueryString["RSS"] != null)
                {
                    GetYTVideoRss();
                }
            } 
            LoadEmbeddedList();
            CreatedynamicContainer();
            LoadSageEmbeddedCode();
            LoadSagePlayer();
            LoadSearchResult();
            LoadSerchResult();
        }
        
        LoadImage();       
        ytPagination.Visible = false; 
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        IncludeJs("VideoGallery", "/Modules/VideoGallery/Js/swfobject.js", "/Modules/VideoGallery/Js/Video.js", "/Modules/VideoGallery/Js/easypaginate.min.js", "/Modules/VideoGallery/Js/jquery.pajinate.min.js");
        IncludeCss("VideoGallery", "/Modules/VideoGallery/module.css");
        IncludeCss("VideoGallery", "/Modules/VideoGallery/Css/styles.css");      
        txtSearchVideo.Attributes.Add("onkeypress", "return clickButton(event,'" + imbSearchYTVideo.ClientID + "')");
        txtSearchinSage.Attributes.Add("onkeypress", "return clickButton(event,'" + imbSageSearch.ClientID + "')");
       
    }

    private void LoadImage()
    {
        
        imbDownloadVideo.ImageUrl = VideoUrlpath + "Logo/imgdownload.png";
        imbSearchYTVideo.ImageUrl = GetTemplateImageUrl("search-btn.jpg", true);
        imbSageSearch.ImageUrl = GetTemplateImageUrl("search-btn.jpg", true);
        imbSageRss.ImageUrl = VideoUrlpath + "Logo/rss-icon.png";
        imbYTRss.ImageUrl = VideoUrlpath + "Logo/rss-icon.png";
    }

    public void CreatedynamicContainer()
    {
        StringBuilder sb = new StringBuilder();        
        sb.Append("<ul id='ulSelectedVidList_" + UserModuleID + "' class='sfSagevideo clearfix'></ul>");     
        ltrVideo.Text=sb.ToString();
             
    }

    public void LoadEmbeddedList()
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("<div id='divEmbedded_" + UserModuleID + "' >");
        sb.Append("<ul id='selectedEmbeddedVideos_" + UserModuleID + "'></ul>");
        sb.Append("</div>");
        ltrEmbedded.Text=sb.ToString();
             
    }

    public void LoadSagePlayer()
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("<div id='divSagePlayer_" + UserModuleID + "' >");
        sb.Append("<p id='player2_" + UserModuleID + "'></p>");
        sb.Append("</div>");
        ltrSagePlayer.Text = sb.ToString();
    }

    public void LoadSageEmbeddedCode()
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("<div id='divSageEmbed_" + UserModuleID + "' class='sfSageEmbedVideo' >");
        sb.Append("<ul id='embedplayer_" + UserModuleID + "' class='ulSageEmbedvideo clearfix'></ul>");
        sb.Append("<ul id='Embeddedplayer_" + UserModuleID + "'></ul>");
        sb.Append("</div>");
        ltrSagEmbedded.Text = sb.ToString();
    }

    public void LoadSearchResult()
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("<input id='txtSearch_" + UserModuleID + "' type='text'class='sfInputbox'/>");
        sb.Append("<input id='imbSageVideoSearch_" + UserModuleID + "' type='button' class='sfBtn' value='Search'/>");
        ltrSearchVideo.Text = sb.ToString();
    }

    public void LoadSerchResult()
    {
        StringBuilder sb = new StringBuilder();
        sb.Append("<div id='SagepagingList_" + UserModuleID + "' class='sfSearchResult'>");
        sb.Append("<div id='PageNav_" + UserModuleID + "' class='page_navigation' ></div>");
        sb.Append("<ul id='ulSearchVideo_" + UserModuleID + "' class='sfSearchedList' ></ul>");
        sb.Append("</div>");
        ltrSearchResult.Text = sb.ToString();
    }

    protected void PlayVideo(string url)
    {

        string[] urlParts = url.Split('=');
        if (urlParts[1] != "")
        {
            Literal1.Text = YouTubeScript.GetSearch(urlParts[1], 0, 500, 400);
            lblLink.Text = urlParts[1];
        }
    }

    protected void imbSearchYTVideo_Click(object sender, EventArgs e)
    {
        try
        {
            string searchText = txtSearchVideo.Text;
           
                XmlDataSource1.DataFile = "http://gdata.youtube.com/feeds/api/videos?vq=" + searchText + "&orderby=relevance&start-index=1&max-results=12&alt=rss&format=5";
                xmlN = new XmlNamespaceManager(XmlDataSource1.GetXmlDocument().NameTable);
                xmlN.AddNamespace("gd", "http://schemas.google.com/g/2005");
                xmlN.AddNamespace("yt", "http://gdata.youtube.com/schemas/2007");
                xmlN.AddNamespace("media", "http://search.yahoo.com/mrss/");
                XmlDataSource1.DataBind();
                RepeaterTube.DataSource = XmlDataSource1;
                RepeaterTube.DataBind();           
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    protected void RepeaterTube_ItemCommand1(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.Equals("View"))
        {
            PlayVideo(e.CommandArgument.ToString());
        }      
    }

    protected void RepeaterTube_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (RepeaterTube.Items.Count < 1)
        {
            if (e.Item.ItemType == ListItemType.Footer)
            {
                Label lblFooter = (Label)e.Item.FindControl("lblEmptyYTData");
                lblFooter.Visible = true;
            }
        }
    }  
    
    protected void SearchRepeater_ItemCommand1(object source, RepeaterCommandEventArgs e)
    {

    }

    protected void SearchRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (SearchRepeater.Items.Count < 1)
        {
            if (e.Item.ItemType == ListItemType.Footer)
            {
                Label lblFooter = (Label)e.Item.FindControl("lblEmptyData");
                lblFooter.Visible = true;
            }
        }
        if (SearchRepeater.Items.Count > 10)
        {
            ytPagination.Visible = true;
        }
    }

    protected void imbSageSearch_Click(object sender, EventArgs e)
    {
        SearchVideo();
        
    }

    protected void SearchRepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.Equals("DBVideo"))
        {
            PlayDBVideo(e.CommandArgument.ToString());

        }
    }

    private void SearchVideo()
    {
        try
        {
            VideoController clt = new VideoController();
            string txtSerachTitle = txtSearchinSage.Text;

            SearchRepeater.DataSource = clt.GetSearchVideoFromSage(txtSerachTitle);
            SearchRepeater.DataBind();
            txtSearchinSage.Text = string.Empty;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void PlayDBVideo(string url)
    {
        Literal1.Text = YouTubeScript.Get(url, 0, 500, 400);
    }
   
    protected void RepeaterSelectedVideoList_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.Equals("AllVideo"))
        {
            PlayDBVideo(e.CommandArgument.ToString());
        }
    }

    protected void RepeaterSelectedVideoList_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {

    }

    private void LoadYouTubeSelectedVideo()
    {
        try
        {
            VideoController clt = new VideoController();
            RepeaterSelectedVideoList.DataSource = clt.GetYoutubeSelectedVideo(GetPortalID,int.Parse(SageUserModuleID));
            RepeaterSelectedVideoList.DataBind();           
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void RepeaterEmbededYoutube_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }

    protected void RepeaterEmbededYoutube_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {

    }

    private void LoadSelectedEmbedYoutube()
    {
        VideoController clt = new VideoController();

        RepeaterEmbededYoutube.DataSource = clt.GetEmbedSelectedYoutube(GetPortalID,int.Parse(SageUserModuleID));
        RepeaterEmbededYoutube.DataBind();
       
    }

    protected void RepeaterEmbedSageVideo_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }

    protected void RepeaterEmbedSageVideo_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {

    }

    protected void imbDownloadVideo_Click(object sender, EventArgs e)
    {

        string test = hidValue.Value;

        string filepath = Server.MapPath(VideoUrlpath + "\\VideoFile\\" + test);
        FileInfo file = new FileInfo(filepath);
        if (file.Exists)
        {
            Response.ClearContent();
            Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name);
            Response.AddHeader("Content-Length", file.Length.ToString());
            Response.ContentType = ReturnExtension(file.Extension.ToLower());
            Response.TransmitFile(file.FullName);
            Response.End();

        }
    }

    private string ReturnExtension(string fileExtension)
    {
        switch (fileExtension)
        {

            case "flv":
                return "video/flv";            
            default:
                return "application/octet-stream";
        }

    }
   
    #region "View control through setting"
    public void GetSettingList(int PortalID, int UserModuleID)
    {
        try
        {
            VideoController clt = new VideoController();
            VideoGallerySettingInfo GetSetting = new VideoGallerySettingInfo();
            GetSetting = clt.GetVideoSetting(PortalID, UserModuleID);
             string YouTubeSearch = Convert.ToString(GetSetting.Search_Youtube);
             string SageSearch = Convert.ToString(GetSetting.Search_Sageframe);            
             string SelectedVideo = Convert.ToString(GetSetting.Selected_Video);            
             string EnableSageEmbedVideo = Convert.ToString(GetSetting.SageEmbedVideo);
             string EnableYTEmbedVideo = Convert.ToString(GetSetting.YTEmbedVideo);
             string EmbeddedVideoList = Convert.ToString(GetSetting.EnableEmbeddedList);
             string SageRss = Convert.ToString(GetSetting.SageRss);
             string YoutubeRss = Convert.ToString(GetSetting.YoutubeRss);
             SageSelectedVideo = Convert.ToString(GetSetting.SageSelected_Video);
             EnableSageDownload = Convert.ToString(GetSetting.EnableSageVideoDownload);
             Enablesearch = Convert.ToString(GetSetting.EnableSearch);

            if (SageSearch == "False")
            {
                TabPnlSageSearch.Visible = false;
            }
            if (YouTubeSearch == "False")
            {
                TabPnlYoutubeSearch.Visible = false;
               
            }
            if (SageSearch == "False" && YouTubeSearch == "True")
            {
                TabPnlSageSearch.Visible = false;
                TabIndex = "1";
                TabSearchVideo.ActiveTabIndex = int.Parse(TabIndex.ToString());
            }

            if (Enablesearch == "False")
            {
                DivsearchSageVideo.Visible = false;
            }
            if (SelectedVideo == "False")
            {
                DivSelectedVideo.Visible = false;
            }
            if (SageSelectedVideo == "False")
            {
                divSelectedVidList.Visible = false;
            }
            if (YouTubeSearch == "False" && SageSearch == "False")
            {
                TabSearchVideo.Visible = false;
            }
            if (EnableSageDownload == "False")
            {
                imbDownloadVideo.Visible = false;
            }
            if (SageRss == "False")
            {
                imbSageRss.Visible = false;
            }
            if (YoutubeRss == "False")
            {
                imbYTRss.Visible = false;
            }
            if (EnableSageEmbedVideo == "False")
            {
                divSageEmbedVideo.Visible = false;
            }
            if (EnableYTEmbedVideo == "False")
            {
                DivEmbededYoutubeVideo.Visible = false;
            }
            if (YouTubeSearch == "False" && SageSearch == "False" && SelectedVideo == "False")
            {
                divYoutubeGallery.Visible = false;
                divEmbeddedVideoList.Visible = false;
               
            }
            if (YouTubeSearch == "False" && SageSearch == "False" && SelectedVideo == "False"&&YoutubeRss=="True")
            {
                divYoutubeGallery.Visible = true;
                divEmbeddedVideoList.Visible = false;
                divYTRss.Visible = true;
            }
            if (Enablesearch == "False" && SageSelectedVideo == "False" && EnableSageDownload == "False")
            {
                DivSageGallery.Visible = false;
                divEmbeddedVideoList.Visible = false;
            }
            if (Enablesearch == "False" && SageSelectedVideo == "False" && EnableSageDownload == "False" &&SageRss=="True")
            {
                DivSageGallery.Visible = true;
                divEmbeddedVideoList.Visible = false;
                imbSageRss.Visible = true;
            }
            if (Enablesearch == "True" && SageSelectedVideo == "True" && EnableSageDownload == "True" && SageRss == "True")
            {
                DivSageGallery.Visible = true;
                //divEmbeddedVideoList.Visible = true;
                imbSageRss.Visible = true;
            }
            if (EmbeddedVideoList == "True")
            {
                DivSageGallery.Visible = false;
                divYoutubeGallery.Visible = false;
                divEmbeddedVideoList.Visible = true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
    #endregion

    private void loadYtDefaultValue()
    {
        try
        {         
            VideoController vct = new VideoController();
            YoutubeVideoInfo obj = vct.GetYtvideoFile(GetPortalID,int.Parse(SageUserModuleID));
            if (obj == null)
            {
                ytHight = "0";
                ytWidth = "0";
                divYoutubeGallery.Visible = false;
                DivEmbededYoutubeVideo.Visible = false;
            }
            string ytPlayer = vct.GetYtSize(GetPortalID,int.Parse(SageUserModuleID));
            string[] length = ytPlayer.Split('x');
            ytHight = length[0];
            ytWidth = length[1];
            if (ytPlayer == "0x0")
            {
                DivEmbededYoutubeVideo.Visible = false;
            }       
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    private void LoadSageDefaultValue()
    {
        try
        {
            VideoController vct = new VideoController();
            VideoInfo obj = vct.GetvideoFile(GetPortalID,int.Parse(SageUserModuleID));
            if (obj == null)
            {
                DivSageGallery.Visible = false;
            }
            string size = vct.GetSagePlayerSize(GetPortalID,int.Parse(SageUserModuleID));
            string[] length = size.Split('x');
            height = length[0];
            width = length[1];
            if (size == "0x0")
            {
                divSageEmbedVideo.Visible = false;
            }

        }
        catch (Exception e)
        {
            throw e;
        }
    }


    private void GetVideoRSS()
    {
        try
        {
            VideoRss objrss = new VideoRss();
            objrss.GetRSS(UserModuleID, Request.Url.AbsoluteUri);
        }
        catch (Exception)
        {
        }
    }

    private void GetYTVideoRss()
    {
        try
        {
            YTVideoRss objrss = new YTVideoRss();
            objrss.GetYTRSS(UserModuleID, Request.Url.AbsoluteUri);
        }
        catch (Exception)
        {
        }
    }

    protected void imbSageRss_Click1(object sender, ImageClickEventArgs e)
    {

        if (Session["BasePage"] != null)
        {
            string basePage = Session["BasePage"].ToString();
            string redirectURL = basePage;           
            if (basePage.Contains("?"))
            {
                redirectURL += "&RSS=VideoGallery";
            }
            else
            {
                redirectURL += "?RSS=VideoGallery";
            }
            Response.Redirect(redirectURL, false);
        }
        else
        {
            VideoInfo objBlogClass = new VideoInfo();
            string basePageURL = objBlogClass.BaseUrl(Request.RawUrl);
            if (basePageURL.Contains("?"))
            {
                basePageURL += "&RSS=VideoGallery";
            }
            else
            {
                basePageURL += "?RSS=VideoGallery";
            }
            Response.Redirect(basePageURL, false);
        }
    }

    protected void imbYTRss_Click(object sender, ImageClickEventArgs e)
    {

        if (Session["BasePage"] != null)
        {
            string basePage = Session["BasePage"].ToString();
            string redirectURL = basePage;
            if (basePage.Contains("?"))
            {
                redirectURL += "&RSS=VideoGallery";
            }
            else
            {
                redirectURL += "?RSS=VideoGallery";
            }
            Response.Redirect(redirectURL, false);
        }
        else
        {
            VideoInfo objBlogClass = new VideoInfo();
            string basePageURL = objBlogClass.BaseUrl(Request.RawUrl);
            if (basePageURL.Contains("?"))
            {
                basePageURL += "&RSS=VideoGallery";
            }
            else
            {
                basePageURL += "?RSS=VideoGallery";
            }
            Response.Redirect(basePageURL, false);
        }
    }
}


   



