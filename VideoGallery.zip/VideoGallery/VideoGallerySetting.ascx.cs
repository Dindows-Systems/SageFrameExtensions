﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.VideoGallery.DataProvider;
using SageFrame.VideoGallery;
using SageFrame.VideoGallery.Entities;

public partial class Modules_VideoGallery_VideoGallerySetting : BaseAdministrationUserControl
{
    public string VideoUrlpath;
    public int PortalID;
    public int UserModuleID;
    public string Username;
    public string SageGallerySearch;
    public string EmbeddedVideo;
    public string DownloadSageVideo;
    public string YTSearchToyoutube;
    public string YTSearchToSage;
    public string YTSelectedVideo;
    public string YTEmbeddedVideo;
    public string SageEmbeddedVideo;
    public string SageSelectedVideo;
    public string SageRss;
    public string YoutubeRss;

    protected void Page_Load(object sender, EventArgs e)
    {
       
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        PortalID = GetPortalID;
        Username = GetUsername;
        UserModuleID = Int32.Parse(SageUserModuleID);
        PageInit();
        VideoUrlpath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
        loadSetting(PortalID, UserModuleID);
    }

    private void PageInit()
    {
        //IncludeJs("VideoGallery", "/Modules/VideoGallery/Js/Video.js");
        IncludeCss("VideoGallery", "/Modules/VideoGallery/module.css");
    }

    private void loadSetting(int PortalID, int UserModuleID)
    {
        try
        {

            VideoController clt = new VideoController();
            VideoGallerySettingInfo GetSetting = new VideoGallerySettingInfo();
            GetSetting = clt.GetVideoSetting(PortalID, UserModuleID);

            SageGallerySearch = Convert.ToString(GetSetting.EnableSearch);
            EmbeddedVideo = Convert.ToString(GetSetting.EnableEmbeddedList);
            DownloadSageVideo = Convert.ToString(GetSetting.EnableSageVideoDownload);
            YTSearchToyoutube = Convert.ToString(GetSetting.Search_Youtube);
            YTSearchToSage = Convert.ToString(GetSetting.Search_Sageframe);
            YTSelectedVideo = Convert.ToString(GetSetting.Selected_Video);
            YTEmbeddedVideo = Convert.ToString(GetSetting.YTEmbedVideo);
            SageEmbeddedVideo = Convert.ToString(GetSetting.SageEmbedVideo);
            SageSelectedVideo = Convert.ToString(GetSetting.SageSelected_Video);
            SageRss = Convert.ToString(GetSetting.SageRss);
            YoutubeRss = Convert.ToString(GetSetting.YoutubeRss);
        }
        catch (Exception e)
        {
            throw e;
        }   
    }
}
