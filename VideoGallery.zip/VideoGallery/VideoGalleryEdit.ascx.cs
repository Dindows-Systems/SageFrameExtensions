﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.VideoGallery.Entities;
using SageFrame.VideoGallery;
using SageFrame.VideoGallery.DataProvider;
using System.IO;
using System.Data;
using System.Diagnostics;
using System.Xml;
using System.Threading;



public partial class Modules_VideoGallery_VideoGalleryEdit : BaseAdministrationUserControl
{
    public static char[] splitter = { ':' };
    public XmlNamespaceManager xmlN;
    public XmlNamespaceManager xmlN1;
    public string url = string.Empty;
    public string path;
    public string TabIndex;
    public string Tab;
    public string ImageId;
    public int i;
    public int videoCharacterCount;
    public int UserModuleID ;
    public int PortalID;
    protected void Page_Load(object sender, EventArgs e)
    {
        PortalID = GetPortalID;
        UserModuleID = Int32.Parse(SageUserModuleID);       
        if (!IsPostBack)
        {
            LoadEmbeddedVideoCode();
            LoadSageEmbeddedVideo();
            LoadYTEmbeddedVideo();
            LoadSageVideo();
            LoadYoutubeVideoList();          
            LoadEmbedddedVideoType();
            LoadVideoCategory();
            loadSetting(PortalID, UserModuleID);
            VideoController clt = new VideoController();
            url = clt.GetYTUrlID(PortalID,UserModuleID);
            HideSave(url);
            Literal1.Text = YouTubeScript.Get(url, 0, 400, 300);
            lblLink.Text = url;  
            
        }
       
        path = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
        LoadImage();
        
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        IncludeCss("VideoGallery", "/Modules/VideoGallery/module.css");
        IncludeJs("VideoGallery", "/Modules/VideoGallery/Js/jquery.numeric.js", "/Modules/VideoGallery/Js/jquery.validate.js", "/Modules/VideoGallery/Js/jquery.validate.min.js");      
        txtSearchSageVideo.Attributes.Add("onkeypress", "return clickButton(event,'" + imgbtnSageSearch.ClientID + "')");
        txtSearchYTVideo.Attributes.Add("onkeypress", "return clickButton(event,'" + imgbtnYTvideo.ClientID + "')");
        txtSearchVideo.Attributes.Add("onkeypress", "return clickButton(event,'" + imbSearchfromYT.ClientID + "')");
        txtSearchSageEmbeddedVideo.Attributes.Add("onkeypress", "return clickButton(event,'" + imgbtnSageEmbedded.ClientID + "')");
        txtYTEmbeddedVideo.Attributes.Add("onkeypress", "return clickButton(event,'" + imgbtnSearchYTEmbedded.ClientID + "')"); 
    }

    private void LoadImage()
    {        
        btnSelectOk.ImageUrl = GetTemplateImageUrl("imgsave.png", true);
        btnSubmitYoutube.ImageUrl = GetTemplateImageUrl("imgsave.png", true);
        imbSaveSageEmbeddedList.ImageUrl = GetTemplateImageUrl("imgsave.png", true);
        imbSaveYTEmbeddedList.ImageUrl = GetTemplateImageUrl("imgsave.png", true);      
        imbbtnSaveCheckedEmbeddedList.ImageUrl = GetTemplateImageUrl("imgsave.png", true);       
        imbbtnSearchEmbeddedVideo.ImageUrl = GetTemplateImageUrl("search-btn.jpg", true);
        imgbtnYTvideo.ImageUrl = GetTemplateImageUrl("search-btn.jpg", true);
        imbSearchfromYT.ImageUrl = GetTemplateImageUrl("search-btn.jpg", true);
        imgbtnSageEmbedded.ImageUrl = GetTemplateImageUrl("search-btn.jpg", true);
        imgbtnSearchYTEmbedded.ImageUrl = GetTemplateImageUrl("search-btn.jpg", true);
        imgbtnSageSearch.ImageUrl = GetTemplateImageUrl("search-btn.jpg", true);
        imgbtnSageSearch.ImageUrl = GetTemplateImageUrl("search-btn.jpg", true);
    }

    private void loadSetting(int PortalID, int UserModuleID)
    {
        try
        {
            VideoController clt = new VideoController();
            VideoGallerySettingInfo GetSetting = new VideoGallerySettingInfo();
            GetSetting = clt.GetVideoSetting(PortalID, UserModuleID);

            string SageGallerySearch= Convert.ToString(GetSetting.EnableSearch);
            string EmbeddedVideo= Convert.ToString(GetSetting.EnableEmbeddedList);
            string DownloadSageVideo = Convert.ToString(GetSetting.EnableSageVideoDownload);
            string YTSearchToyoutube = Convert.ToString(GetSetting.Search_Youtube);
            string YTSearchToSage = Convert.ToString(GetSetting.Search_Sageframe);
            string YTSelectedVideo = Convert.ToString(GetSetting.Selected_Video);
            string YTEmbeddedVideo = Convert.ToString(GetSetting.YTEmbedVideo);
            string SageEmbeddedVideo = Convert.ToString(GetSetting.SageEmbedVideo);
            string SageSelectedVideo = Convert.ToString(GetSetting.SageSelected_Video);
            if (SageGallerySearch == "True" || DownloadSageVideo == "True" || YTSearchToyoutube == "True" || YTSearchToSage == "True" || YTSelectedVideo == "True" || SageSelectedVideo == "True")
            {
              
                Tab = "0";
                tabContrGallery.ActiveTabIndex = int.Parse(Tab.ToString());              
                if (SageGallerySearch == "True" || DownloadSageVideo == "True" || SageSelectedVideo == "True")
                {
                    TabIndex = "0";
                    TabContainerGallery.ActiveTabIndex = int.Parse(TabIndex.ToString());
                }
                if (YTSearchToyoutube == "True" || YTSearchToSage == "True" || YTSelectedVideo == "True")
                {
                    TabIndex = "1";
                    TabContainerGallery.ActiveTabIndex = int.Parse(TabIndex.ToString());
                }
            }
            if (EmbeddedVideo == "True" || YTEmbeddedVideo == "True" || SageEmbeddedVideo=="True")
            {
                Tab = "1";
                tabContrGallery.ActiveTabIndex = int.Parse(Tab.ToString());               
                if (SageEmbeddedVideo == "True")
                {
                    TabIndex = "0";
                    TabContainerEmbedded.ActiveTabIndex = int.Parse(TabIndex.ToString());
                }
                if (YTEmbeddedVideo == "True")
                {
                    TabIndex = "1";
                    TabContainerEmbedded.ActiveTabIndex = int.Parse(TabIndex.ToString());
                }
                if (EmbeddedVideo == "True")
                {
                    TabIndex = "2";
                    TabContainerEmbedded.ActiveTabIndex = int.Parse(TabIndex.ToString());
                }
            }
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    private void HideSave(string url)
    {
        try
        {

            if (url == "")
            {
                divSaveYtLink.Visible = false;
            }
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    private void LoadEmbedddedVideoType()
    {
        try
        {
            VideoController vclt = new VideoController();
            ddlSearchtype.DataSource = vclt.GetEmbeddedVideoType(PortalID,UserModuleID);
            ddlSearchtype.DataTextField = "Type";
            ddlSearchtype.DataBind();
        }
        catch (Exception e)
        {
            throw e;
        }

    }

    private void LoadVideoCategory()
    {
        try
        {
            VideoController vclt = new VideoController();
            string videocat = vclt.GetSageVideoCategory();
            ddlSelectCategory.DataSource = vclt.GetVideoCategory(PortalID,UserModuleID);
            ddlSelectCategory.DataTextField = "VideoCategory";
            ddlSelectCategory.DataBind();
            if (videocat == null)
            {
                ddlSelectCategory.Visible = false;
            }
        }
        catch (Exception e)
        {
            throw e;
        }

    }

    #region "Upload and convert video"

    protected void btnUploadSageframeVideo_Click(object sender, EventArgs e)
    {
        bool i = ReturnVideo(VideoUpload, this.VideoUpload.FileName.ToString());
    }

    private bool ReturnVideo(FileUpload fu, string fileName)
    {
        try
        {
            videoCharacterCount = fileName.Length;
            i = fu.PostedFile.ContentLength;
          
            if (videoCharacterCount >= 130)
            {
                return false;
            }
            else
            {
                if (i >= 100000000)
                {
                    return false;
                }
                else
                {
                    string html = string.Empty;
                    VideoInfo obj = new VideoInfo();
                    obj.VideoDescription = txtVideoDescription.Value;
                    obj.UserModuleID = UserModuleID;
                    obj.PortalID = PortalID;
                    string category = txtVideoCategory.Text;
                    string ddlCategory = ddlSelectCategory.SelectedIndex.ToString();
                    if (category == "" && ddlCategory == "-1")
                    {
                        obj.VideoCategory = "Music";

                    }
                    if (category == "" && ddlCategory != "-1")
                    {
                        obj.VideoCategory = ddlSelectCategory.SelectedItem.Text;
                    }
                    if (category != "")
                    {
                        obj.VideoCategory = category;
                    }
                    int j = 0;
                    string pathv;
                    string inputPath;
                    string outputPath;
                    string mediumimgpath;
                    string smallimgpath;
                    string largeimageath;
                    string basePath = Request.PhysicalApplicationPath + "Modules\\VideoGallery\\Originalvideo\\";
                    pathv = Request.PhysicalApplicationPath;                   
                    if (!Directory.Exists(basePath))
                    {
                        Directory.CreateDirectory(basePath);
                    }
                   
                    inputPath = pathv + "Modules\\VideoGallery\\Originalvideo";
                    outputPath = pathv + "Modules\\VideoGallery\\videoFile";
                    if (!Directory.Exists(outputPath))
                    {
                        Directory.CreateDirectory(outputPath);
                    }
                    mediumimgpath = pathv + "Modules\\VideoGallery\\ThumbnailImage\\Medium";
                    if (!Directory.Exists(mediumimgpath))
                    {
                        Directory.CreateDirectory(mediumimgpath);
                    }
                    smallimgpath = pathv + "Modules\\VideoGallery\\ThumbnailImage\\Small";
                    if (!Directory.Exists(smallimgpath))
                    {
                        Directory.CreateDirectory(smallimgpath);
                    }
                    largeimageath = pathv + "Modules\\VideoGallery\\ThumbnailImage\\Large";
                    if (!Directory.Exists(largeimageath))
                    {
                        Directory.CreateDirectory(largeimageath);
                    }
                    string filepath = basePath + fileName;
                    while (File.Exists(filepath))
                    {
                        j = j + 1;
                        int dotPos = fileName.LastIndexOf(".");
                        string namewithoutext = fileName.Substring(0, dotPos);
                        string ext = fileName.Substring(dotPos + 1);
                        fileName = namewithoutext + j + "." + ext;
                        filepath = basePath + fileName;
                    }
                    try
                    {
                        this.VideoUpload.SaveAs(filepath);
                    }
                    catch
                    {
                        return false;
                    }
                    string outPutFile;
                    outPutFile = basePath + fileName;
                    System.IO.FileInfo a = new System.IO.FileInfo(filepath);
                    while (a.Exists == false)
                    {

                    }
                    long b = a.Length;

                    while (i != b)
                    {

                    }
                    decimal duration;
                    duration = Convert.ToDecimal(b) / Convert.ToDecimal(2446058);
                    string length = duration.ToString("#.##");
                    obj.VideoLength = length;


                    string fileextension = Path.GetExtension(this.VideoUpload.PostedFile.FileName);
                    if (fileextension == ".flv")
                    {
                        try
                        {
                            VideoUpload.SaveAs(Path.Combine(outputPath, VideoUpload.FileName));
                            string videoFile = fileName.Replace(".flv", "");
                            obj.VideoName = videoFile;
                            string small = " -i \"" + inputPath + "\\" + fileName + "\" -f image2 -ss 2 -vframes 1 -s 150x100 -an \"" + smallimgpath + "\\" + videoFile + ".jpg" + "\"";
                            ConvertNow(small);

                            obj.ThumbnailImage = videoFile + ".jpg";
                            string medium = " -i \"" + inputPath + "\\" + fileName + "\" -f image2 -ss 2 -vframes 1 -s 200x150 -an \"" + mediumimgpath + "\\" + videoFile + ".jpg" + "\"";
                            ConvertNow(medium);

                            string large = " -i \"" + inputPath + "\\" + fileName + "\" -f image2 -ss 2 -vframes 1 -s 450x350 -an \"" + largeimageath + "\\" + videoFile + ".jpg" + "\"";
                            ConvertNow(large);

                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }
                    if(fileextension == ".mp4")
                    {
                        string GetFileExtension = Path.GetExtension(fileName);
                        string newFileName = fileName.Replace(GetFileExtension, ".flv");
                        string cmd = " -i \"" + inputPath + "\\" + fileName + "\" \"" + outputPath + "\\" + newFileName + "\"";
                        ConvertNow(cmd);
                        obj.VideoName = newFileName.Replace(".flv", "");
                        string mediumThumb = " -i \"" + outputPath + "\\" + newFileName + "\" -f image2 -ss 2 -vframes 1 -s 200x150 -an \"" + mediumimgpath + "\\" + newFileName.Replace(".flv", ".jpg") + "\"";
                        ConvertNow(mediumThumb);
                        obj.ThumbnailImage = newFileName.Replace(".flv", ".jpg");

                        string smallThumb = " -i \"" + outputPath + "\\" + newFileName + "\" -f image2 -ss 2 -vframes 1 -s 150x100 -an \"" + smallimgpath + "\\" + newFileName.Replace(".flv", ".jpg") + "\"";
                        ConvertNow(smallThumb);

                        string largeThumb = " -i \"" + outputPath + "\\" + newFileName + "\" -f image2 -ss 2 -vframes 1 -s 450x350 -an \"" + largeimageath + "\\" + newFileName.Replace(".flv", ".jpg") + "\"";
                        ConvertNow(largeThumb);

                    }
                    VideoDataProvider dp = new VideoDataProvider();
                    dp.UploadVideo(obj);
                    ClearText();
                    LoadSageVideo();
                    LoadSageEmbeddedVideo();
                    Deletefile(fileName);
                    LoadVideoCategory();
                    return true;                  
                }
            }

            
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    private void ConvertNow(string cmd)
    {
        try
        {
            string exepath;
            string pathv;
            pathv = Request.PhysicalApplicationPath;
            exepath = pathv + "Modules\\VideoGallery\\ffmpeg.exe";
            System.Diagnostics.Process proc = new System.Diagnostics.Process();
            proc.StartInfo.FileName = exepath;
            proc.StartInfo.Arguments = cmd;
            proc.StartInfo.UseShellExecute = false;
            proc.StartInfo.CreateNoWindow = true;
            proc.StartInfo.RedirectStandardOutput = false;
            proc.Start();
            while (proc.HasExited == false)
            {
            }
        }
        catch(Exception e)
        {
            throw e;
        }
    }

    #endregion

    private void Deletefile(string Videofile)
    {
        try
        {
            string completePath = Server.MapPath(path + "Originalvideo/") + Videofile;
            if (File.Exists(completePath))
            {
                File.Delete(completePath);
            }
        }
        catch (Exception e)        
        {
            throw e;
        }
    }

    private void ClearText()
    {
        try
        {
            txtVideoDescription.Value = string.Empty;
            txtSageWidth.Text = string.Empty;
            txtSageHight.Text = string.Empty;
            txtYtHight.Text = string.Empty;
            txtYtWidth.Text = string.Empty;
        }
        catch (Exception e)
        {
            throw e;
        }
    }      

    protected void GdvVideoList_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }

    protected void GdvVideoList_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void GdvVideoList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {          
            int OprationID = Int32.Parse(e.CommandArgument.ToString());
            switch (e.CommandName.ToString())
            {
                case "Delete":
                  Deletes(OprationID);                    
                  break;               
            }
          
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }   

    protected void GdvVideoList_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            ImageButton imgDelete = (ImageButton)e.Row.FindControl("imgDelete");
            RadioButton radIsActive = (RadioButton)e.Row.FindControl("radioSageVideo");
            //if (radIsActive.Checked)
            //{

            //    imgDelete.Visible = false;
            //}

        }
    }

    protected void GdvVideoList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GdvVideoList.PageIndex = e.NewPageIndex;
        LoadSageVideo();
    }

    private void LoadSageVideo()
    {
        try
        {
            VideoController clt = new VideoController();
            GdvVideoList.DataSource = clt.GetSageVideoList(PortalID,UserModuleID);
            GdvVideoList.DataBind();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void LoadSageEmbeddedVideo()
    {
        try
        {
            VideoController clt = new VideoController();
            GdvSageEmbedded.DataSource = clt.GetSageVideoList(PortalID,UserModuleID);
            GdvSageEmbedded.DataBind();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void Deletes(int VideoID)
    {
        try
        {
            string DefaultVideo = GetDefaultVideo(VideoID);
            //if (DefaultVideo == "False")
            //{
                string VideoName = GetVideoNamebyId(VideoID);
                DeleteVideoFile(VideoName);
                VideoDataProvider clt = new VideoDataProvider();
                clt.DeleteVideo(VideoID);
                ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/VideoGallery/ModuleLocalText", "DeleteVideo"), "", SageMessageType.Success);
                LoadSageVideo();
                LoadSageEmbeddedVideo();
            //}
            //else
            //{
            //    ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/VideoGallery/ModuleLocalText", "DefaultVideo"), "", SageMessageType.Alert);
            //    return;
            //}
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    private void DeleteVideoFile(string VideoName)
    {
        try
        {
            string VideoFile = Server.MapPath(path + "VideoFile/") + VideoName + ".flv";
            string LargeThumb = Server.MapPath(path + "ThumbnailImage/Large/") + VideoName + ".jpg";
            string MediumThumb = Server.MapPath(path + "ThumbnailImage/Medium/") + VideoName + ".jpg";
            string SmallThumb = Server.MapPath(path + "ThumbnailImage/Small/") + VideoName + ".jpg";
            if (File.Exists(VideoFile))
            {
                File.Delete(VideoFile);
            }
            if (File.Exists(LargeThumb))
            {
                File.Delete(LargeThumb);
            }
            if (File.Exists(MediumThumb))
            {
                File.Delete(MediumThumb);
            }
            if (File.Exists(SmallThumb))
            {
                File.Delete(SmallThumb);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private string GetVideoNamebyId(int VideoID)
    {
        try
        {
            VideoController clt = new VideoController();
            return clt.GetVideoName(VideoID);
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    private string GetDefaultVideo(int VideoID)
    {
        try
        {
            VideoController clt = new VideoController();
            return clt.GetDefaultVideo(VideoID);
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    private void DeleteYoutubeVideo(int VideoID)
    {
        try
        {
            string YTDefaultVideo = GetYTDefaultVideo(VideoID);
            if (YTDefaultVideo == "False")
            {
                VideoDataProvider clt = new VideoDataProvider();
                clt.DeleteYoutubeVideo(VideoID);
                ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/VideoGallery/ModuleLocalText", "DeleteVideo"), "", SageMessageType.Success);
                LoadYoutubeVideoList();
                LoadYTEmbeddedVideo();
            }
            else
            {
                ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/VideoGallery/ModuleLocalText", "DefaultVideo"), "", SageMessageType.Alert);
                
                return;
            }
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    private string GetYTDefaultVideo(int VideoID)
    {
        try
        {
            VideoController clt = new VideoController();
            return clt.GetYTDefaultVideo(VideoID);
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    protected void btnSelectOk_Click(object sender, EventArgs e)
    {
        UpdateActiveList();
        UpdateDefaultVideo();
    }

    protected void GdvVideoList_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    private void UpdateActiveList()
    {
        try
        {
            string CheckedItem = "";
            foreach (GridViewRow grdRow in GdvVideoList.Rows)
            {
                int VideoID = 0;
                HiddenField hdnVideoId = grdRow.FindControl("hdfVideoID") as HiddenField;
                VideoID = Convert.ToInt32(hdnVideoId.Value);

                CheckBox CheckActive = grdRow.FindControl("chkShowVideo") as CheckBox;
                if (CheckActive.Checked == true)
                {
                    CheckedItem = "True";
                }
                else
                {
                    CheckedItem = "False";
                }
                VideoDataProvider Vclt = new VideoDataProvider();
                Vclt.UpdateChecked(VideoID, CheckedItem);
                ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/VideoGallery/ModuleLocalText", "SaveSelectedVideo"), "", SageMessageType.Success);
            }
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    private void LoadYoutubeVideoList()
    {
        try
        {
            VideoController clt = new VideoController();
            GdvYoutube.DataSource = clt.GetYouTubeVideoList(PortalID,UserModuleID);
            GdvYoutube.DataBind();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void LoadYTEmbeddedVideo()
    {
        try
        {
            VideoController clt = new VideoController();
            GdvYoutubeEmbeddedList.DataSource = clt.GetYouTubeVideoList(PortalID,UserModuleID);
            GdvYoutubeEmbeddedList.DataBind();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void btnSubmitYoutube_Click(object sender, EventArgs e)
    {
        UpdateYoutubeActiveList();
        UpdateYTDefaultVideo();
    }

    private void UpdateYoutubeActiveList()
    {
        try
        {
            string CheckedItem = "";
            foreach (GridViewRow grdRow in GdvYoutube.Rows)
            {
                int VideoID = 0;
                HiddenField hdnVideoId = grdRow.FindControl("hdfYTVideoID") as HiddenField;
                VideoID = Convert.ToInt32(hdnVideoId.Value);
                CheckBox CheckActive = grdRow.FindControl("chkYoutubeVideo") as CheckBox;
                if (CheckActive.Checked == true)
                {
                    CheckedItem = "True";
                }
                else
                {
                    CheckedItem = "False";
                }
                VideoDataProvider Vclt = new VideoDataProvider();
                Vclt.UpdateCheckedYoutubeList(VideoID, CheckedItem);
                ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/VideoGallery/ModuleLocalText", "SaveSelectedVideo"), "", SageMessageType.Success);
            }
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    protected void imbSearchfromYT_Click(object sender, EventArgs e)
    {
        try
        {
            string searchtext = txtSearchVideo.Text;
            
                XmlDataSource1.DataFile = "http://gdata.youtube.com/feeds/api/videos?vq=" + searchtext + "&orderby=relevance&start-index=1&max-results=12&alt=rss&format=5";
                xmlN = new XmlNamespaceManager(XmlDataSource1.GetXmlDocument().NameTable);
                xmlN.AddNamespace("gd", "http://schemas.google.com/g/2005");
                xmlN.AddNamespace("yt", "http://gdata.youtube.com/schemas/2007");
                xmlN.AddNamespace("media", "http://search.yahoo.com/mrss/");
                XmlDataSource1.DataBind();
                RepeaterTube.DataSource = XmlDataSource1;
                RepeaterTube.DataBind();           
        }
        catch (Exception)
        {
            throw;
        }
    }

    protected void PlayVideo(string url)
    {
        string[] urlParts = url.Split('=');
        if (urlParts[1] != "")
        {
            Literal1.Text = YouTubeScript.Get(urlParts[1], 0, 400, 300);
            lblLink.Text = urlParts[1];
        }
    }

    protected void btnSaveYoutubeLink_Click(object sender, EventArgs e)
    {
        try
        {
            string urlid;
            YoutubeVideoInfo obj = new YoutubeVideoInfo();
            obj.VideoTitle = txtYoutubeVieoTitle.Text;
            obj.VideoDescription = txtYTDescription.Text;
            obj.PortalID = PortalID;
            obj.UserModuleID = UserModuleID;
            urlid = lblLink.Text;
            obj.UrlID=urlid;
            if (urlid != "")
            {
                VideoController ct = new VideoController();
                bool chk = ct.checkDuplicateID(lblLink.Text,GetPortalID,int.Parse(SageUserModuleID));
                if (chk == true)
                {
                    VideoDataProvider Ctl = new VideoDataProvider();
                    Ctl.AddYoutubeUrl(obj);
                    ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/VideoGallery/ModuleLocalText", "LinkSaveSuccessfully"), "", SageMessageType.Success);
                    txtYoutubeVieoTitle.Text = string.Empty;
                    txtYTDescription.Text = string.Empty;
                }
                else
                {
                    ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/VideoGallery/ModuleLocalText", "LinkAleradyExit"), "", SageMessageType.Alert);
                }
            }
            else
            {
                ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/VideoGallery/ModuleLocalText", "Nolinkfound"), "", SageMessageType.Alert);
            }
            DivSaveYoutubeVideo.Visible = true;
            LoadYoutubeVideoList();
            LoadYTEmbeddedVideo();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void RepeaterTube_ItemCommand1(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.Equals("View"))
        {
            PlayVideo(e.CommandArgument.ToString());
            divSaveYtLink.Visible = true;
        }
    }

    protected void RepeaterTube_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {

        if (RepeaterTube.Items.Count < 1)
        {
            if (e.Item.ItemType == ListItemType.Footer)
            {
                Label lblFooter = (Label)e.Item.FindControl("lblEmptyData");
                lblFooter.Visible = true;
            }

        }
        else
        {

           //string ytt=((Label))e.Item.FindControl("lblYoutubeTitle")).text
           // ((Label)e.Item.FindControl("RatingLabel")).Text = "<b>***Good***</b>";
           // string videotitle = DataFile;
           // lblytTitle.Text = videotitle.Substring(0, 20).ToString();
        }
    }

    private void UpdateDefaultVideo()
    {
        try
        {
            string CheckedItem = "";
            foreach (GridViewRow grdRow in GdvVideoList.Rows)
            {
                int VideoID = 0;
                HiddenField hdnVideoId = grdRow.FindControl("hdfDefaultSageVideo") as HiddenField;
                VideoID = Convert.ToInt32(hdnVideoId.Value);
                RadioButton CheckActive = grdRow.FindControl("radioSageVideo") as RadioButton;
                if (CheckActive.Checked == true)
                {
                    CheckedItem = "True";
                }
                else
                {
                    CheckedItem = "False";
                }
                VideoDataProvider Vclt = new VideoDataProvider();
                Vclt.UpdateDefaultVideo(VideoID, CheckedItem);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void LoadYTSearchVideo(string VdieoTitle)
    {
        try
        {
            VideoController clt = new VideoController();
            GdvYoutube.DataSource = clt.SearchYTVideo(VdieoTitle);
            GdvYoutube.DataBind();
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    private void LoadSageSearchVideo(string VdieoTitle)
    {
        try
        {
            VideoController clt = new VideoController();
            GdvVideoList.DataSource = clt.SearchSageVideo(VdieoTitle);
            GdvVideoList.DataBind();
        }
        catch (Exception e)        
        {
            throw e;
        }
    }

    private void UpdateYTDefaultVideo()
    {
        try
        {
            string CheckedItem = "";
            foreach (GridViewRow grdRow in GdvYoutube.Rows)
            {
                int VideoID = 0;
                HiddenField hdnVideoId = grdRow.FindControl("hdfDefaultYTVideo") as HiddenField;
                VideoID = Convert.ToInt32(hdnVideoId.Value);
                RadioButton CheckActive = grdRow.FindControl("radioYTVideo") as RadioButton;
                if (CheckActive.Checked == true)
                {
                    CheckedItem = "True";
                }
                else
                {
                    CheckedItem = "False";
                }
                VideoDataProvider Vclt = new VideoDataProvider();
                Vclt.UpdateDefaultYTVideo(VideoID, CheckedItem);
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void imgbtnSageSearch_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            string VdieoTitle = txtSearchSageVideo.Text;
            LoadSageSearchVideo(VdieoTitle);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void imbYTDefaultVideo_Click(object sender, ImageClickEventArgs e)
    {

    }

    protected void imgbtnYTvideo_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            string VdieoTitle = txtSearchYTVideo.Text;
                LoadYTSearchVideo(VdieoTitle); 
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void GdvYoutube_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GdvYoutube.PageIndex = e.NewPageIndex;
        LoadYoutubeVideoList();
    }

    protected void GdvYoutube_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            int OprationID = Int32.Parse(e.CommandArgument.ToString());
            switch (e.CommandName.ToString())
            {
                case "Delete":
                    DeleteYoutubeVideo(OprationID);
                    break;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void GdvYoutube_RowDataBound(object sender, GridViewRowEventArgs e)
    {   
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            ImageButton imgDelete = (ImageButton)e.Row.FindControl("imgDelete");
            RadioButton rdbtnIsActive = (RadioButton)e.Row.FindControl("radioYTVideo");
            if (rdbtnIsActive.Checked)
            {
                imgDelete.Visible = false;
            }
            
        }    
    }

    protected void GdvYoutube_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void GdvYoutube_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void GdvSageEmbedded_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GdvSageEmbedded.PageIndex = e.NewPageIndex;
        LoadSageEmbeddedVideo();
    }

    protected void GdvSageEmbedded_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }

    protected void GdvSageEmbedded_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void GdvSageEmbedded_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void GdvSageEmbedded_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }

    protected void imbSaveSageEmbeddedList_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            UpdateEmbeddedList();
            ddlSagePlayerSize.Visible = true;
            ClearText();
            ddlSagePlayerSize.SelectedValue = "0";
        }
        catch(Exception ex)
        {
            throw ex;
        }
    }
      
    protected void imbSaveYTEmbeddedList_Click(object sender, ImageClickEventArgs e)
    {
        UpdateEmbeddedYTList();
        ddlYtPlayerSize.Visible = true;      
        ddlYtPlayerSize.SelectedValue = "0";
    }

    protected void GdvYoutubeEmbeddedList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GdvYoutubeEmbeddedList.PageIndex = e.NewPageIndex;
        LoadYTEmbeddedVideo();
    }

    protected void GdvYoutubeEmbeddedList_RowCommand(object sender, GridViewCommandEventArgs e)
    {

    }

    protected void GdvYoutubeEmbeddedList_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void GdvYoutubeEmbeddedList_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }

    protected void GdvYoutubeEmbeddedList_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    private void UpdateEmbeddedList()
    {
        try
        {
            string CheckedItem = "";
            foreach (GridViewRow grdRow in GdvSageEmbedded.Rows)
            {
                string size;
                string hight;
                string width;
                int VideoID = 0;
                HiddenField hdnVideoId = grdRow.FindControl("hdfEmbededVideoID") as HiddenField;
                VideoID = Convert.ToInt32(hdnVideoId.Value);
                CheckBox CheckActive = grdRow.FindControl("chkEmbeddedVideo") as CheckBox;
                if (CheckActive.Checked == true)
                {
                    CheckedItem = "True";
                }
                else
                {
                    CheckedItem = "False";
                }
                VideoDataProvider Vclt = new VideoDataProvider();
                VideoInfo obj = new VideoInfo();
                hight = txtSageHight.Text;
                width = txtSageWidth.Text;
                if (hight == "" && width == "")
                {
                    size = ddlSagePlayerSize.SelectedItem.Text;
                }
                else
                {
                    size = hight + 'x' + width;
                }
                Vclt.UpdateSageEmbededList(VideoID, CheckedItem, size);
                ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/VideoGallery/ModuleLocalText", "SaveSelectedSageEmbeddedVideo"), "", SageMessageType.Success);

            }
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    private void UpdateEmbeddedYTList()
    {
        try
        {
            string CheckedItem = "";
            foreach (GridViewRow grdRow in GdvYoutubeEmbeddedList.Rows)
            {
                int VideoID = 0;
                string size;
                string H;
                string W;
                HiddenField hdnVideoId = grdRow.FindControl("hdfYTEmbeddedVideoID") as HiddenField;
                VideoID = Convert.ToInt32(hdnVideoId.Value);
                CheckBox CheckActive = grdRow.FindControl("chkYoutubeEmbeddedVideo") as CheckBox;
                if (CheckActive.Checked == true)
                {
                    CheckedItem = "True";
                }
                else
                {
                    CheckedItem = "False";
                }

                VideoDataProvider Vclt = new VideoDataProvider();
                YoutubeVideoInfo obj = new YoutubeVideoInfo();
                H = txtYtHight.Text;
                W = txtYtWidth.Text;
                if (H == "" && W == "")
                {
                    size = ddlYtPlayerSize.SelectedItem.Text;
                }
                else
                {
                    size = H + 'x' + W;
                }
                Vclt.UpdateYTEmbededList(VideoID, CheckedItem, size);
                ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/VideoGallery/ModuleLocalText", "SaveSelectedYTEmbeddedVideo"), "", SageMessageType.Success);
            }
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    //protected void rdnEmbed_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        if (rdnEmbed.SelectedValue == "0")
    //        {
    //            pnlGallery.Visible = true;
    //            pnlEmbeded.Visible = false;
    //        }
    //        else
    //        {
    //            pnlEmbeded.Visible = true;
    //            pnlGallery.Visible = false;
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //}

    protected void GdvEmbeddedLink_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GdvEmbeddedLink.PageIndex = e.NewPageIndex;
        LoadEmbeddedVideoCode();
    }

    protected void GdvEmbeddedLink_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {          
           
            int OprationID = Int32.Parse(e.CommandArgument.ToString());           
            switch (e.CommandName.ToString())
            {
                case "Delete":
                    DeleteEmbedList(OprationID);
                    break; 
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
   
    protected void GdvEmbeddedLink_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                ImageButton ImageId = (ImageButton)e.Row.FindControl("imgEdit");
                //ImageButton imgDelete = (ImageButton)e.Row.FindControl("imgDelete");
                //if (imgDelete != null)
                //{
                //    imgDelete.Attributes.Add("onclick", "javascript:return " +
                //        "confirm('Are you sure to delete?')");
                //}

                ImageId.Attributes.Add("onclick", "javascript:return " + "showPopup1(this);");

            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void GdvEmbeddedLink_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void GdvEmbeddedLink_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    private void LoadEmbeddedVideoCode()
    {
        try
        {
            VideoController clt = new VideoController();
            GdvEmbeddedLink.DataSource = clt.GetEmbeddedVideoCode(PortalID,UserModuleID);
            GdvEmbeddedLink.DataBind();
        }
        catch (Exception e)
        {
            throw e;
        }

    }

    private void DeleteEmbedList(int EmbeddedVideoID)
    {
        VideoDataProvider clt = new VideoDataProvider();
        clt.DeleteEmbeddedVideo(EmbeddedVideoID);
        ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/VideoGallery/ModuleLocalText", "DeleteEmbedVideo"), "", SageMessageType.Success);
        LoadEmbeddedVideoCode();

    }
        
    protected void imbbtnSaveCheckedEmbeddedList_Click(object sender, ImageClickEventArgs e)
    {
        UpdateEmbeddedVideoList();

    }

    private void UpdateEmbeddedVideoList()
    {
        try
        {
            string CheckedItem = "";
            foreach (GridViewRow grdRow in GdvEmbeddedLink.Rows)
            {
                int EmbeddedID = 0;
                HiddenField hdnVideoId = grdRow.FindControl("hdfEmbeddedCode") as HiddenField;
                EmbeddedID = Convert.ToInt32(hdnVideoId.Value);
                CheckBox CheckActive = grdRow.FindControl("chkEmbeddedVideoCode") as CheckBox;
                if (CheckActive.Checked == true)
                {
                    CheckedItem = "True";
                }
                else
                {
                    CheckedItem = "False";
                }
                VideoDataProvider Vclt = new VideoDataProvider();
                Vclt.UpdateEmbededVideoList(EmbeddedID, CheckedItem);
            }
        }
        catch (Exception e)
        {
            throw e;
        }
    }  
  
    protected void ddlRecordsPerPage_SelectedIndexChanged(object sender, EventArgs e)
    {
        GdvVideoList.PageSize = int.Parse(ddlRecordsPerPage.SelectedValue.ToString());
        LoadSageVideo();
    }

    protected void ddlYtRecordperPage_SelectedIndexChanged(object sender, EventArgs e)
    {
        GdvYoutube.PageSize = int.Parse(ddlYtRecordperPage.SelectedValue.ToString());
        LoadYoutubeVideoList();
    }

    protected void ddlEmbeddedPagerSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        GdvEmbeddedLink.PageSize = int.Parse(ddlEmbeddedPagerSize.SelectedValue.ToString());
        LoadEmbeddedVideoCode();
    }

    protected void imbbtnSearchEmbeddedVideo_Click(object sender, ImageClickEventArgs e)
    {
        string searchType = ddlSearchtype.SelectedItem.Text;
        string SearchText = txtSearchEmbeddedVideo.Text;
        LoadEmbeddedVideoList(searchType,SearchText);
    }

    protected void ddlSearchtype_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    private void LoadEmbeddedVideoList(string Type, string SearchText)
    {
        try
        {
            VideoController vclt = new VideoController();
            GdvEmbeddedLink.DataSource = vclt.SearchEmbeddedVideoByType(Type,SearchText);
            GdvEmbeddedLink.DataBind();

        }
        catch (Exception e)
        {
           throw e;
        }
    }

    protected void ddlytPageRecord_SelectedIndexChanged(object sender, EventArgs e)
    {
        GdvYoutubeEmbeddedList.PageSize = int.Parse(ddlytPageRecord.SelectedValue.ToString());
        LoadYTEmbeddedVideo();
    }

    protected void ddlSageVideoPageRecord_SelectedIndexChanged(object sender, EventArgs e)
    {
        GdvSageEmbedded.PageSize = int.Parse(ddlSageVideoPageRecord.SelectedValue.ToString());
        LoadSageEmbeddedVideo();
    }

    protected void imgbtnSageEmbedded_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            string VdieoTitle = txtSearchSageEmbeddedVideo.Text;
            LoadSageEmbeddedVideo(VdieoTitle);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void LoadSageEmbeddedVideo(string VdieoTitle)
    {
        try
        {
            VideoController clt = new VideoController();
            GdvSageEmbedded.DataSource = clt.SearchSageEmbeddedVideo(VdieoTitle);
            GdvSageEmbedded.DataBind();
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    protected void imgbtnSearchYTEmbedded_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            string VdieoTitle = txtYTEmbeddedVideo.Text;
            LoadYTSearchEmbeddedVideo(VdieoTitle);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void LoadYTSearchEmbeddedVideo(string VdieoTitle)
    {
        try
        {
            VideoController clt = new VideoController();
            GdvYoutubeEmbeddedList.DataSource = clt.SearchYTEmbeddedVideo(VdieoTitle);
            GdvYoutubeEmbeddedList.DataBind();
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    protected void GdvEmbeddedLink_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }

   
}
