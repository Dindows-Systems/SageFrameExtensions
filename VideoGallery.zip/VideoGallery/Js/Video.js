﻿(function($) {
    $.createVideoGallery = function(p) {
        p = $.extend
        ({

            VideoUrlpath: '',
            width: '',
            height: '',
            ytWidth: '',
            ytHeight: '',
            defid: '',
            PortalID: '',
            UserModuleID: ''
        }, p);

        GetSageDefaultVideo();
        GetVideoList();
        GetEmbedVideo();
        GetEmbeddedVideosList();
        $('#imbSageVideoSearch_' + p.UserModuleID + '').click(function() {
            SearchVideo();
        });
        $('ul#ulSelectedYTVideos').easyPaginate({
            step: 4
        });

        $('#YTpagingList').pajinate({
            num_page_links_to_display: 3,
            items_per_page: 10
        });

        $('#txtSearch_' + p.UserModuleID + '').keypress(function(e) {
            if (e.which == 13) {
                SearchVideo();
            }
        });

        function clickButton(e, buttonid) {
            var evt = e ? e : window.event;
            var bt = document.getElementById(buttonid);
            if (bt) {
                if (evt.keyCode == 13) {
                    bt.click();
                    return false;
                }
            }
        }

        var videoName = '';
        function InitVideo(video, Image) {

            var playerFlv = new SWFObject(p.VideoUrlpath + 'player.swf', "Player", "500", "350", "9");
            playerFlv.addParam('allowfullscreen', 'true');
            playerFlv.addVariable("screencolor", "white");
            playerFlv.addParam('wmode', 'opaque');
            playerFlv.addVariable("stretching", "uniform");
            playerFlv.addParam("allowscriptaccess", "always");
            playerFlv.addVariable("enableJavascript", "true");
            playerFlv.addVariable("image", '' + p.VideoUrlpath + 'ThumbnailImage/Large/' + Image);
            playerFlv.addVariable("file", p.VideoUrlpath + 'VideoFile/' + video);

            playerFlv.write('player2_' + p.UserModuleID + '');
        }

        function GetVideoList() {
            $.ajax({
                type: "POST",
                url: '' + p.VideoUrlpath + 'WebService.asmx/GetVideos',
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify({ PortalID: p.PortalID, UserModuleID: p.UserModuleID }),
                dataType: "json",

                success: function(msg) {
                    var data = msg.d;
                    var htmlElements = '';
                    var file = '';
                    $.each(data, function(index, item) {
                        file = p.VideoUrlpath + 'ThumbnailImage/Small/' + item.ThumbnailImage;
                        $.ajax({

                            url: file,
                            type: 'HEAD',
                            async: false,
                            error: function() {

                                //default image load
                                htmlElements += '<li><img alt="no preview available" src="' + p.VideoUrlpath + 'ThumbnailImage/DefaultImage/DefaultSmallThumb.jpg" title="' + item.VideoName + '"/></li>';

                            },
                            success: function() {
                                htmlElements += '<li><img alt="no preview available" src="' + file + '" title="' + item.VideoName + '"/></li>';
                            }
                        });
                        videoid = item.VideoID;
                    });

                    $('#ulSelectedVidList_' + p.UserModuleID + '').html(htmlElements);
                    $('ul#ulSelectedVidList_' + p.UserModuleID + '').easyPaginate({

                        step: 3
                    });
                },
                error: function(msg) { }
            });
        }

        $('#ulSelectedVidList_' + p.UserModuleID + ' li ').live("click", function() {
            videoName = '';
            videoName = $(this).find('img').attr('title') + '.flv';
            var imagepath = $(this).find('img').attr('title') + '.jpg';
            InitVideo(videoName, imagepath);
            var x = p.defid;
            document.getElementById(p.defid).value = videoName;
        });


        function SearchVideo() {
            var searchText = $('#txtSearch_' + p.UserModuleID + '').val();
            if (searchText == "") {
                alert("enter search text");
                return false;
            }
            $.ajax({
                type: "POST",
                url: '' + p.VideoUrlpath + 'WebService.asmx/GetSearchVideos',
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify({ txtvalue: searchText, PortalID: p.PortalID, UserModuleID: p.UserModuleID }),
                dataType: "json",
                success: function(msg) {
                    var data = msg.d;
                    var videoElements = '';
                    var filenamepath = '';
                    if (data.length > 10) {

                        if (msg.d.length > 0) {
                            $.each(data, function(index, item) {

                                filenamepath = p.VideoUrlpath + 'ThumbnailImage/Small/' + item.ThumbnailImage;
                                $.ajax({
                                    url: filenamepath,
                                    type: 'HEAD',
                                    async: false,
                                    error: function() {
                                        //default image load
                                        videoElements += '<li><img alt="no preview available" src="' + p.VideoUrlpath + 'ThumbnailImage/DefaultImage/DefaultSmallThumb.jpg" title="' + item.VideoName + '"/></br></br><b><span>' + item.VideoName + '</span></b></li>';

                                    },
                                    success: function() {
                                        videoElements += '<li><img alt="no preview available" src="' + filenamepath + '" title="' + item.VideoName + '"/></br></br><b><span>' + item.VideoName + '</span></b></li>';
                                    }
                                });
                            });
                            $('#ulSearchVideo_' + p.UserModuleID + '').html(videoElements);
                            $('#PageNav_' + p.UserModuleID + '').show();
                        }
                        else {
                            $('#ulSearchVideo_' + p.UserModuleID + '').html("Video not found");
                            $('#PageNav_' + p.UserModuleID + '').hide();
                        }

                        $('#SagepagingList_' + p.UserModuleID + '').pajinate({
                            num_page_links_to_display: 5,
                            items_per_page: 10
                        });
                    }
                    else {

                        if (msg.d.length > 0) {
                            $.each(data, function(index, item) {

                                filenamepath = p.VideoUrlpath + 'ThumbnailImage/Small/' + item.ThumbnailImage;
                                $.ajax({
                                    url: filenamepath,
                                    type: 'HEAD',
                                    async: false,
                                    error: function() {
                                        //default image load
                                        videoElements += '<li><img alt="no preview available" src="' + p.VideoUrlpath + 'ThumbnailImage/DefaultImage/DefaultSmallThumb.jpg" title="' + item.VideoName + '"/></br></br><b><span>' + item.VideoName + '</span></b></li>';

                                    },
                                    success: function() {
                                        videoElements += '<li><img alt="no preview available" src="' + filenamepath + '" title="' + item.VideoName + '"/></br></br><b><span>' + item.VideoName + '</span></b></li>';
                                    }
                                }); //                           
                            });
                            $('#ulSearchVideo_' + p.UserModuleID + '').html(videoElements);
                            $('#PageNav_' + p.UserModuleID + '').hide();
                        }
                        else {
                            $('#PageNav_' + p.UserModuleID + '').hide();
                            $('#ulSearchVideo_' + p.UserModuleID + '').html("Video not found");
                        }
                        $('#SagepagingList_' + p.UserModuleID + '').pajinate({
                            num_page_links_to_display: 5,
                            items_per_page: 10
                        });
                    }
                },
                error: function() {
                }
            });
        }


        $('#ulSearchVideo_' + p.UserModuleID + ' li').live("click", function() {
            videoName = $(this).find('span').html() + '.flv';
            var imagepath = $(this).find('span').html() + '.jpg';
            InitVideo(videoName, imagepath);
            var x = p.defid;
            document.getElementById(p.defid).value = videoName;

        });


        function EmbedVideo(videoName, object, imagepath) {
            var videopath = p.VideoUrlpath + "VideoFile/" + videoName;
            var playerFlv = new SWFObject(p.VideoUrlpath + 'player.swf', "Embedplayer", p.width, p.height, "9");
            playerFlv.addVariable("screencolor", "white");
            playerFlv.addParam('allowfullscreen', 'true');
            playerFlv.addVariable("image", '' + p.VideoUrlpath + 'ThumbnailImage/Large/' + imagepath);
            playerFlv.addVariable("file", videopath);
            playerFlv.write(object);
        }


        function GetEmbedVideo() {
            $.ajax({
                type: "POST",
                url: '' + p.VideoUrlpath + 'WebService.asmx/GetSageEmbeddedList',
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify({ PortalID: p.PortalID, UserModuleID: p.UserModuleID }),
                dataType: "json",
                success: function(msg) {
                    var data = msg.d;
                    var html = '';
                    var filepath = '';
                    $.each(data, function(index, item) {
                        filepath = p.VideoUrlpath + 'ThumbnailImage/Medium/' + item.ThumbnailImage;
                        $.ajax({
                            url: filepath,
                            type: 'HEAD',
                            async: false,
                            error: function() {
                                //default image load
                                html += '<li id="li_' + index + p.UserModuleID + '" style="height:auto"><img id="li_' + index + p.UserModuleID + '" alt="no image available" src="' + p.VideoUrlpath + 'ThumbnailImage/DefaultImage/DefaultSmallThumb.jpg" title="' + item.VideoName + '" /></li>';

                            },
                            success: function() {
                                html += '<li id="li_' + index + p.UserModuleID + '" style="height:auto"><img id="li_' + index + p.UserModuleID + '" alt="no image available" src="' + filepath + '" title="' + item.VideoName + '" /></li>';
                            }
                        });
                    });
                    $('#embedplayer_' + p.UserModuleID + '').append(html);

                },
                error: function(msg) { }
            });
        }

        $('#embedplayer_' + p.UserModuleID + ' li img').live("click", function() {
            var videoName = $(this).attr('title') + '.flv';
            var id = $(this).attr("id");
            var imagepath = $(this).attr('title') + '.jpg';
            EmbedVideo(videoName, id, imagepath);
        });


        function GetEmbeddedVideosList() {
            $.ajax({
                type: "POST",
                url: '' + p.VideoUrlpath + 'WebService.asmx/GetEmbeddedVideoList',
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify({ PortalID: p.PortalID, UserModuleID: p.UserModuleID }),
                dataType: "json",
                success: function(msg) {
                    var data = msg.d;
                    var html = '';
                    var iframeLink = '';
                    var embeddedcode = '';
                    var wmode = '';
                    $.each(data, function(index, item) {
                        wmode = "wmode=transparent";
                        embeddedcode = item.EmbeddedCode;
                        ifr_source = $(embeddedcode).attr('src');
                        if (ifr_source != null) {
                            if (ifr_source.indexOf('?') != -1) {
                                iframeLink = embeddedcode.replace(ifr_source, ifr_source + '&' + wmode);
                                html += '<li>' + iframeLink + '</li>';
                            }
                            else {
                                iframeLink = embeddedcode.replace(ifr_source, ifr_source + '?' + wmode);
                                html += '<li>' + iframeLink + '</li>';
                            }

                        }
                        else {
                            var embed = embeddedcode.replace('<embed', '<embed wmode="transparent"');
                            html += '<li>' + embed + '</li>';
                        }
                    });
                    $('#selectedEmbeddedVideos_' + p.UserModuleID + '').html(html);
                },
                error: function(msg) { }
            });
        }


        function GetSageDefaultVideo() {
            $.ajax({
                type: "POST",
                url: '' + p.VideoUrlpath + 'WebService.asmx/GetSageDefaultVideo',
                contentType: "application/json; charset=utf-8",
                data: JSON.stringify({ PortalID: p.PortalID, UserModuleID: p.UserModuleID }),
                dataType: "json",
                success: function(msg) {
                    var data = msg.d;
                    var html = '';
                    $.each(data, function(index, item) {
                        var defaultvideo = item.VideoName + '.flv';
                        var imagepath = item.VideoName + '.jpg';
                        InitVideo(defaultvideo, imagepath);
                        var x = p.defid;

                        document.getElementById(p.defid).value = defaultvideo;
                    });
                },
                error: function(msg) {

                }
            });
        }
    };

    $.fn.SageVideoGallery = function(p) {
        $.createVideoGallery(p);
    };
})(jQuery);




   
   