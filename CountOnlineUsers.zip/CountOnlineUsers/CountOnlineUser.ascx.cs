﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using CountUser;
using SageFrame.Web;

public partial class CountOnlineUser_CountOnlineUser : BaseAdministrationUserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
      
            DispalyOnlineUser();
        
    }
    /// <summary>
    /// 
    /// </summary>
    private void DispalyOnlineUser()
    {       
        CountUserInfo ObjInfo = CountUserDataProvider.GetOnlineUserCount();       
        lblGuests.Text = ObjInfo.AnonymousUser.ToString();
		lblMembers.Text=ObjInfo.LoginUser.ToString();
        
    }

    
   
}
