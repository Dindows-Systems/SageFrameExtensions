﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.PhotoGalleryWithAlbum;
using SageFrame.Web;
using System.Text;
using SageFrame.Shared;


public partial class PhotoGallery_Settings : BaseAdministrationUserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PageLoadLogic();
            AddImageUrls();
        }
    }

    #region "User Defined Methods"
    private void PageLoadLogic()
    {
        pnlPhotoSettings.Visible = true;
        ReadSettings();
        txtMaxFileSize.Attributes.Add("onkeypress", "return KeyTypeCheck(event);");
        txtSmallThumbnailSize.Attributes.Add("onkeypress", "return KeyTypeCheck(event);");
        txtMediumThumbnailSize.Attributes.Add("onkeypress", "return KeyTypeCheck(event);");
        txtLargeThumbnailSize.Attributes.Add("onkeypress", "return KeyTypeCheck(event);");
        PhotoGalleryController con = new PhotoGalleryController();
        ddlImagZoomType.DataSource = con.GetJsEffects();   
        ddlImagZoomType.DataTextField = "Value";
        ddlImagZoomType.DataValueField = "Key";          
        ddlImagZoomType.DataBind();              
    }

    private void AddImageUrls()
    {
        imbSave.ImageUrl = GetTemplateImageUrl("imgsave.png", true);
    }

    private void SaveSettings()
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            StringBuilder sbSettingKey = new StringBuilder();
            StringBuilder sbSettingValue = new StringBuilder();
            sbSettingKey.Append("Extension" + '#');
            sbSettingValue.Append(txtextension.Text.Trim()+"#");
            sbSettingKey.Append("MaxFileSize" + '#');
            sbSettingValue.Append(txtMaxFileSize.Text.Trim()+"#");
            sbSettingKey.Append("SmallThumbnailSize" + "#");
            sbSettingValue.Append(txtSmallThumbnailSize.Text.Trim()+"#");
            sbSettingKey.Append("MediumThumbnailSize" + "#");
            sbSettingValue.Append(txtMediumThumbnailSize.Text.Trim()+"#");
            sbSettingKey.Append("LargeThumbnailSize" + "#");
            sbSettingValue.Append(txtLargeThumbnailSize.Text.Trim() + "#");
            sbSettingKey.Append("ShortDescription" + "#");
            sbSettingValue.Append(rblShortDescription.SelectedValue + "#");
            sbSettingKey.Append("FullDescription" + "#");
            sbSettingValue.Append(rblFullDescription.SelectedValue + "#");            
            sbSettingKey.Append("ImageZoomType");
            sbSettingValue.Append(ddlImagZoomType.SelectedValue);
            string SettingKeys = sbSettingKey.ToString();            
            string SettingValues = sbSettingValue.ToString();
            PhotoGalleryController objPG = new PhotoGalleryController();
            objPG.SaveSettings(SettingKeys, SettingValues, UserModuleID, GetPortalID);
            ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "SettingsSavedSuccessfully"), "", SageMessageType.Success);                     
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void ReadSettings()
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }            
            PhotoGalleryController objPG = new PhotoGalleryController();
            List<PhotoGallerySettingInfo> objSettings = objPG.GetAllSettings(UserModuleID,GetPortalID);
            foreach (PhotoGallerySettingInfo objInf in objSettings)
            {
                string strKey = objInf.SettingKey;
                switch (strKey)
                {
                    case "Extension":
                        txtextension.Text =objInf.SettingValue;
                        break;
                    case "MaxFileSize":
                        txtMaxFileSize.Text = objInf.SettingValue;
                        break;
                    case "SmallThumbnailSize":
                        txtSmallThumbnailSize.Text = objInf.SettingValue;
                        break;
                    case "MediumThumbnailSize":
                        txtMediumThumbnailSize.Text = objInf.SettingValue;
                        break;
                    case "LargeThumbnailSize":
                        txtLargeThumbnailSize.Text = objInf.SettingValue;
                        break;
                    case "ShortDescription":
                        rblShortDescription.SelectedValue = objInf.SettingValue; 
                        break;
                    case "FullDescription":
                        rblFullDescription.SelectedValue = objInf.SettingValue;
                        break;
                    case "ImageZoomType":
                        ddlImagZoomType.SelectedValue = (objInf.SettingValue);
                        break;
                }
            }             
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }
    #endregion

    #region "Control Events" 
  
    protected void imbSave_Click(object sender, ImageClickEventArgs e)
    {
        SaveSettings();
    }
    #endregion
}
