﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using SageFrame.PhotoGalleryWithAlbum;
using SageFrame.Web;
using System.Text;
using System.Data;


public partial class PhotoGallery_ViewImage : BaseAdministrationUserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {           
            IncludeFiles();
            LoadAllContent();
            GetImageUrls();
        }
    }
   
    #region "User Defined Method"
    private void GetImageUrls()
    {
        imbBackToAlbum.ImageUrl = GetTemplateImageUrl("imgview.png", true);
    }

    private void LoadAllContent()
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            PhotoGalleryController con = new PhotoGalleryController();
            List<PhotoAlbumInfo> objAlbumInfo = con.GetAllPhotoAlbums(UserModuleID, GetPortalID);
            if (objAlbumInfo.Count > 0)
            {
                rptAlbumCollection.DataSource = objAlbumInfo;
                rptAlbumCollection.DataBind();
            }
            else
            {
                ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "NoAlbumFound"), "", SageMessageType.Alert);
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void IncludeFiles()
    {
        string strImageZoomingScript = string.Empty;
        PhotoGalleryController objPG = new PhotoGalleryController();
        int UserModuleID = 0;
        if (!string.IsNullOrEmpty(SageUserModuleID))
        {
            UserModuleID = Int32.Parse(SageUserModuleID);
        }
        List<PhotoGallerySettingInfo> objPS = objPG.GetAllSettings(UserModuleID, GetPortalID);
        foreach (PhotoGallerySettingInfo objInf in objPS)
        {
            string strKey = objInf.SettingKey;
            switch (strKey)
            {
                case "ImageZoomType":
                    strImageZoomingScript = objInf.SettingValue;
                    break;
            }
        }     
        IncludeJsTop("PhotoGalleryWithAlbum", "/Modules/PhotoGalleryWithAlbum/highslide/" + strImageZoomingScript);        
        IncludeCss("PhotoGalleryWithAlbum", "/Modules/PhotoGalleryWithAlbum/highslide/module.css");
      
        if (strImageZoomingScript == "AdvancedImageZoom.js")
        {
            Literal LitSageScript = this.Page.FindControl("LitSageScript") as Literal;
            if (LitSageScript != null)
            {
                StringBuilder strAdvancedImageZoomingScripts = new StringBuilder();
                strAdvancedImageZoomingScripts.Append("<script type=\"text/javascript\">");
                strAdvancedImageZoomingScripts.Append("hs.graphicsDir = './Modules/PhotoGalleryWithAlbum/highslide/graphics/';");
                strAdvancedImageZoomingScripts.Append("hs.align = 'center';");
                strAdvancedImageZoomingScripts.Append("hs.transitions = ['expand', 'crossfade'];");
                strAdvancedImageZoomingScripts.Append("hs.wrapperClassName = 'dark borderless floating-caption';");
                strAdvancedImageZoomingScripts.Append("hs.fadeInOut = true;");
                strAdvancedImageZoomingScripts.Append("hs.dimmingOpacity = .75;");

                strAdvancedImageZoomingScripts.Append("if (hs.addSlideshow) hs.addSlideshow({");
                strAdvancedImageZoomingScripts.Append("interval: 5000, repeat: false, useControls: true, fixedControls: 'fit', ");
                strAdvancedImageZoomingScripts.Append("overlayOptions: { opacity: .6, position: 'bottom center', hideOnMouseOut: true }});");
                strAdvancedImageZoomingScripts.Append("</script>");
                string strScript = strAdvancedImageZoomingScripts.ToString();
                if (!LitSageScript.Text.Contains(strScript))
                {
                    LitSageScript.Text += strScript;
                }
            }
        }
        else if (strImageZoomingScript == "SimpleImageZoom.js")
        {
            Literal LitSageScript = this.Page.FindControl("LitSageScript") as Literal;
            if (LitSageScript != null)
            {
                StringBuilder strSimpleImageZoomingScripts = new StringBuilder();
                strSimpleImageZoomingScripts.Append("<script type=\"text/javascript\">");
                strSimpleImageZoomingScripts.Append("hs.graphicsDir = './Modules/PhotoGalleryWithAlbum/highslide/graphics/';");
                strSimpleImageZoomingScripts.Append("hs.wrapperClassName = 'wide-border';");
                strSimpleImageZoomingScripts.Append("</script>");
                string strScript = strSimpleImageZoomingScripts.ToString();
                if (!LitSageScript.Text.Contains(strScript))
                {
                    LitSageScript.Text += strScript;
                }
            }
        }
    }   

    private void HideAll()
    {
        pnlAlbumCollection.Visible = false;
        pnlShowImage.Visible = false;
    }

    public void GetAlbumsAllImages(int PhotoAlbumID)
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }           
            PhotoGalleryController con = new PhotoGalleryController();
            List<PhotoGalleryInfo> objphoto = con.GetPhotoGalleryListByAlbum(PhotoAlbumID, UserModuleID, GetPortalID);
            PhotoAlbumInfo objAlbumInfo = con.GetPhotoAlbumInfoByID(PhotoAlbumID, UserModuleID, GetPortalID);            
            if (objphoto.Count > 0)
            {
                rptImageView.DataSource = objphoto;
                rptImageView.DataBind();
                HideAll();
                pnlShowImage.Visible = true;
            }
            else if (objphoto.Count == 0)
            {
                HideAll();
                pnlShowImage.Visible = false;
                ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "NoImageInAlbum"), "", SageMessageType.Alert);
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }        
    }   

    public string GetImage(string strThumbnailPath)
    {
        try
        {
            string actualFile = strThumbnailPath.Substring(strThumbnailPath.LastIndexOf("\\") + 1);
            string FullImagePath = ("~/Modules/PhotoGalleryWithAlbum/ImageFiles/" + actualFile);
            return FullImagePath;
        }
        catch (Exception ex)
        {
            ProcessException(ex);
            return "";
        }
    }
    public string GetImageCover(string PhotoAlbumID)
    {
        string strImageCoverPath = string.Empty;
        try
        {
            int AlbumID = Int32.Parse(PhotoAlbumID);
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            
            PhotoGalleryController con = new PhotoGalleryController();
            PhotoGalleryInfo objInfo = con.GetPhotoGalleryInfoByAlbumID(AlbumID, UserModuleID, GetPortalID);
            if (objInfo != null)
            {
                strImageCoverPath = objInfo.PhotoPath;                
            }            
        }
        catch (Exception ex)
        {
            ProcessException(ex);       
        }
        return strImageCoverPath;
    }

    public string GetPhotoGalleryWithAlbumImageUrl(string imageName, bool isServerControl)
    {
        string path = string.Empty;
        if (isServerControl == true)
        {
            path = "~/Modules/PhotoGalleryWithAlbum/ImageFiles/" + imageName;
        }
        else
        {
            path = this.Page.ResolveUrl("~/Modules/PhotoGalleryWithAlbum/ImageFiles/" + imageName);
        }
        return path;
    }
    #endregion

    #region "Control Events"
    protected void rptAlbumCollection_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        try
        {
            ImageButton imbImageCover = (ImageButton)e.Item.FindControl("imbAlbumCover");
            
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType ==
            ListItemType.AlternatingItem)
            {               
                int ID = (Int32)DataBinder.Eval(e.Item.DataItem, "PhotoAlbumID");               
               PhotoGalleryController con = new PhotoGalleryController();
               PhotoGalleryInfo objInfo = con.GetPhotoGalleryInfoByAlbumID(ID, UserModuleID, GetPortalID);
               if (objInfo == null)
               {
                   imbImageCover.ImageUrl = GetPhotoGalleryWithAlbumImageUrl("no-coverimage.jpg", true);
               }
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    protected void rptAlbumCollection_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        int UserModuleID = 0;
        if (!string.IsNullOrEmpty(SageUserModuleID))
        {
            UserModuleID = Int32.Parse(SageUserModuleID);
        }
        ImageButton AlbumCover = (ImageButton)e.Item.FindControl("imbAlbumCover");
        int ID=Int32.Parse(e.CommandArgument.ToString());
        PhotoGalleryController con = new PhotoGalleryController();
        PhotoGalleryInfo objInfo = con.GetPhotoGalleryInfoByAlbumID(ID, UserModuleID, GetPortalID);
        if (e.CommandName == "ImageClick")
        {
                IncludeCssFile("~/Modules/PhotoGalleryWithAlbum/highslide/highslide.css");
                GetAlbumsAllImages(ID);
        }         
    }    
    
    protected void imbBackToAlbum_Click(object sender, ImageClickEventArgs e)
    {
        HideAll();
        pnlAlbumCollection.Visible = true;
    }

    protected void rptImageView_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            bool ShowShortDescription = false, ShowFullDescription = false;

            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType ==
            ListItemType.AlternatingItem)
            {
                HtmlGenericControl pnlShortDescription = (HtmlGenericControl)e.Item.FindControl("pnlShortDescription");
                HtmlGenericControl pnlFullDescription = (HtmlGenericControl)e.Item.FindControl("pnlFullDescription");

                PhotoGalleryController objPG = new PhotoGalleryController();
                List<PhotoGallerySettingInfo> objPS = objPG.GetAllSettings(UserModuleID, GetPortalID);
                foreach (PhotoGallerySettingInfo objInf in objPS)
                {
                    string strKey = objInf.SettingKey;
                    switch (strKey)
                    {
                        case "ShortDescription":
                            ShowShortDescription = bool.Parse(objInf.SettingValue);
                            break;
                        case "FullDescription":
                            ShowFullDescription = bool.Parse(objInf.SettingValue);
                            break;

                    }
                }
                if (ShowShortDescription == false)
                {
                    pnlShortDescription.Visible = false;
                }
                if (ShowFullDescription == false)
                {
                    pnlFullDescription.Visible = false;
                }
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }   
    #endregion    
}
