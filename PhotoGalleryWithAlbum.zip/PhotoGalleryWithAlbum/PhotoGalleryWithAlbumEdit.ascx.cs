﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.IO;
using System.Data;
using System.Configuration;
using System.Drawing;
using SageFrame.PhotoGalleryWithAlbum;
using SageFrame.Web;


public partial class PhotoGallery_ShowData : BaseAdministrationUserControl
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            PageLoadLogic();
            AddImageUrls();
        }
        string AllowedExtension = string.Empty;
        int UserModuleID = 0;
        if (!string.IsNullOrEmpty(SageUserModuleID))
        {
            UserModuleID = Int32.Parse(SageUserModuleID);
        }
        PhotoGalleryController objPG = new PhotoGalleryController();
        List<PhotoGallerySettingInfo> objPS = objPG.GetAllSettings(UserModuleID, GetPortalID);
        foreach (PhotoGallerySettingInfo objInf in objPS)
        {
            string strKey = objInf.SettingKey;
            switch (strKey)
            {
                case "Extension":
                    AllowedExtension = objInf.SettingValue;
                    break;
            }
        }
        imbSave.Attributes.Add("onclick", string.Format("return checkfiletype('{0}','{1}','{2}','{3}');", fluImage.ClientID, AllowedExtension, txtTitle.ClientID, hdfIsEdit.ClientID));
        imbSaveAddAlbum.Attributes.Add("onclick", string.Format("return checkalbumvalidation('{0}');", txtAlbumName.ClientID));
    }

    #region "User Defined Method"

    private void PageLoadLogic()
    {
        LoadAllContent();
        LoadAlbums();
    }

    private void LoadAlbums()
    {
        try
        {

            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            PhotoGalleryController photoGalleryController = new PhotoGalleryController();
            List<PhotoAlbumInfo> photoAlbumInfo = photoGalleryController.GetPhotoAlbums(UserModuleID, GetPortalID);
            ddlPhotoAlbum.DataSource = photoAlbumInfo;
            ddlPhotoAlbum.DataValueField = "PhotoAlbumID";
            ddlPhotoAlbum.DataTextField = "AlbumName";
            ddlPhotoAlbum.DataBind();
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void AddImageUrls()
    {
        imbAddNew.ImageUrl = GetTemplateImageUrl("imgadd.png", true);
        imbSave.ImageUrl = GetTemplateImageUrl("imgsave.png", true);
        imbCancel.ImageUrl = GetTemplateImageUrl("imgcancel.png", true);
        imbAddNewAlbum.ImageUrl = GetTemplateImageUrl("imgadd.png", true);
        imbSaveAddAlbum.ImageUrl = GetTemplateImageUrl("imgsave.png", true);
        imbCancelAddAlbum.ImageUrl = GetTemplateImageUrl("imgcancel.png", true);
    }

    private void SaveAlbum()
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            PhotoAlbumInfo paInfo = new PhotoAlbumInfo();
            paInfo.AlbumName = txtAlbumName.Text.Trim();
            paInfo.AlbumDescription = txtAlbumDescription.Text.Trim();
            paInfo.IsActive = true;
            paInfo.IsDeleted = false;
            PhotoGalleryController con = new PhotoGalleryController();
            HideAll();
            if (Session["EditPhotoAlbumID"] != null)
            {
                paInfo.PhotoAlbumID = Int32.Parse(Session["EditPhotoAlbumID"].ToString());
                con.PhotoAlbumAddUpdate(paInfo, UserModuleID, GetPortalID, GetUsername);
            }
            else
            {
                paInfo.PhotoAlbumID = 0;
                con.PhotoAlbumAddUpdate(paInfo, UserModuleID, GetPortalID, GetUsername);

            }
            ClearAll();
            LoadAllContent();
            ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "AlbumSavedSuccessfully"), "", SageMessageType.Success);
            pnlAlbumShow.Visible = true;
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void ClearAll()
    {
        hdfIsEdit.Value = "0";
        hdfEditPhotoPath.Value = string.Empty;
        Session["EditPhotoAlbumID"] = null;
        Session["EditPhotoID"] = null;
        txtTitle.Text = string.Empty;
       // txtShortDescription.Text = string.Empty;
        txtFullDescription.Text = string.Empty;
        txtImageAlt.Text = string.Empty;
        txtAlbumDescription.Text = string.Empty;
        txtAlbumName.Text = string.Empty;
    }

    private void ValidateFileExtension()
    {
        try
        {
            bool toUpdateCover = false;
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            string strVirtualUrl = "~/Modules/PhotoGalleryWithAlbum/ImageFiles/";
            string PhysicalFilePath = Server.MapPath(strVirtualUrl);
            if (!Directory.Exists(PhysicalFilePath))
            {
                Directory.CreateDirectory(PhysicalFilePath);
            }
            string ThumbnailFolders = "~/Modules/PhotoGalleryWithAlbum/ImageFiles/MyThumbnail/";
            string filepath = Server.MapPath(ThumbnailFolders);
            if (!Directory.Exists(filepath))
            {
                Directory.CreateDirectory(filepath);
            }
            int SmallThumbnailSize = 0, MediumThumbnailSize = 0, LargeThumbnailSize = 0;
            string SmallThumbnailImagePath = filepath + "SmallThumbnails\\";
            string MediumThumbnailImagePath = filepath + "MediumThumbnails\\";
            string LargeThumbnailImagePath = filepath + "LargeThumbnails\\";

            PhotoGalleryInfo objphoto = new PhotoGalleryInfo();
            objphoto.Title = txtTitle.Text.Trim();
            objphoto.ShortDescription = "";
            objphoto.FullDescription = txtFullDescription.Text.Trim();
            objphoto.ImageAlt = txtImageAlt.Text.Trim();
            objphoto.UserModuleID = UserModuleID;
            objphoto.PortalID = GetPortalID;
            objphoto.IsActive = true;
            objphoto.IsDeleted = false;
            objphoto.PhotoAlbumID = Int32.Parse(ddlPhotoAlbum.SelectedValue);
            objphoto.IsCover = bool.Parse(rblIsCover.SelectedValue);

            if (bool.Parse(rblIsCover.SelectedValue) == false)
            {
                    toUpdateCover = false;
                    //con.GetPhotoGalleryCoverImageUpdate(objphoto, true);
            }
            else if (bool.Parse(rblIsCover.SelectedValue) == true)
            {
                toUpdateCover = true;
                //con.GetPhotoGalleryCoverImageUpdate(objphoto, false);
            }

            if (Session["EditPhotoID"] != null)
            {
                objphoto.PhotoGalleryID = Int32.Parse(Session["EditPhotoID"].ToString());
                int ID = Int32.Parse(Session["EditPhotoID"].ToString());               

                if (!fluImage.HasFile)
                {
                    objphoto.PhotoPath = hdfEditPhotoPath.Value;
                    SaveToDataBase(objphoto);
                    ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "ImageUpdatedSuccessfully"), "", SageMessageType.Success);
                }
                else
                {
                    string uploadedFile = fluImage.PostedFile.FileName;

                    long MaxFileSize = 0;
                    string AllowedExtension = string.Empty;
                    FileInfo objFI = new FileInfo(uploadedFile);
                    string FileType = objFI.Extension.ToLower();
                    FileType = FileType.Replace(".", "");
                    long FileSize = fluImage.PostedFile.ContentLength;
                    string FullPath = PhysicalFilePath + objFI.Name;

                    PhotoGalleryController objPG = new PhotoGalleryController();
                    List<PhotoGallerySettingInfo> objPS = objPG.GetAllSettings(UserModuleID, GetPortalID);
                    foreach (PhotoGallerySettingInfo objInf in objPS)
                    {
                        string strKey = objInf.SettingKey;
                        switch (strKey)
                        {
                            case "Extension":
                                AllowedExtension = objInf.SettingValue;
                                break;
                            case "MaxFileSize":
                                MaxFileSize = long.Parse(objInf.SettingValue);
                                break;
                            case "SmallThumbnailSize":
                                SmallThumbnailSize = Int32.Parse(objInf.SettingValue);
                                break;
                            case "MediumThumbnailSize":
                                MediumThumbnailSize = Int32.Parse(objInf.SettingValue);
                                break;
                            case "LargeThumbnailSize":
                                LargeThumbnailSize = Int32.Parse(objInf.SettingValue);
                                break;
                        }
                    }


                    if (AllowedExtension.Contains(FileType))
                    {
                        if (FileSize <= MaxFileSize*1000)
                        {
                            string uploadedFileName = fluImage.FileName;
                            string uploadpath = "~\\Modules\\PhotoGalleryWithAlbum\\ImageFiles\\MyThumbnail\\SmallThumbnails\\";
                            string Savefilepath = uploadpath + uploadedFileName;                           
                            fluImage.SaveAs(FullPath);
                            SaveThumbnailImages(FullPath, SmallThumbnailSize, SmallThumbnailImagePath, uploadedFileName);
                            SaveThumbnailImages(FullPath, MediumThumbnailSize, MediumThumbnailImagePath, uploadedFileName);
                            SaveThumbnailImages(FullPath, LargeThumbnailSize, LargeThumbnailImagePath, uploadedFileName);
                            objphoto.PhotoPath = Savefilepath;                           
                            SaveToDataBase(objphoto);
                            ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "ImageUpdatedSuccessfully"), "", SageMessageType.Success);
                        }
                        else
                        {
                            ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "ExceedFileSize"), "", SageMessageType.Alert);
                        }
                    }
                    else
                    {
                        ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "FileTypeNotAllowed"), "", SageMessageType.Alert);
                     
                    }
                }
            }
            else
            {
                if (!fluImage.HasFile)
                {
                    pnlEdit.Visible = true;
                    ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "PleaseSelectFile"), "", SageMessageType.Alert);
                }
                else
                {
                    string uploadedFile = fluImage.PostedFile.FileName;
                    string uploadedFileName = fluImage.FileName;
                    long MaxFileSize = 0;
                    string AllowedExtension = string.Empty;
                    FileInfo objFI = new FileInfo(uploadedFile);
                    string FileType = objFI.Extension.ToLower();
                    FileType = FileType.Replace(".", "");
                    long FileSize = fluImage.PostedFile.ContentLength;
                    string FullPath = PhysicalFilePath + objFI.Name;

                    PhotoGalleryController con = new PhotoGalleryController();
                    List<PhotoGallerySettingInfo> objPS1 = con.GetAllSettings(UserModuleID, GetPortalID);
                    foreach (PhotoGallerySettingInfo objInf in objPS1)
                    {
                        string strKey = objInf.SettingKey;
                        switch (strKey)
                        {
                            case "Extension":
                                AllowedExtension = objInf.SettingValue;
                                break;
                            case "MaxFileSize":
                                MaxFileSize = long.Parse(objInf.SettingValue);
                                break;
                            case "SmallThumbnailSize":
                                SmallThumbnailSize = Int32.Parse(objInf.SettingValue);
                                break;
                            case "MediumThumbnailSize":
                                MediumThumbnailSize = Int32.Parse(objInf.SettingValue);
                                break;
                            case "LargeThumbnailSize":
                                LargeThumbnailSize = Int32.Parse(objInf.SettingValue);
                                break;
                        }
                    }

                    if (AllowedExtension.Contains(FileType))
                    {
                        if (FileSize <= MaxFileSize*1000)
                        {                            
                            string uploadpath = "~\\Modules\\PhotoGalleryWithAlbum\\ImageFiles\\MyThumbnail\\SmallThumbnails\\";
                            string Savefilepath = uploadpath + uploadedFileName;                        
                            fluImage.SaveAs(FullPath);
                            SaveThumbnailImages(FullPath, SmallThumbnailSize, SmallThumbnailImagePath, uploadedFileName);
                            SaveThumbnailImages(FullPath, MediumThumbnailSize, MediumThumbnailImagePath, uploadedFileName);
                            SaveThumbnailImages(FullPath, LargeThumbnailSize, LargeThumbnailImagePath, uploadedFileName);
                            objphoto.PhotoPath = Savefilepath;
                            SaveToDataBase(objphoto);
                            ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "ImageSavedSuccessfully"), "", SageMessageType.Success);
                        }
                        else
                        {
                            ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "ExceedFileSize"), "", SageMessageType.Alert);
                           
                        }
                    }
                    else
                    {
                        ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "FileTypeNotAllowed"), "", SageMessageType.Alert);
                       
                    }
                }
            }
            ClearAll();
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void SaveToDataBase(PhotoGalleryInfo objPhoto)
    {
        PhotoGalleryController con = new PhotoGalleryController();
        con.PhotoGalleryAddUpdate(objPhoto, GetUsername);
        ManageAlbum(Int32.Parse(hdfPhotoAlbumID.Value));

        HideAll();
        pnlShow.Visible = true;
    }

    public void SaveThumbnailImages(string ImageFilePath, int TargetSize, string TargetLocation, string fileName)
    {
        try
        {
            if (!Directory.Exists(TargetLocation))
            {
                Directory.CreateDirectory(TargetLocation);
            }
            string SavePath = string.Empty;
            SavePath = TargetLocation + fileName;
            PictureManager.CreateThmnail(ImageFilePath, TargetSize, SavePath);
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void Save()
    {
        try
        {
            ValidateFileExtension();
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void ShowForm()
    {
        pnlEdit.Visible = true;
    }

    private void HideAll()
    {
        pnlAddAlbum.Visible = false;
        pnlEdit.Visible = false;
        pnlShow.Visible = false;
        pnlAlbumShow.Visible = false;
        divViewImage.Visible = false;
    }

    private void LoadAllContent()
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            PhotoGalleryController con = new PhotoGalleryController();
            List<PhotoAlbumInfo> objphoto = con.GetAllPhotoAlbums(UserModuleID, GetPortalID);
            if (objphoto.Count > 0)
            {
                rptAlbumShow.Visible = true;
                rptAlbumShow.DataSource = objphoto;
                rptAlbumShow.DataBind();
            }
            else if (objphoto.Count == 0)
            {
                rptAlbumShow.Visible = false;
                ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "NoAlbumFound"), "", SageMessageType.Alert);
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void EditRecord(int ID)
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            PhotoGalleryController con = new PhotoGalleryController();
            PhotoGalleryInfo objphoto = con.GetPhotoGalleryInfoByID(ID, UserModuleID, GetPortalID);
            if (objphoto != null)
            {
                ddlPhotoAlbum.SelectedIndex = ddlPhotoAlbum.Items.IndexOf(ddlPhotoAlbum.Items.FindByValue(hdfPhotoAlbumID.Value.ToString()));
                txtTitle.Text = objphoto.Title;
                txtShortDescription.Text = objphoto.ShortDescription;
                txtFullDescription.Text = objphoto.FullDescription;
                imgCurrentImage.ImageUrl = objphoto.PhotoPath;
                txtImageAlt.Text = objphoto.ImageAlt;                
                rblIsCover.SelectedValue = objphoto.IsCover.ToString();
                Session["EditPhotoID"] = ID;
                hdfIsEdit.Value = "1";
                hdfEditPhotoPath.Value = objphoto.PhotoPath;
                HideAll();
                ShowForm();
                divViewImage.Visible = true;
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }


    private void ShowData()
    {
        rptImageInfo.Visible = true;
    }

    private void DeleteRecord(int ID)
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            PhotoGalleryController con = new PhotoGalleryController();
            con.DeletePhotoByID(ID, UserModuleID, GetPortalID, GetUsername, true);
            ManageAlbum(Int32.Parse(hdfPhotoAlbumID.Value));
            ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "PhotoDeletedSuccessfully"), "", SageMessageType.Success);
            imbAddNew.Visible = true;
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void ManageAlbum(int ID)
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            PhotoGalleryController con = new PhotoGalleryController();
            PhotoAlbumInfo objphoto = con.GetPhotoAlbumInfoByID(ID, UserModuleID, GetPortalID);
            List<PhotoGalleryInfo> objInfo = con.GetPhotoGalleryListByAlbum(ID, UserModuleID, GetPortalID);

            if (objInfo.Count > 0)
            {
                rptImageInfo.Visible = true;
                rptImageInfo.DataSource = objInfo;
                rptImageInfo.DataBind();
            }
            else if (objInfo.Count == 0)
            {
                rptImageInfo.Visible = false;
                ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "NoPhotosFound"), "", SageMessageType.Alert);
            }
            HideAll();
            pnlShow.Visible = true;            
            hdfPhotoAlbumID.Value = ID.ToString();
            imbBackToAlbum.ImageUrl = GetTemplateImageUrl("imgview.png", true);
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void EditAlbum(int ID)
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            PhotoGalleryController con = new PhotoGalleryController();
            PhotoAlbumInfo objphoto = con.GetPhotoAlbumInfoByID(ID, UserModuleID, GetPortalID);
            if (objphoto != null)
            {
                txtAlbumName.Text = objphoto.AlbumName;
                txtAlbumDescription.Text = objphoto.AlbumDescription;
                Session["EditPhotoAlbumID"] = ID;
                HideAll();
                pnlAddAlbum.Visible = true;
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    private void DeleteAlbum(int ID)
    {
        try
        {
            int UserModuleID = 0;
            if (!string.IsNullOrEmpty(SageUserModuleID))
            {
                UserModuleID = Int32.Parse(SageUserModuleID);
            }
            PhotoGalleryController con = new PhotoGalleryController();
            con.DeletePhotoAlbumByID(ID, UserModuleID, GetPortalID, GetUsername, true);
            ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "AlbumDeletedSuccessfully"), "", SageMessageType.Success);
            LoadAllContent();
        }
        catch (SqlException ex)
        {
            ProcessException(ex);
        }
    }

    public string GetPhotoGalleryWithAlbumImageUrl(string imageName, bool isServerControl)
    {
        string path = string.Empty;
        if (isServerControl == true)
        {
            path = "~/Modules/PhotoGalleryWithAlbum/ImageFiles/" + imageName;
        }
        else
        {
            path = this.Page.ResolveUrl("~/Modules/PhotoGalleryWithAlbum/ImageFiles/" + imageName);
        }
        return path;
    }

    #endregion

    #region "Control Events"

    protected void rptImageInfo_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        try
        {
            int ID = Int32.Parse(e.CommandArgument.ToString());
            switch (e.CommandName)
            {
                case "Edit":
                    EditRecord(ID);
                    break;
                case "Delete":
                    DeleteRecord(ID);
                    break;
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    protected void imbAddNewAlbum_Click(object sender, ImageClickEventArgs e)
    {
        HideAll();
        ClearAll();
        pnlAddAlbum.Visible = true;
    }

    protected void rptAlbumShow_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        try
        {
            int ID = Int32.Parse(e.CommandArgument.ToString());
            switch (e.CommandName)
            {
                case "Edit":
                    EditAlbum(ID);
                    break;
                case "Delete":
                    DeleteAlbum(ID);
                    break;
                case "Manage":
                    ManageAlbum(ID);
                    break;
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    protected void imbCancelAddAlbum_Click(object sender, ImageClickEventArgs e)
    {
        HideAll();
        pnlAlbumShow.Visible = true;
    }

    protected void imbAddNew_Click(object sender, ImageClickEventArgs e)
    {
        ClearAll();
        rblIsCover.ClearSelection();
        rblIsCover.SelectedValue = true.ToString();
        HideAll();
        LoadAlbums();
        ddlPhotoAlbum.SelectedIndex = ddlPhotoAlbum.Items.IndexOf(ddlPhotoAlbum.Items.FindByValue(hdfPhotoAlbumID.Value.ToString()));
        pnlEdit.Visible = true;
    }

    protected void imbSave_Click(object sender, ImageClickEventArgs e)
    {      
        Save();
    }

    protected void imbCancel_Click(object sender, ImageClickEventArgs e)
    {
        HideAll();
        ClearAll();
        pnlShow.Visible = true;
    }

    protected void rptAlbumShow_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            ImageButton imbAlbumEdit = (ImageButton)e.Item.FindControl("imbEditAlbum");
            ImageButton imbAlbumDelete = (ImageButton)e.Item.FindControl("imbDeleteAlbum");
            ImageButton imbManageAlbum = (ImageButton)e.Item.FindControl("imbManageAlbum");
            imbAlbumDelete.ImageUrl = GetTemplateImageUrl("imgdelete.png", true);
            imbAlbumEdit.ImageUrl = GetTemplateImageUrl("imgedit.png", true);
            imbAlbumDelete.Attributes.Add("onclick", "javascript:return confirm('" + SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "AreYouSureToDelete") + "')");
            imbManageAlbum.ImageUrl = GetPhotoGalleryWithAlbumImageUrl("imgmanage.png", true);
        }
    }

    protected void rptImageInfo_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            ImageButton imbEdit = (ImageButton)e.Item.FindControl("imbEdit");
            ImageButton imbDelete = (ImageButton)e.Item.FindControl("imbDelete");
            imbEdit.ImageUrl = GetTemplateImageUrl("imgedit.png", true);
            imbDelete.ImageUrl = GetTemplateImageUrl("imgdelete.png", true);
            imbDelete.Attributes.Add("onclick", "javascript:return confirm('" + SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/PhotoGalleryWithAlbum/ModuleLocalText", "AreYouSureToDelete") + "')");
        }
    }

    protected void imbBackToAlbum_Click(object sender, ImageClickEventArgs e)
    {
        HideAll();
        pnlAlbumShow.Visible = true;
    }

    protected void imbSaveAddAlbum_Click(object sender, ImageClickEventArgs e)
    {
        SaveAlbum();
    }
    #endregion
}
