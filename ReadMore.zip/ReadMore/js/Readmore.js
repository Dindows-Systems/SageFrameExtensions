﻿(function($) {
    var dateformat = '';
    $.ReadmoreSetting = function(p) {
        p = $.extend
        ({

            PortalID: '',
            UserModuleID: '',
            urlpath: '',
            ReadmorelinkImage: '',
            ReadmorelinkText: '',
            HeaderText: '',
            HeaderLink: '',
            HeaderImage: '',
            Description: '',
            Image: '',
            Text: '',
            DescriptionLength: '',
            IconName: '',
            ReadmoreLinkVisible: '',
            AddedBy: '',
            ReadmoreType: '',
            Pagination: '',
            PaginationSize: '',
            ViewAll: '',
            DateFormat: ''

        }, p);

        $('#btnSavingSetting').click(function() {
            SaveSetting();
        });

        $('#btnDelete').live('click', function() {
            DeleteIcon(p.IconName);
        });

        $('#btnimgDelete').live('click', function() {
            var iconfile = $('div.cssClassUploadFiles img').attr('title');
            DeleteIcon(iconfile);
        });
        $('#btndeleteimage').live('click', function() {
            var iconfile = $('div.cssClassUploadFiles img').attr('title');
            DeleteIcon(iconfile);
        });
        ImageUploader();
        GetdateFormat();
        $('#dvHeaderLink').hide();
        $('#dvDesclength').hide();
        $('#dvtext').hide();
        $('#dvimageUpload').hide();
        $('#txtDescLength').numeric();
        $('#txtPagination').numeric();
        if (p.ReadmoreType == "Page") {
            $('#rdbtnPage').attr('checked', true);
        }
        else {
            $('#rdbtnContent').attr('checked', true);
        }
        if (p.ReadmoreLinkVisible == "True") {
            $('#rdbtnYes').attr('checked', true);
        }
        else {
            $('#rdbtnNo').attr('checked', true);
        }

        if (p.HeaderText == "True") {
            $('#chkHeaderText').attr('checked', true);
            $('#dvHeaderLink').show();
            if (p.HeaderLink == "True") {
                $('#chkIsHeaderlink').attr('checked', true);
            }
        }

        if (p.HeaderImage == "True") {
            $('#chkImage').attr('checked', true);
        }
        if (p.Description == "True") {
            $('#chkDescription').attr('checked', true);
            $('#dvDesclength').show();
            $('#txtDescLength').val(p.DescriptionLength);
        }
        if (p.Pagination == "True") {
            $('#chkPagination').attr('checked', true);
            $('#divNoOfPage').show();
            $('#txtPagination').val(p.PaginationSize);
        }
        else
        { $('#divNoOfPage').hide(); }

        if (p.ReadmorelinkImage) {
            if (p.Image == "") {
                $('div.cssClassUploadFiles').hide();
            }
            else {
                $('div.cssClassUploadFiles').show();
                $('div.cssClassUploadFiles').append('<img class="readmoreimage" title="' + p.Image + '" alt="" src=" ' + p.urlpath + 'Image/ReadmoreLinkImage/' + p.Image + '"/><img id="btnimgDelete" src="' + p.urlpath + 'Image/btndelete.png" style="cursor:pointer"/>');
            }
            $('#radImage').attr('checked', true);
            $('#dvimageUpload').show();
            $('#dvtext').hide();

        }
        if (p.ReadmorelinkText == "True") {
            $('#radText').attr('checked', true);
            $('#dvimageUpload').hide();
            $('#dvtext').show();
            $('div.cssClassUploadFiles').hide();
            $('#txtLink').val(p.Text);
        }
        if (p.ViewAll == "True") {
            $('#chkViewAll').attr('checked', true);
        }

        $('#chkHeaderText').bind('click', function() {
            if ($(this).is(':checked')) {
                $('#dvHeaderLink').show();

            } else {

                $('#dvHeaderLink').hide();
                $('#chkIsHeaderlink').attr('checked', false);
            }
        });



        $('#chkDescription').bind('click', function() {
            if ($(this).is(':checked')) {
                $('#dvDesclength').show();
                $('#txtDescLength').val(p.DescriptionLength);

            } else {
                $('#dvDesclength').hide();
            }
        });

        $('#chkPagination').bind('click', function() {
            if ($(this).is(':checked')) {
                $('#divNoOfPage').show();
                $('#txtPagination').val(p.PaginationZize);

            } else {
                $('#divNoOfPage').hide();
            }
        });

        $('#radImage').bind("click", function() {
            $('div.cssClassUploadFiles').html('');
            if (p.Image == "") {
                $('div.cssClassUploadFiles').hide();
            }
            else {
                $('div.cssClassUploadFiles').show();
                $('div.cssClassUploadFiles').append('<img class="readmoreimage" title="' + p.Image + '" alt="" src=" ' + p.urlpath + 'Image/ReadmoreLinkImage/' + p.Image + '"/><img id="btndeleteimage" src="' + p.urlpath + 'Image/btndelete.png" style="cursor:pointer"/>');
            }

            $('#dvimageUpload').show();
            $('#dvtext').hide();



        });
        $('#radText').bind("click", function() {
            $('div.cssClassUploadFiles').hide();
            $('#dvtext').show();
            $('#dvimageUpload').hide();
            $('#txtLink').val(p.Text);
        });

        function DeleteIcon(iconfile) {
            $.ajax({

                type: "POST",
                url: p.urlpath + "WebService.asmx/DeleteLinkIcon",
                data: JSON.stringify({ LinkIcon: iconfile, basePath: p.urlpath }),

                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function(msg) {
                    $('div.cssClassUploadFiles').html('');
                    SageFrame.messaging.show("Icon successfully deleted", "Success");

                },

                error: function() {
                    SageFrame.messaging.show("Fail to delete icon", "Error");
                }
            });

        }
        dateformat = p.DateFormat;

        function GetdateFormat() {

            $.ajax({

                type: "POST",
                url: p.urlpath + "WebService.asmx/GetDateFormat",
                data: '{}',
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function(msg) {
                    var data = msg.d;
                    var html = '';
                    $.each(data, function(index, item) {
                        if (item.Key == dateformat) {
                            html += '<option value=" ' + item.Key + '" selected="selected" >' + item.Value + '</option>';
                        } else {
                            html += '<option value=" ' + item.Key + '" >' + item.Value + '</option>';
                        }
                    });
                    $('#ddlDateFormat').append(html);
                },

                error: function() {

                    SageFrame.messaging.show("Fail to load dateformat", "Error");
                }
            });

        }

        function ImageUploader() {

            var html = '';
            var uploadFlag = false;
            var upload = new AjaxUpload($('#IconUpload'), {
                action: ReadmoreUploadPath + 'UploadHandler.ashx',
                name: 'myfile[]',
                multiple: false,
                data: {},
                autoSubmit: true,
                responseType: 'json',
                onChange: function(file, ext) {
                },
                onSubmit: function(file, ext) {
                    if (ext == "jpg" || ext == "gif" || ext == "bmp" || ext == "png" || ext == "jpeg") {
                        return true;
                    }
                    else {
                        alert('Alert Message<p>Not a valid image file!</p>');
                        return false;
                    }
                },
                onComplete: function(file, response) {
                    $('div.cssClassUploadFiles').html('');
                    $('div.cssClassUploadFiles').show();
                    var str = response;
                    var imagefile = file.split(" ").join("_");
                    var filePath = str.replace("filePath=", "");
                    p.IconName = imagefile;
                    $('div.cssClassUploadFiles').append('<span><img class="readmoreimage" alt="" src=" ' + p.urlpath + 'Image/ReadmoreLinkImage/' + imagefile + '"/></span><span class="delete"><img id="btnDelete" src="' + p.urlpath + 'Image/btndelete.png" style="cursor:pointer"/></span>');
                }
            });
        }

        function SaveSetting() {
            var Arr = new Array();
            var ReadmorePage = $('#rdbtnPage').is(':checked');
            var ReadmoreContent = $('#rdbtnContent').is(':checked');
            var ReadmoreLinkvisible = $('#rdbtnYes').is(':checked');
            var ReadmoreLinknotVisible = $('#rdbtnNo').is(':checked');
            var HeaderText = $('#chkHeaderText').is(':checked');
            var HeaderLink = $('#chkIsHeaderlink').is(':checked');
            var HeaderImage = $('#chkImage').is(':checked');
            var Description = $('#chkDescription').is(':checked');
            var DescLength = $('#txtDescLength').val();
            var LinkImage = $('#radImage').is(':checked');
            var LinkText = $('#radText').is(':checked');
            var rmlinktext =  $.trim($('#txtLink').val());
            var DateFormat = $('#ddlDateFormat option:selected').attr("value");
            var Pagination = $('#chkPagination').is(':checked');
            var NoOfPageToDisplay = $('#txtPagination').val();
            var ViewAll = $('#chkViewAll').is(':checked');
            var SettingKey;
            var SettingValue = "";
            if ((HeaderText == false) && (HeaderImage == false) && (Description == false)) {

                SageFrame.messaging.show("No content will be displayed please select as your choice Header or Image or Description ", "Alert");
                return false;
            }
            if ((HeaderText == true) && (HeaderLink == false) && (HeaderImage == false) && (Description == false)) {

                SageFrame.messaging.show("Please check any one field with header text", "Alert");
                return false;
            }
            else {
                SettingKey = "ViewAll" + "/" + "Pagination" + "/" + "PaginationSize" + "/" + "DateFormat" + "/" + "ReadmoreType" + "/" + "ReadmoreLinkVisible" + "/" + "HeaderText" + "/" + "IsHeaderLink" + "/" + "HeaderImage" + "/" + "Description" + "/" + "DescriptionLength" + "/" + "ReadmoreLinkImage" + "/" + "ReadmoreLinkText" + "/" + "Image" + "/" + "Text";
                Arr.push(ViewAll);
                Arr.push(Pagination);
                if (Pagination) {
                    if (NoOfPageToDisplay == '') {
                        SageFrame.messaging.show("Enter number of items to be shown.", "Alert");
                        return false;
                        //Arr.push(p.PaginationSize);
                    }
                    if (NoOfPageToDisplay != '' && NoOfPageToDisplay <= 0) {
                        SageFrame.messaging.show("Please set valid page number to display.", "Alert");
                        return false;
                    }
                }
                Arr.push(NoOfPageToDisplay);
                Arr.push(DateFormat);
                if (ReadmorePage == true && ReadmoreContent == false)
                { Arr.push("Page"); }
                else { Arr.push("Content"); }
                if ((ReadmoreLinkvisible == true) && (ReadmoreLinknotVisible == false)) {
                    Arr.push(true);
                }
                else {
                    Arr.push(false);
                }
                Arr.push(HeaderText);
                Arr.push(HeaderLink);
                Arr.push(HeaderImage);
                Arr.push(Description);

                if (Description) {
                    if (DescLength == '') {
                        SageFrame.messaging.show("Please enter description length.", "Alert");
                        return false;
                        //Arr.push(p.DescriptionLength);
                    }
                    else {
                        Arr.push(DescLength);
                    }
                }
				 if (!Description) {
                   
                    Arr.push(p.DescriptionLength);
                }

                if ((LinkImage == true) && (LinkText == false)) {
                    Arr.push(true);
                    Arr.push(false);
                    if (p.IconName == '') {
                        //SageFrame.messaging.show("Please check any one field with header text", "Alert");
                        Arr.push(p.Image);
                    }
                    else {
                        Arr.push(p.IconName);
                    }
                    Arr.push(p.Text);
                }
                else {
                    Arr.push(false);
                    Arr.push(true);
                    Arr.push(p.Image);
                    if (rmlinktext == '') {
                        SageFrame.messaging.show("Please enter button text.", "Alert");
                        //Arr.push(p.Text);
                        return false;
                    }
                    else {
                        Arr.push(rmlinktext);
                    }
                }

            }
            SettingValue = Arr.join('/');
            $('div.cssClassUploadFiles').html('');
            $.ajax({

                type: "POST",
                url: p.urlpath + "WebService.asmx/SaveSetting",
                data: JSON.stringify({ Key: SettingKey, value: SettingValue, UserModuleID: p.UserModuleID, PortalID: p.PortalID, AddedBy: p.AddedBy }),

                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function(msg) {
                    SageFrame.messaging.show("Settings Successfully Saved", "Success");
                    // $('#txtDescLength').val('');
                    // $('#txtLink').val('');
                },

                error: function() {
                    SageFrame.messaging.show("Fail to save setting!", "Error");
                }
            });
        }
    };
    $.fn.Readmore = function(p) {
        $.ReadmoreSetting(p);
    };
})(jQuery);

