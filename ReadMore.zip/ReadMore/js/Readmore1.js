﻿(function($) {

    $.ReadMorePageSize = function(p) {
        p = $.extend
        ({
            Pagination: '',
            PageCount: '',
            ContentCount: '',
            urlpath: '',
            NoOfPage: 3,
            DivID1: '',
            DivID2: ''
        }, p);

        var ReadMorePageVar = {
            init: function() {
                $listItem = $('ul.resize li');
                maxValue = ReadMorePageVar.findMaxValue($listItem);
                $listItem.each(function() {
                    $(this).css("height", maxValue);

                });               
                if (p.Pagination) {
                    if (p.PageCount > p.NoOfPage) {
                        $(p.DivID1).pajinate({
                            items_per_page: p.NoOfPage
                        });
                    }
                    if (p.ContentCount > p.NoOfPage) {
                        $(p.DivID2).pajinate({
                            items_per_page: p.NoOfPage
                        });
                    }

                }


            },
            findMaxValue: function(element) {
                var maxValue = undefined;
                $(element).each(function() {
                    var val = parseInt($(this).height());
                    if (maxValue === undefined || maxValue < val) {
                        maxValue = val;
                    }
                });
                return maxValue;
            }

        };
        ReadMorePageVar.init();



    };

    $.fn.ReadmorePager = function(p) {
        $.ReadMorePageSize(p);
    };

})(jQuery);

