﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.ReadMoreLink.Controller;
using SageFrame.ReadMoreLink.Entity;
using System.Web.UI.HtmlControls;
using System.Data;
using System.Text;
using System.IO;
using SageFrame.Common.CommonFunction;

public partial class Modules_Read_More_ReadMoreView : BaseAdministrationUserControl
{
    public int DescLength;
    public string urlpath;
    public string Image;
    public string Text;
    public string ReadmoreType;
    public string PaginationSize;  
    public bool AllowPagination;
    public int PageCount;
    public int ContentCount;
    public string ViewType;
    protected void Page_Load(object sender, EventArgs e)
    {
        urlpath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
        if (!IsPostBack)
        {
            LoadSetting();
            LoadReadmoreContent();
            LoadReadmorePageLink();
        }
        loadScript();
        divCancel.Visible = false;
        divBackToHome.Visible = false;
        divBackToAllList.Visible = false;
       
    }

    public void LoadSetting()
    {
        ReadMoreController ctl = new ReadMoreController();
        ReadMoreSettingEntity setObj = ctl.GetSettingValues(int.Parse(SageUserModuleID), GetPortalID);
        ViewType = setObj.ReadmoreType;
    }

    private void loadScript()
    {
       IncludeCss("ReadMore", "/Modules/ReadMore/css/module.css");    
		IncludeJs("ReadMore", "/Modules/ReadMore/js/paginate.js", "/Modules/ReadMore/js/Readmore1.js"); 	   
    }

    public void LoadReadmorePageLink()
    {
        ReadMoreController ctl = new ReadMoreController();
        List<ReadMoreEditInfo> lstReadMore = ctl.LoadDataOnRepeater(GetPortalID, int.Parse(SageUserModuleID));
        foreach (ReadMoreEditInfo obj in lstReadMore)
        {
            obj.URLPath = string.Format("{0}{1}", Request.ApplicationPath == "/" ? "" : Request.ApplicationPath, obj.URLPath + ".aspx");
            if (obj.ImageWrapper != " ")
            {
                obj.ImageWrapper = obj.ImageWrapper;
            }
        }
        repReadMoreLink.DataSource = lstReadMore;
        repReadMoreLink.DataBind();
        PageCount = lstReadMore.Count;
        if (PageCount == 0 && ViewType == "Page")
        {
            divViewAllPage.Visible = false;
            divReadmorePage.Visible = false;
            divReadmoreContent.Visible = false;           
        }
    }   

    protected void repReadMoreLink_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        ReadMoreController ctl = new ReadMoreController();
        ReadMoreSettingEntity setObj = ctl.GetSettingValues(int.Parse(SageUserModuleID), GetPortalID);
        if (setObj != null)
        {
            DescLength = Convert.ToInt32(setObj.DescriptionLength);
            Image = setObj.Image;
            Text = setObj.Text;
            ReadmoreType = setObj.ReadmoreType;
            PaginationSize = setObj.PaginationSize;
            AllowPagination = setObj.Pagination;
            
        }
        if (setObj.Pagination)
        {
            //IncludeJs("ReadMore", "/Modules/ReadMore/js/paginate.js");
        }
        if (setObj.ReadmoreType == "Page")
        {
            if (setObj.ViewAll)
            {               
                divViewAllPage.Visible = true;
            }
            else
            {               
                divViewAllPage.Visible = false;
            }
            divReadmorePage.Visible = true;
            divReadmoreContent.Visible = false;
        }
        HyperLink hpLink = e.Item.FindControl("hpLink") as HyperLink;
        HiddenField hdImage = e.Item.FindControl("hdnImage") as HiddenField;
        Literal ltrImage = e.Item.FindControl("ltrImage") as Literal;
        HtmlGenericControl hdrText = e.Item.FindControl("HeaderText") as HtmlGenericControl;
        HtmlGenericControl hdrlink = e.Item.FindControl("HeaderLink") as HtmlGenericControl;
        HtmlGenericControl description = e.Item.FindControl("description") as HtmlGenericControl;
        HyperLink hpImageLink = e.Item.FindControl("hpHeaderImage") as HyperLink;
        HtmlGenericControl dvreadmoreItem = e.Item.FindControl("dvReadmoreItem") as HtmlGenericControl;
        string newdesc = HTMLHelper.StripTagsRegex(description.InnerText);

        if ((newdesc.Length) > DescLength)
        {
            description.InnerText = newdesc.Substring(0, DescLength).ToString() + "...";
        }

        if (hdImage.Value == null && !setObj.HeaderText && !setObj.Description)
        {
            dvreadmoreItem.Visible = false;
        }

        if (!setObj.HeaderText)
        {
            hdrText.Visible = false;
            hdrlink.Visible = false;
        }

        if (setObj.IsHeaderImageLink)
        {
            hdrlink.Visible = false;
        }

        if (setObj.HeaderText == true && !setObj.IsHeaderLink)
        {
            hdrlink.Visible = false;
            hdrText.Visible = true;
        }

        if (setObj.HeaderText && setObj.Description && !setObj.HeaderImage)
        {
            description.Visible = true;
            hdrText.Visible = true;
            hdImage.Visible = false;
        }

        if (setObj.HeaderText && setObj.IsHeaderLink && !setObj.HeaderImage && !setObj.Description)
        {
            hdrlink.Visible = true;
            description.Visible = false;
            hdrText.Visible = false;
            hpLink.Visible = false;
        }

        if (setObj.HeaderText && setObj.IsHeaderLink)
        {
            hdrlink.Visible = true;
            hdrText.Visible = false;
        }

        if (!setObj.HeaderImage)
        {
            hpImageLink.Visible = false;
        }

        if (!setObj.Description)
        {
            description.Visible = false;
        }

        if (hdImage.Value != "" && setObj.HeaderImage && !setObj.HeaderText && !setObj.Description)
        {
            description.Visible = false;
            hdrText.Visible = false;
            hpLink.Visible = false;
            hdrlink.Visible = false;
            hpImageLink.Visible = true;
        }

        if (setObj.ReadmoreLinkText)
        {
            hpLink.Text = Text;
            hpLink.CssClass = "sfBtn";
        }

        if (setObj.ReadmoreLinkImage)
        {
            string iconurl = Server.MapPath(urlpath + "Image/ReadmoreLinkImage/" + Image);
            if (File.Exists(iconurl))
            {
                hpLink.ImageUrl = urlpath + "Image/ReadmoreLinkImage/" + Image;
            }
            //else
            //{
            //    hpLink.ImageUrl = Server.MapPath(urlpath + "Image/ReadmoreLinkImage/readmore_icon.jgp");
            //}
            hpLink.ToolTip = "Click to read more";
        }

        if (!setObj.ReadmoreLinkVisible)
        {
            hpLink.Visible = false;
        }
        
        if (setObj.ReadmoreLinkVisible && !setObj.HeaderText && !setObj.HeaderImage && !setObj.Description)
        {
            dvreadmoreItem.Visible = false;
        }
    }

    protected void repReadMoreLink_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }
 
    protected void RptrReadmoreContent_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        try
        {
            divCancel.Visible = true;
            int contentID = Int32.Parse(e.CommandArgument.ToString());
            Session["ContentID"] = contentID;
            switch (e.CommandName.ToString())
            {
                case "btnLoadContent":
                    ReadmoreloadContent(contentID);
                    break;
                case "imgLoadContent":
                    ReadmoreloadContent(contentID);
                    break;
                case "lnkHeader":
                    ReadmoreloadContent(contentID);
                    break;
                case "contentHeaderImg":
                    ReadmoreloadContent(contentID);
                    break;
            }
            ShowHideDetails();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void ShowHideDetails()
    {
        divBackToAllList.Visible = false;
        divCancel.Visible = true;
        divViewAllPage.Visible = false;
    }

    private void ReadmoreloadContent(int contentID)
    {
        LoadControl(phdDetailContent, "~/Modules/ReadMore/ReadmoreContent.ascx");
        divReadmoreContent.Visible = false;
        divReadmorePage.Visible = false;       
    }

    protected void RptrReadmoreContent_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        try
        {
            ReadMoreController ctl = new ReadMoreController();
            ReadMoreSettingEntity setObj = ctl.GetSettingValues(int.Parse(SageUserModuleID), GetPortalID);
            if (setObj != null)
            {
                DescLength = Convert.ToInt32(setObj.DescriptionLength);
                Image = setObj.Image;
                Text = setObj.Text;
                ReadmoreType = setObj.ReadmoreType;
                PaginationSize = setObj.PaginationSize;
                AllowPagination = setObj.Pagination;
            }
            if (ReadmoreType == "Content")
            {
                if (setObj.ViewAll)
                {
                    divViewAllPage.Visible = true;                 
                }
                else
                {
                    divViewAllPage.Visible = false;                  
                }
                divReadmoreContent.Visible = true;
                divReadmorePage.Visible = false;
            }
            string len = "To get access to the Sageframe web content management, you should be a registered user. If you are new to sageframe, Focused For DevelopersFocused For DevelopersFocused For Developerscreate a user account by filling up the basic user information form. After this you will get an email from sageframe team confirming your registration, now User can anytime login";
            int dd = len.Length;
            Button btn = e.Item.FindControl("btnReadmore") as Button;
            ImageButton readmoreImage = e.Item.FindControl("imgReadmore") as ImageButton;
            HtmlGenericControl contentDescription = e.Item.FindControl("contentDescription") as HtmlGenericControl;
            HtmlGenericControl ContentHeader = e.Item.FindControl("ContentHeaderText") as HtmlGenericControl;
            LinkButton lnkContentHeader = e.Item.FindControl("lnkCintentHeader") as LinkButton;
            HtmlGenericControl dvReadmoreContent = e.Item.FindControl("divReadmoreContent") as HtmlGenericControl;
            HiddenField hdnContentImage = e.Item.FindControl("hdnContentImage") as HiddenField;
            ImageButton hpContentImage = e.Item.FindControl("imgContentHeader") as ImageButton;
            HtmlContainerControl spnReadmoreContent = e.Item.FindControl("spnReadmoreContent") as HtmlGenericControl;
            string newdesc = HTMLHelper.StripTagsRegex(contentDescription.InnerText).ToString();
            if ((newdesc.Length) > DescLength)
            {
                contentDescription.InnerText = newdesc.Substring(0, DescLength) + "...";
            }

            if (hdnContentImage.Value == null && !setObj.HeaderText && !setObj.Description)
            {
                dvReadmoreContent.Visible = false;
            }

            if (!setObj.HeaderText)
            {
                ContentHeader.Visible = false;
                lnkContentHeader.Visible = false;
            }

            if (setObj.IsHeaderLink)
            {
                lnkContentHeader.Visible = false;
            }

            if (setObj.HeaderText && !setObj.IsHeaderLink)
            {
                lnkContentHeader.Visible = false;
                ContentHeader.Visible = true;
            }

            if (setObj.HeaderText && setObj.Description && !setObj.HeaderImage)
            {
                contentDescription.Visible = true;
                ContentHeader.Visible = true;
                hdnContentImage.Visible = false;
            }

            if (setObj.HeaderText && setObj.IsHeaderLink && !setObj.HeaderImage && !setObj.Description)
            {
                lnkContentHeader.Visible = true;
                contentDescription.Visible = false;
                ContentHeader.Visible = false;
                spnReadmoreContent.Visible = false;
            }

            if (setObj.HeaderText && setObj.IsHeaderLink)
            {
                lnkContentHeader.Visible = true;
                ContentHeader.Visible = false;
            }

            if (!setObj.HeaderImage)
            {
                hpContentImage.Visible = false;
            }

            if (!setObj.Description)
            {
                contentDescription.Visible = false;
            }

            if (hdnContentImage.Value != "" && setObj.HeaderImage && !setObj.HeaderText && !setObj.Description)
            {
                contentDescription.Visible = false;
                ContentHeader.Visible = false;
                spnReadmoreContent.Visible = false;
                lnkContentHeader.Visible = false;
                hpContentImage.Visible = true;
            }

            if (setObj.ReadmoreLinkText)
            {
                readmoreImage.Visible = false;
                btn.Text = Text;
                btn.CssClass = "sfBtn";
            }

            if (setObj.ReadmoreLinkImage)
            {
                string iconPath = Server.MapPath(urlpath + "Image/ReadmoreLinkImage/" + Image);
                if (File.Exists(iconPath))
                {
                    readmoreImage.ImageUrl = urlpath + "Image/ReadmoreLinkImage/" + Image;
                }
                else
                {
                    readmoreImage.Visible = false;
                }

               // readmoreImage.ImageUrl = urlpath + "Image/ReadmoreLinkImage/" + Image;
                btn.Visible = false;
            }

            if (!setObj.ReadmoreLinkVisible)
            {
                spnReadmoreContent.Visible = false;
            }

            if (setObj.ReadmoreLinkVisible && !setObj.HeaderText && !setObj.HeaderImage && !setObj.Description)
            {
                dvReadmoreContent.Visible = false;
            }

            if (setObj.HeaderImage && setObj.ReadmoreLinkVisible && setObj.Description)
            {
                spnReadmoreContent.Visible = true;
            }
        }

        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void LoadControl(PlaceHolder ContainerControl, string controlSource)
    {
        SageUserControl ctl = this.Page.LoadControl(controlSource) as SageUserControl;
        ctl.SageUserModuleID = SageUserModuleID;
        ctl.EnableViewState = true;
        ContainerControl.Controls.Add(ctl);
    }

    public void LoadReadmoreContent()
    {
        ReadMoreController ctl = new ReadMoreController();
        List<ReadmoreContent> lstReadMoreContent = ctl.LoadReadmoreContent(GetPortalID, int.Parse(SageUserModuleID));
        RptrReadmoreContent.DataSource = lstReadMoreContent;
        RptrReadmoreContent.DataBind();
        ContentCount = lstReadMoreContent.Count;
        if (ContentCount == 0 && ViewType == "Content")
        {
            divViewAllPage.Visible = false;           
            divReadmoreContent.Visible = false;
            divReadmorePage.Visible = false;
        }  
    }

   
    protected void lnkbtnViewAll_Click(object sender, EventArgs e)
    {
        LoadAllContent();
        divReadmoreContent.Visible = false;
        divReadmorePage.Visible = false;      
        divBackToHome.Visible = true;
    }

    private void LoadAllContent()
    {
        ReadMoreController ctl = new ReadMoreController();
        List<ReadmoreContent> lstReadMore = ctl.LoadReadmoreAllContent(GetPortalID, int.Parse(SageUserModuleID));
        RptrLoadAllContent.DataSource = lstReadMore;
        RptrLoadAllContent.DataBind();
    }

    protected void RptrLoadAllContent_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        try
        {
            divCancel.Visible = true;
            int contentID = Int32.Parse(e.CommandArgument.ToString());
            Session["ContentID"] = contentID;
            switch (e.CommandName.ToString())
            {
                case "btnLoadContent":
                    ReadmoreloadContent(contentID);
                    break;
                case "imgLoadContent":
                    ReadmoreloadContent(contentID);
                    break;
                case "lnkHeader":
                    ReadmoreloadContent(contentID);
                    break;
                case "contentHeaderImg":
                    ReadmoreloadContent(contentID);
                    break;
            }
            showDetails();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void showDetails()
    {
        divAllContent.Visible = false;
        divAllPage.Visible = false;
        divCancel.Visible = false;
        divBackToAllList.Visible = true;
        divViewAllPage.Visible = false;
    }

    protected void RptrLoadAllContent_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        try
        {
            ReadMoreController ctl = new ReadMoreController();
            ReadMoreSettingEntity setObj = ctl.GetSettingValues(int.Parse(SageUserModuleID), GetPortalID);

            if (setObj != null)
            {
                DescLength = Convert.ToInt32(setObj.DescriptionLength);
                Image = setObj.Image;
                Text = setObj.Text;
                ReadmoreType = setObj.ReadmoreType;
                PaginationSize = setObj.PaginationSize;
            }
            if (ReadmoreType == "Content")
            {
                divReadmoreContent.Visible = true;
                divReadmorePage.Visible = false;
            }
            Button btn = e.Item.FindControl("btnReadmore") as Button;
            ImageButton readmoreImage = e.Item.FindControl("imgReadmore") as ImageButton;
            HtmlGenericControl contentDescription = e.Item.FindControl("contentDescription") as HtmlGenericControl;
            HtmlGenericControl ContentHeader = e.Item.FindControl("ContentHeaderText") as HtmlGenericControl;
            LinkButton lnkContentHeader = e.Item.FindControl("lnkCintentHeader") as LinkButton;
            HtmlGenericControl dvReadmoreContent = e.Item.FindControl("divReadmoreContent") as HtmlGenericControl;
            HiddenField hdnContentImage = e.Item.FindControl("hdnContentImage") as HiddenField;
            ImageButton hpContentImage = e.Item.FindControl("imgContentHeader") as ImageButton;
            HtmlContainerControl spnReadmoreContent = e.Item.FindControl("spnReadmoreContent") as HtmlGenericControl;
            string newdesc =contentDescription.InnerHtml;
            if ((newdesc.Length) > DescLength)
            {
                contentDescription.InnerText = newdesc.Substring(0, DescLength).ToString() + "...";
            }

            if (hdnContentImage.Value == null && !setObj.HeaderText && !setObj.Description)
            {
                dvReadmoreContent.Visible = false;
            }

            if (!setObj.HeaderText)
            {
                ContentHeader.Visible = false;
                lnkContentHeader.Visible = false;
            }

            if (setObj.IsHeaderLink)
            {
                lnkContentHeader.Visible = false;
            }

            if (setObj.HeaderText && !setObj.IsHeaderLink)
            {
                lnkContentHeader.Visible = false;
                ContentHeader.Visible = true;
            }

            if (setObj.HeaderText && setObj.Description && !setObj.HeaderImage)
            {
                contentDescription.Visible = true;
                ContentHeader.Visible = true;
                hdnContentImage.Visible = false;
            }

            if (setObj.HeaderText && setObj.IsHeaderLink && !setObj.HeaderImage && !setObj.Description)
            {
                lnkContentHeader.Visible = true;
                contentDescription.Visible = false;
                ContentHeader.Visible = false;
                spnReadmoreContent.Visible = false;
            }

            if (setObj.HeaderText && setObj.IsHeaderLink)
            {
                lnkContentHeader.Visible = true;
                ContentHeader.Visible = false;
            }

            if (!setObj.HeaderImage)
            {
                hpContentImage.Visible = false;
            }

            if (!setObj.Description)
            {
                contentDescription.Visible = false;
            }

            if (hdnContentImage.Value != "" && setObj.HeaderImage && !setObj.HeaderText && !setObj.Description)
            {
                contentDescription.Visible = false;
                ContentHeader.Visible = false;
                spnReadmoreContent.Visible = false;
                lnkContentHeader.Visible = false;
                hpContentImage.Visible = true;
            }

            if (setObj.ReadmoreLinkText)
            {
                readmoreImage.Visible = false;
                btn.Text = Text;
                btn.CssClass = "sfBtn";
            }

            if (setObj.ReadmoreLinkImage)
            {
                readmoreImage.ImageUrl = urlpath + "Image/ReadmoreLinkImage/" + Image;
                btn.Visible = false;
            }

            if (!setObj.ReadmoreLinkVisible)
            {
                spnReadmoreContent.Visible = false;
            }

            if (setObj.ReadmoreLinkVisible && !setObj.HeaderText && !setObj.HeaderImage && !setObj.Description)
            {
                dvReadmoreContent.Visible = false;
            }

            if (setObj.HeaderImage && setObj.ReadmoreLinkVisible && setObj.Description)
            {
                spnReadmoreContent.Visible = true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    } 

  
    protected void lnkbtnViewAllPage_Click(object sender, EventArgs e)
    {
        LoadAllPage();
        LoadAllContent();
        divReadmoreContent.Visible = false;
        divReadmorePage.Visible = false;        
        divBackToHome.Visible = true;
        divViewAllPage.Visible = false;
    }

    private void LoadAllPage()
    {
        ReadMoreController ctl = new ReadMoreController();
        List<ReadMoreEditInfo> lstReadMore = ctl.LoadDataOnRepeater(GetPortalID, int.Parse(SageUserModuleID));
        foreach (ReadMoreEditInfo obj in lstReadMore)
        {
            obj.URLPath = string.Format("{0}{1}", Request.ApplicationPath == "/" ? "" : Request.ApplicationPath, obj.URLPath + ".aspx");
            if (obj.ImageWrapper != " ")
            {
                obj.ImageWrapper = obj.ImageWrapper;
            }
        }
        RptrLoadAllPage.DataSource = lstReadMore;
        RptrLoadAllPage.DataBind();   
    }

    protected void RptrLoadAllPage_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        ReadMoreController ctl = new ReadMoreController();
        ReadMoreSettingEntity setObj = ctl.GetSettingValues(int.Parse(SageUserModuleID), GetPortalID);
        if (setObj != null)
        {
            DescLength = Convert.ToInt32(setObj.DescriptionLength);
            Image = setObj.Image;
            Text = setObj.Text;
            ReadmoreType = setObj.ReadmoreType;
            PaginationSize = setObj.PaginationSize;
        }      

        if (setObj.ReadmoreType == "Page")
        {
            divReadmorePage.Visible = true;
            divReadmoreContent.Visible = false;
        }

        HyperLink hpLink = e.Item.FindControl("hpLink") as HyperLink;
        HiddenField hdImage = e.Item.FindControl("hdnImage") as HiddenField;
        Literal ltrImage = e.Item.FindControl("ltrImage") as Literal;
        HtmlGenericControl hdrText = e.Item.FindControl("HeaderText") as HtmlGenericControl;
        HtmlGenericControl hdrlink = e.Item.FindControl("HeaderLink") as HtmlGenericControl;
        HtmlGenericControl description = e.Item.FindControl("description") as HtmlGenericControl;
        HyperLink hpImageLink = e.Item.FindControl("hpHeaderImage") as HyperLink;
        HtmlGenericControl dvreadmoreItem = e.Item.FindControl("dvReadmoreItem") as HtmlGenericControl;
        string newdesc = HTMLHelper.StripTagsRegex(description.InnerText);
        if ((newdesc.Length) > DescLength)
        {
            description.InnerText = newdesc.Substring(0, DescLength).ToString() + "...";
        }

        if (hdImage.Value == null && !setObj.HeaderText && !setObj.Description)
        {
            dvreadmoreItem.Visible = false;
        }

        if (!setObj.HeaderText)
        {
            hdrText.Visible = false;
            hdrlink.Visible = false;
        }

        if (setObj.IsHeaderImageLink)
        {
            hdrlink.Visible = false;
        }

        if (setObj.HeaderText == true && !setObj.IsHeaderLink)
        {
            hdrlink.Visible = false;
            hdrText.Visible = true;
        }

        if (setObj.HeaderText && setObj.Description && !setObj.HeaderImage)
        {
            description.Visible = true;
            hdrText.Visible = true;
            hdImage.Visible = false;
        }

        if (setObj.HeaderText && setObj.IsHeaderLink && !setObj.HeaderImage && !setObj.Description)
        {
            hdrlink.Visible = true;
            description.Visible = false;
            hdrText.Visible = false;
            hpLink.Visible = false;
        }

        if (setObj.HeaderText && setObj.IsHeaderLink)
        {
            hdrlink.Visible = true;
            hdrText.Visible = false;
        }

        if (!setObj.HeaderImage)
        {
            hpImageLink.Visible = false;
        }

        if (!setObj.Description)
        {
            description.Visible = false;
        }

        if (hdImage.Value != "" && setObj.HeaderImage && !setObj.HeaderText && !setObj.Description)
        {
            description.Visible = false;
            hdrText.Visible = false;
            hpLink.Visible = false;
            hdrlink.Visible = false;
            hpImageLink.Visible = true;
        }

        if (setObj.ReadmoreLinkText)
        {
            hpLink.Text = Text;
            hpLink.CssClass = "sfBtn";
        }

        if (setObj.ReadmoreLinkImage)
        {
            hpLink.ImageUrl = urlpath + "Image/ReadmoreLinkImage/" + Image;
        }

        if (!setObj.ReadmoreLinkVisible)
        {
            hpLink.Visible = false;
        }

        if (setObj.ReadmoreLinkVisible && !setObj.HeaderText && !setObj.HeaderImage && !setObj.Description)
        {
            dvreadmoreItem.Visible = false;
        }
    }

    protected void RptrLoadAllPage_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }
	
	 protected void btnBacktoalllist_Click(object sender, EventArgs e)
    {
        LoadAllContent();
        divAllContent.Visible = true;
        divReadmoreContent.Visible = false;
        divBackToHome.Visible = true;
        divAllPage.Visible = true;
    }
    protected void btnBacktohome_Click(object sender, EventArgs e)
    {
        Page.Response.Redirect(Page.Request.Url.ToString(), true);
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        if (ReadmoreType == "Page")
        {
            divReadmoreContent.Visible = false;
            divReadmorePage.Visible = true;
        }
        else
        {
            Page.Response.Redirect(Page.Request.Url.ToString(), true);
            divReadmoreContent.Visible = true;
            divReadmorePage.Visible = false;
        }
        divCancel.Visible = false;
    }
	
}
