﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.ReadMoreLink.Controller;
using SageFrame.ReadMoreLink.Entity;
using System.IO;
using SageFrame.ReadMoreLink;
using SageFrame.Common.CommonFunction;
using CKEditor.NET;

public partial class Modules_Read_More_ReadMoreEdit : BaseAdministrationUserControl
{
    public string urlpath;
    public string EditImage;
    public string ImageName;
    public string width;
    public string height;
    public string ImageFile;
    string ExtraFieldKey;
    string ExtraFieldValue;
    public int OperationId;
    public int i;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadURLPages(GetPortalID);
            LoadRecordsOnGrid();
            loadImage();
            LoadContent();
            LoadExtraField();
        }
        dvForm.Visible = false;
        divTableContent.Visible = false;
        trSubmitField.Visible = false;
        trExtraField.Visible = false;
        urlpath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        IncludeCssFile(urlpath + "css/module.css");
        IncludeScriptFile(urlpath + "js/Readmroe.js");
    }

    private void LoadExtraField()
    {
        try
        {
            ReadMoreController clt = new ReadMoreController();
            gdvExField.DataSource = clt.GetExtraField(int.Parse(SageUserModuleID), GetPortalID);
            gdvExField.DataBind();
            ddlExtraField.DataSource = clt.GetExtraField(int.Parse(SageUserModuleID), GetPortalID);
            ddlExtraField.DataValueField = "ExtraFieldID";
            ddlExtraField.DataTextField = "ExtraField";
            ddlExtraField.DataBind();
            ddlExtraField.Items.Insert(0, new ListItem("ChooseField", "-1"));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void loadImage()
    {
        ImgAddNewDoc.ImageUrl = GetTemplateImageUrl("imgadd.png", true);
        imbCancel.ImageUrl = GetTemplateImageUrl("imgdelete.png", true);
        imgSave.ImageUrl = GetTemplateImageUrl("imgsave.png", true);
        imbDeletePageThumb.ImageUrl = GetTemplateImageUrl("imgdelete.png", true);
        imbSaveContent.ImageUrl = GetTemplateImageUrl("imgsave.png", true);
        imbAddNewContent.ImageUrl = GetTemplateImageUrl("imgadd.png", true);
        imbContentCancel.ImageUrl = GetTemplateImageUrl("imgdelete.png", true);
        imgDeleteImage.ImageUrl = GetTemplateImageUrl("imgdelete.png", true);
        imbNewsCalender.ImageUrl = GetTemplateImageUrl("imgcalendar.png", true);
        imgAddExtraField.ImageUrl = GetTemplateImageUrl("imgadd.png", true);
        imageAddExtraField.ImageUrl = GetTemplateImageUrl("imgsave.png", true);
    }

    public void LoadURLPages(int PortalID)
    {
        try
        {
            ReadMoreController ctl = new ReadMoreController();
            ddlURL.DataSource = ctl.LoadURLPages(PortalID);
            ddlURL.DataTextField = "TabPath";
            ddlURL.DataValueField = "TabPath";
            ddlURL.DataBind();
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    public bool ThumbnailCallback()
    {
        return false;
    }

    public void ClearFormData()
    {
        txtHeader.Text = string.Empty;
        CkEditorPageAdd.Text = string.Empty;
        txtContentTitle.Text = string.Empty;
        contentEditor.Text = string.Empty;
        chkContentIsActive.Checked = false;
        txtShortDescription.Value = string.Empty;
        txtExtraField.Text = string.Empty;
        divExtrafield.Visible = false;
        Session["ContentImage"] = string.Empty;
        Session["ReadMoreLinkID"] = string.Empty;
        Session["PageImage"] = string.Empty;
        Session["ReadmoreContentID"] = string.Empty;
    }

    public void LoadRecordsOnGrid()
    {
        try
        {
            ReadMoreController ctl = new ReadMoreController();
            gdvEditRecord.DataSource = ctl.LoadRecordsOnGrid(GetPortalID, int.Parse(SageUserModuleID));
            gdvEditRecord.DataBind();
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    public void LoadContent()
    {
        try
        {
            ReadMoreController ctl = new ReadMoreController();
            gdvContentList.DataSource = ctl.LoadContentRecord(GetPortalID, int.Parse(SageUserModuleID));
            gdvContentList.DataBind();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    #region GvRecordDisplay

    protected void gdvEditRecord_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvEditRecord.PageIndex = e.NewPageIndex;
        LoadRecordsOnGrid();
    }

    protected void gdvEditRecord_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }

    protected void gdvEditRecord_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            int OprationID = Int32.Parse(e.CommandArgument.ToString());
            switch (e.CommandName.ToString())
            {
                case "Delete":
                    Delete(OprationID);
                    break;
                case "Edit":
                    Edit(OprationID);
                    break;
            }
        }
        catch (Exception ex)
        {
            throw (ex);
        }
    }

    private void Edit(int ReadMoreLinkID)
    {
        try
        {
            ReadMoreController ctl = new ReadMoreController();
            ReadMoreEditInfo obj = ctl.GetReadMoreEditInfoByID(ReadMoreLinkID);
            txtHeader.Text = obj.Header;
            CkEditorPageAdd.Text = obj.Description;
            ddlURL.SelectedValue = obj.URLPath;
            chkIsActive.Checked = obj.IsActive;
            var ImageWrapper = obj.ImageWrapper;
            Session["PageImage"] = obj.ImageName;
            Session["ReadMoreLinkID"] = obj.ReadMoreLinkID;
            if (obj.ImageName != "")
            {
                divPageImage.Visible = true;
                imgPageThumb.ImageUrl = urlpath + "Image/UploadedImage/" + obj.ImageName;
            }
            else
            {
                divPageImage.Visible = false;
            }
            ShowHidePage();

        }
        catch (Exception e)
        {
            throw e;
        }
    }

    private void Delete(int ReadMoreLinkID)
    {
        try
        {
            ReadMoreController ctl = new ReadMoreController();
            string Imagefile = ctl.GetImage(ReadMoreLinkID);
            DeleteImage(Imagefile);
            ctl.DeleteReadMoreLinkByID(ReadMoreLinkID);
            LoadRecordsOnGrid();
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    private void DeleteImage(string Imagefile)
    {
        try
        {
            string completePath = Server.MapPath(urlpath + "Image/UploadedImage/") + Imagefile;
            if (File.Exists(completePath))
            {
                File.Delete(completePath);
            }
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    protected void gdvEditRecord_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }

    protected void gdvEditRecord_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

    }

    protected void gdvEditRecord_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }

    protected void gdvEditRecord_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    #endregion

    protected void ImgAddNewDoc_Click(object sender, ImageClickEventArgs e)
    {
        ShowHidePage();
        divPageImage.Visible = false;
    }

    protected void imgSave_Click(object sender, ImageClickEventArgs e)
    {
        AddRecords();
    }

    protected void imbCancel_Click(object sender, ImageClickEventArgs e)
    {
        gdvEditRecord.Visible = true;
        dvAddBtn.Visible = true;
        dvForm.Visible = false;
        ClearFormData();
    }

    public void AddRecords()
    {
        int Pageid = 0;
        try
        {
            width = "250";
            height = "150";

            string pageImage = "";
            ReadMoreController ctl = new ReadMoreController();
            ReadMoreEditInfo info = new ReadMoreEditInfo();
            if (Session["ReadMoreLinkID"] != null && Session["ReadMoreLinkID"].ToString() != string.Empty)
            {
                Pageid = Int32.Parse(Session["ReadMoreLinkID"].ToString());
                info.ReadMoreLinkID = Pageid;

            }
            else
            {
                info.ReadMoreLinkID = 0;

            }

            info.Description = CkEditorPageAdd.Text;
            info.PortalID = GetPortalID;
            info.UserModuleID = int.Parse(SageUserModuleID);
            info.Header = txtHeader.Text;
            info.URLPath = ddlURL.SelectedItem.ToString();
            info.IsActive = chkIsActive.Checked;
            string PageThumbimg = PageImageupload.PostedFile.FileName;
            if (PageThumbimg == "" && Session["PageImage"].ToString() == string.Empty)
            {
                ShowHidePage();
                ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/ReadMore/ModuleLocalText", "uploadimage"), "", SageMessageType.Alert);
                return;
            }
            string thumbTarget = Server.MapPath(urlpath + "Image/UploadedImage");
            if (!Directory.Exists(thumbTarget))
            {
                Directory.CreateDirectory(thumbTarget);
            }
            if (Pageid != 0 && PageThumbimg == "")
            {
                pageImage = Session["PageImage"].ToString();
                if (pageImage == null)
                {
                    info.ImageName = "";
                }
                else
                {
                    info.ImageName = pageImage;
                }
            }
            else if (Pageid == 0 && PageThumbimg == "")
            {
                info.ImageName = "";
            }
            else
            {
                System.Drawing.Image.GetThumbnailImageAbort thumbnailImageAbortDelegate = new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback);
                if (PageImageupload.HasFile)
                {
                    pageImage = PageImageupload.PostedFile.FileName;
                    info.ImageName = pageImage;
                    using (System.Drawing.Bitmap originalImage = new System.Drawing.Bitmap(PageImageupload.PostedFile.InputStream))
                    {
                        using (System.Drawing.Image thumbnail = originalImage.GetThumbnailImage(Int32.Parse(width), Int32.Parse(height), thumbnailImageAbortDelegate, IntPtr.Zero))
                        {
                            thumbnail.Save(System.IO.Path.Combine(thumbTarget, PageImageupload.FileName));
                        }
                    }
                }
            }

            info.ImageWrapper = "<img width='" + width + "' height='" + height + "' src='Modules/ReadMore/Image/UploadedImage/" + pageImage + "'/>";

            ctl.SaveEditRecords(info);
            ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/ReadMore/ModuleLocalText", "PageSaveSuccessfully"), "", SageMessageType.Success);
            ClearFormData();
            LoadRecordsOnGrid();
            Session.Abandon();
            gdvEditRecord.Visible = true;
            dvAddBtn.Visible = true;
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    protected void imbDeletePageThumb_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            string PageImage = Session["PageImage"].ToString();
            DeleteImage(PageImage);
            Session["PageImage"] = string.Empty; ;
            ShowHidePage();
            divPageImage.Visible = false;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void ShowHidePage()
    {
        dvForm.Visible = true;
        gdvEditRecord.Visible = false;
        dvAddBtn.Visible = false;
    }

    protected void imbAddNewContent_Click(object sender, ImageClickEventArgs e)
    {
        ShowHide();
    }

    private void ShowHide()
    {
        divTableContent.Visible = true;
        divAddContent.Visible = false;
        divContentData.Visible = false;
        divContentImage.Visible = false;
    }

    protected void imbSaveContent_Click(object sender, ImageClickEventArgs e)
    {
        AddUpdateContent();
    }

    private void AddUpdateContent()
    {
        int contentid = 0;
        string img = "";
        try
        {
            string w = "250";
            string h = "150";
            // string id = Session["ReadmoreContentID"].ToString();
            ReadMoreController ctl = new ReadMoreController();
            ReadmoreContent obj = new ReadmoreContent();
            if (Session["ReadmoreContentID"] != null && Session["ReadmoreContentID"].ToString() != string.Empty)
            {
                contentid = Int32.Parse(Session["ReadmoreContentID"].ToString());
                obj.ContentID = contentid;
            }
            else
            { obj.ContentID = 0; }
            obj.PortalID = GetPortalID;
            obj.UserModuleID = int.Parse(SageUserModuleID);
            obj.ContentTitle = txtContentTitle.Text;
            obj.ShortDescription = txtShortDescription.Value;
            obj.ContentDescription = contentEditor.Text;
            obj.ContentDate = DateTime.Now;
            obj.IsActive = chkContentIsActive.Checked;

            string TargetFolder = Server.MapPath(urlpath + "Image/UploadedImage");
            if (!Directory.Exists(TargetFolder))
            {
                Directory.CreateDirectory(TargetFolder);
            }
            string ImageFile = contentImageUpload.PostedFile.FileName;
            if (ImageFile == "" && Session["ContentImage"].ToString() == string.Empty)
            {
                ShowHide();
                ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/ReadMore/ModuleLocalText", "uploadimage"), "", SageMessageType.Alert);
                return;
            }
            if (contentid != 0 && ImageFile == "")
            {
                img = Session["ContentImage"].ToString();
                if (img == null)
                {
                    obj.ContentImage = "";
                }
                else
                {
                    obj.ContentImage = img;
                }
            }
            else if (contentid == 0 && ImageFile == "")
            {
                obj.ContentImage = "";
            }
            else
            {
                System.Drawing.Image.GetThumbnailImageAbort thumbnailImageAbortDelegate = new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback);
                if (contentImageUpload.HasFile)
                {
                    obj.ContentImage = ImageFile;
                    using (System.Drawing.Bitmap originalImage = new System.Drawing.Bitmap(contentImageUpload.PostedFile.InputStream))
                    {
                        using (System.Drawing.Image thumbnail = originalImage.GetThumbnailImage(250, 150, thumbnailImageAbortDelegate, IntPtr.Zero))
                        {
                            thumbnail.Save(System.IO.Path.Combine(TargetFolder, contentImageUpload.FileName));
                        }
                    }
                }
            }

            obj.ImageWrapper = "<img width='" + w + "' height='" + h + "' src='Modules/ReadMore/Image/UploadedImage/" + img + "'/>";
            ctl.AddContent(obj);

            List<ReadmoreContent> lstFields = new List<ReadmoreContent>();
            lstFields = Session["ExtraField"] as List<ReadmoreContent>;
            if (lstFields != null)
            {
                foreach (ReadmoreContent info in lstFields)
                {
                    ExtraFieldKey += info.ExtraField + "~";
                    ExtraFieldValue += info.ExtraFieldValue + "~";
                }
                lstFields.Clear();
                Session["ExtraField"] = lstFields;
                gdvExtraField.DataSource = lstFields;
                gdvExtraField.DataBind();
                Session.Remove("ExtraField");
                ctl.AddExtraFieldValue(ExtraFieldKey, ExtraFieldValue, int.Parse(SageUserModuleID),obj.ContentID);
            }
            ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/ReadMore/ModuleLocalText", "ContentSaveSuccessfully"), "", SageMessageType.Success);
            Session.Abandon();
            LoadContent();
            ClearFormData();
            divAddContent.Visible = true;
            divContentData.Visible = true;
            divTableContent.Visible = false;

        }
        catch (Exception ex)
        { throw ex; }
    }

    protected void imageAddExtraField_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            int FieldID = Convert.ToInt32(Session["FieldID"]);
            if (FieldID == 0)
            {
                List<ReadmoreContent> lstExtraFields = new List<ReadmoreContent>();
                if (Session["ExtraField"] != null)
                {
                    i = Convert.ToInt32(Session["ExtraFieldID"].ToString());
                    i++;
                    Session["ExtraFieldID"] = i;
                    lstExtraFields = Session["ExtraField"] as List<ReadmoreContent>;
                }
                else
                {
                    Session["ExtraFieldID"] = 0;
                }
                ReadmoreContent obj = new ReadmoreContent();
                obj.ExtraFieldValue = ckEditorExtraField.Text;
                obj.ExtraFieldID = i;
                obj.ExtraField = ddlExtraField.SelectedItem.ToString();
                lstExtraFields.Add(obj);
                gdvExtraField.DataSource = lstExtraFields;
                gdvExtraField.DataBind();
                Session["ExtraField"] = lstExtraFields;
            }
            else
            {
                ReadMoreController clt = new ReadMoreController();
                ReadmoreContent obj = new ReadmoreContent();
                obj.ExtraField = ddlExtraField.SelectedItem.ToString();
                obj.ExtraFieldValue = ckEditorExtraField.Text;
                obj.UserModuleID = int.Parse(SageUserModuleID);
                clt.UpdateExtraField(obj, FieldID);
                LoadExValueInGrid();
                //Session.Abandon();
                Session["FieldID"] = string.Empty;
                Session["ExtraFieldID"] = string.Empty;
            }
            ckEditorExtraField.Text = string.Empty;
            ShowHide();
			            if (Session["ContentImage"] != null && Session["ContentImage"].ToString() != string.Empty)
            {
                string ctimage = Session["ContentImage"].ToString();
                divContentImage.Visible = true;
                imgContentThumbImage.ImageUrl = urlpath + "Image/UploadedImage/" + ctimage;
            }
			
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void DeleteSessionField(int sessionID)
    {
        try
        {
            List<ReadmoreContent> lstFields = new List<ReadmoreContent>();
            lstFields = Session["ExtraField"] as List<ReadmoreContent>;

            List<ReadmoreContent> lstNew = new List<ReadmoreContent>();
            foreach (ReadmoreContent info in lstFields)
            {
                if (info.ExtraFieldID != sessionID)
                {
                    lstNew.Add(info);
                }
            }
            lstFields.Clear();
            foreach (ReadmoreContent obj in lstNew)
            {
                lstFields.Add(obj);
            }
            gdvExtraField.DataSource = lstFields;
            gdvExtraField.DataBind();
            Session.Remove("ExtraField");
            Session["ExtraField"] = lstFields;
            ShowHide();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void gdvContentList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvContentList.PageIndex = e.NewPageIndex;
        LoadContent();
    }

    protected void gdvContentList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            int OprationID = Int32.Parse(e.CommandArgument.ToString());
            switch (e.CommandName.ToString())
            {
                case "ContentDelete":
                    DeleteContent(OprationID);
                    break;
                case "ContentEdit":
                    EditContent(OprationID);
                    break;
            }
        }
        catch (Exception ex)
        {
            throw (ex);
        }
    }

    private void EditContent(int contentID)
    {
        try
        {
            ReadMoreController ctl = new ReadMoreController();
            ReadmoreContent obj = ctl.ReadmoreGetContentDetails(int.Parse(SageUserModuleID), contentID);
            txtContentTitle.Text = obj.ContentTitle;
            contentEditor.Text = obj.ContentDescription;
            chkContentIsActive.Checked = obj.IsActive;
            txtContentDate.Text = CommonHelper.ShortTimeReturn(obj.ContentDate);
            txtShortDescription.Value = obj.ShortDescription;
            Session["ReadmoreContentID"] = obj.ContentID;
            Session["ContentImage"] = obj.ContentImage;
            if (obj.ContentImage != "")
            {
                divContentImage.Visible = true;
                imgContentThumbImage.ImageUrl = urlpath + "Image/UploadedImage/" + obj.ContentImage;
            }
            else
            {
                divContentImage.Visible = false;
            }
            gdvExtraField.DataSource = null;
            gdvExtraField.DataBind();

            LoadExValueInGrid();
            showHideEdit();
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    private void showHideEdit()
    {
        divAddContent.Visible = false;
        divContentData.Visible = false;
        divTableContent.Visible = true;
    }

    private void DeleteContent(int OperationID)
    {
        try
        {
            ReadMoreController ctl = new ReadMoreController();
            string Imagefile = ctl.GetImage(OperationID);
            DeleteImage(Imagefile);
            ctl.DeleteReadmoreContent(OperationID);
            LoadContent();
        }
        catch (Exception e)
        {
            throw e;
        }
    }

    protected void gdvContentList_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }

    protected void gdvContentList_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void gdvContentList_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }

    protected void gdvContentList_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
    }

    protected void imbContentCancel_Click(object sender, ImageClickEventArgs e)
    {
        divTableContent.Visible = false;
        divAddContent.Visible = true;
        divContentData.Visible = true;
        ClearFormData();
    }

    protected void imgDeleteImage_Click(object sender, EventArgs e)
    {
        string contentImage = Session["ContentImage"].ToString();
        DeleteImage(contentImage);
        Session["ContentImage"] = string.Empty;
        divContentImage.Visible = false;
        divTableContent.Visible = true;
    }

    protected void imgAddExtraField_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            ReadMoreController clt = new ReadMoreController();
            ReadmoreContent obj = new ReadmoreContent();
            obj.PortalID = GetPortalID;
            obj.UserModuleID = int.Parse(SageUserModuleID);
            obj.ExtraField = txtExtraField.Text;
            clt.AddExtraField(obj);
            ClearFormData();
            LoadExtraField();
        }

        catch (Exception ex)
        {
            throw ex;
        }
    }

 protected void ddlExtraField_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            if (ddlExtraField.SelectedValue != "-1")
            {
                trExtraField.Visible = true;
                trSubmitField.Visible = true;
                //ShowHide();               
            }
           ShowHide();
            if (Session["ContentImage"] != null && Session["ContentImage"].ToString() != string.Empty)
            {
                string contimg = Session["ContentImage"].ToString();
                divContentImage.Visible = true;
                imgContentThumbImage.ImageUrl = urlpath + "Image/UploadedImage/" + contimg;
            }     
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    private void LoadExValueInGrid()
    {
        try
        {
            int ContentID = Convert.ToInt32(Session["ReadmoreContentID"]);
            ReadMoreController clt = new ReadMoreController();
            gdvExtraFieldValue.DataSource = clt.ReadMoreGetExtraFieldvalue(int.Parse(SageUserModuleID), ContentID);
            gdvExtraFieldValue.DataBind();
			if (gdvExtraFieldValue.DataSource != null)
            {
                divExtrafield.Visible = true;
            }
            else
            {
                divExtrafield.Visible = false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void gdvExtraFieldValue_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvExtraFieldValue.PageIndex = e.NewPageIndex;
        LoadExValueInGrid();
    }

    protected void gdvExtraFieldValue_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            OperationId = Int32.Parse(e.CommandArgument.ToString());
            Session["FieldID"] = OperationId;
            switch (e.CommandName.ToString())
            {
                case "ExFieldDelete":
                    DeleteExtraField(OperationId);
                    break;
                case "ExFieldEdit":
                    EditExtraField(OperationId);
                    break;
            }
        }
        catch (Exception ex)
        {
            throw (ex);
        }
    }

    protected void gdvExtraField_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }

    protected void gdvExtraFieldValue_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void gdvExtraFieldValue_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }

    protected void gdvExtraField_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

    }

    protected void gdvExtraFieldValue_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }

    private void DeleteExtraField(int FieldID)
    {
        ReadMoreController clt = new ReadMoreController();
        clt.DeleteReadMoreExtraField(FieldID);
        LoadExValueInGrid();
        ShowHide();
    }

    private void EditExtraField(int FieldID)
    {
        try
        {
            ReadMoreController ctl = new ReadMoreController();
            ReadmoreContent obj = ctl.ReadMoreGetExtraFieldByID(int.Parse(SageUserModuleID), FieldID);
            ckEditorExtraField.Text = obj.ExtraFieldValue;
            ddlExtraField.SelectedItem.Text = obj.ExtraField;
            trExtraField.Visible = true; ;
            trSubmitField.Visible = true;
            showHideEdit();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void gdvExtraField_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            int SessionExFieldID = Int32.Parse(e.CommandArgument.ToString());
            switch (e.CommandName.ToString())
            {
                case "FieldDelete":
                    DeleteSessionField(SessionExFieldID);
                    break;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void gdvExtraField_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }

    protected void gdvExtraField_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void gdvExField_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            OperationId = Int32.Parse(e.CommandArgument.ToString());
            switch (e.CommandName.ToString())
            {
                case "DeleteField":
                    DeleteExField(OperationId);
                    break;
            }
        }
        catch (Exception ex)
        {
            throw (ex);
        }
    }

    private void DeleteExField(int FieldID)
    {
        ReadMoreController clt = new ReadMoreController();
        clt.DeleteExtraField(int.Parse(SageUserModuleID), FieldID);
        LoadExtraField();
    }

    protected void gdvExField_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }

    protected void gdvExField_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }

    protected void gdvEditRecord_SelectedIndexChanged(object sender, EventArgs e)
    {

    }

    protected void gdvExField_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {

    }

    protected void gdvExField_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvExField.PageIndex = e.NewPageIndex;
        LoadExtraField();
    }
    protected void gdvExtraFieldValue_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }
    protected void gdvExtraFieldValue_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {

    }
}
