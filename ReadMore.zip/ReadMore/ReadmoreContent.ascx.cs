﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.ReadMoreLink.Entity;
using SageFrame.ReadMoreLink.Controller;
using System.Web.UI.HtmlControls;

public partial class Modules_Read_More_ReadmoreContent : BaseAdministrationUserControl
{
    public int UserModuleID;
    public int contentID;
    public string urlpath;
    protected void Page_Load(object sender, EventArgs e)
    {
        urlpath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
        BindContent();
        IncludeCss("ReadMore", "Modules/ReadMore/css/module.css");

    }

    private void BindContent()
    {
        ReadmoreContent obj = new ReadmoreContent();
        contentID = Convert.ToInt32(Session["ContentID"]);

        ReadMoreController clt = new ReadMoreController();
        obj = clt.ReadmoreGetContentDetails(int.Parse(SageUserModuleID), contentID);
        lblContentTitle.Text = obj.ContentTitle;
		 ltrshortdesc.Text = obj.ShortDescription;
        ltrContentDesc.Text = obj.ContentDescription;
        string date = ReadmoreDateFormat(obj.ContentDate);
        lblContentDate.Text = date;
        if (obj.ContentImage != "")
        {
            imgContent.ImageUrl = urlpath + "Image/UploadedImage/" + obj.ContentImage;
        }
        else
        {
            imgContent.Visible = false;
        }
        rptrExtraField.DataSource = clt.ReadMoreGetExtraFieldvalue(int.Parse(SageUserModuleID), contentID);
        rptrExtraField.DataBind();

    }

    private string ReadmoreDateFormat(DateTime ContentDate)
    {

        string ContentDateFormat = string.Empty;
        ReadMoreController ctl = new ReadMoreController();
        ReadMoreSettingEntity setObj = ctl.GetSettingValues(int.Parse(SageUserModuleID), contentID);
        ContentDateFormat = setObj.DateFormat;
        ContentDateFormat = ContentDate.ToString(ContentDateFormat);
        return ContentDateFormat;
    }

    protected void rptrExtraField_ItemCommand(object source, RepeaterCommandEventArgs e)
    {

    }
    protected void rptrExtraField_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {

    }
}
