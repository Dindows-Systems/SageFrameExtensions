﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.ReadMoreLink.Controller;
using SageFrame.ReadMoreLink.Entity;
using System.IO;
using SageFrame.SageFrameClass;


public partial class Modules_Read_More_ReadMoreSetting : BaseAdministrationUserControl
{  
    public int portalID;
    public int userModuleID;
    public string urlpath;
    public bool ReadmoreLinkText;
    public bool HeaderText;
    public bool IsHeaderLink;
    public bool HeaderImage;  
    public string DescriptionLength;
    public bool ReadmoreLinkImage;
    public string Image;
    public string Text;
    public bool ReadmoreLinkVisible;
    public bool Description;
    public string AddedBy;
    public string ReadmoreType;
    public string DateFormat;
    public string PaginationSize;
    public bool Pagination;
    public bool ViewAll;

    protected void Page_Load(object sender, EventArgs e)
    {
        urlpath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
     
            portalID = GetPortalID;
            userModuleID = Int32.Parse(SageUserModuleID);
            AddedBy = GetUsername;

            GetSetting();
    }

    protected void Page_Init(object sender, EventArgs e)
    {
        IncludeCss("ReadMore" , "/Modules/ReadMore/css/module.css");
        IncludeJs("ReadMore", "/Modules/ReadMore/js/jquery.numeric.js", "/Modules/ReadMore/js/Readmore.js", "/Modules/ReadMore/js/ajaxupload.js");       
        string modulePath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "EventManagerGlobalVariable1", " var ReadmoreUploadPath='" + ResolveUrl(modulePath) + "';", true);
    }

    private void GetSetting()
    {        
        ReadMoreController ctl = new ReadMoreController();
        ReadMoreSettingEntity setObj = ctl.GetSettingValues(userModuleID, portalID);
        string iconPath = Server.MapPath(urlpath + "Image/ReadmoreLinkImage/" + setObj.Image);
        if (File.Exists(iconPath))
        {
            Image = setObj.Image;
        }
        else
        {
            Image = "";
        }
        Text = setObj.Text;
        ReadmoreLinkText = setObj.ReadmoreLinkText;
        ReadmoreLinkImage = setObj.ReadmoreLinkImage;
        HeaderText = setObj.HeaderText;
        HeaderImage = setObj.HeaderImage;
        Description = setObj.Description;
        IsHeaderLink = setObj.IsHeaderLink;
        ReadmoreLinkVisible = setObj.ReadmoreLinkVisible;
        DescriptionLength = setObj.DescriptionLength;
        ReadmoreType = setObj.ReadmoreType;
        DateFormat = setObj.DateFormat;
        Pagination = setObj.Pagination;
        PaginationSize = setObj.PaginationSize;
        ViewAll = setObj.ViewAll;
     
    }
  
}
