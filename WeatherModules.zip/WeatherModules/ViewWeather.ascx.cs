﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.Core;
using System.Collections;
using SageFrame.Weather.Entity;
using SageFrame.Web.Utilities;

public partial class Modules_WeatherModules_ViewWeather : BaseAdministrationUserControl
{
    public int UserModuleID, PortalID;
    protected void Page_Load(object sender, EventArgs e)
    {
        string modulePath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "globalVariables", " var WeatherServicePath='" + ResolveUrl(modulePath) + "';", true);
        UserModuleID = Int32.Parse(SageUserModuleID);
        PortalID = GetPortalID;
        InitializeJS();
        IncludeCss();
      
    }
    private void IncludeCss()
    {
		IncludeCss("WeatherModules", "/Modules/WeatherModules/css/module.css");
    }

    private void InitializeJS()
    {
        Page.ClientScript.RegisterClientScriptInclude("JQueryFileTree", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/js/jquery.simpleWeather.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryFileTree", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/js/json2.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryFileTree", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/js/jquery-1.2.6-vsdoc.js"));
        Page.ClientScript.RegisterClientScriptInclude("JQueryFileTree", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/js/jquery-1.2.6.min.js"));
    }
  
}
