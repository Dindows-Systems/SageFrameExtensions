﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Core;
using SageFrame.Common;
using SageFrame.Web;
using SageFrame.Web.Utilities;
using SageFrame.Weather.DataProvider;
using SageFrame.Weather.Entity;


public partial class Modules_WeatherModules_WeatherSetting : BaseAdministrationUserControl
{


    protected void Page_Load(object sender, EventArgs e)
    {

        int usermoduleid = 0;
        usermoduleid = Int32.Parse(SageUserModuleID);
        getSettingInform();
      btnSaveSetting.ImageUrl = GetTemplateImageUrl("imgSave.png", true);

    }
    public void getSettingInform()
    {
        GetSettingInfo obj = new GetSettingInfo();
        obj=GetSettingList(GetPortalID, Int32.Parse(SageUserModuleID));
        txtDefaultLocation.Text = obj.DefaultLocation;
        chkHumidity.Checked = obj.Humidity_Pressure;
        chkNxtDay.Checked = obj.NextDayWeather;
        chkSun.Checked = obj.SunInformation;
        chkWindRecord.Checked = obj.WindRecord;
 }
    protected void CheckBox4_CheckedChanged(object sender, EventArgs e)
    {

    }

    protected void btnSaveSetting_Click(object sender, EventArgs e)
    {
        //////try
        //////{
        //////    SaveSetting("SunInformation", Convert.ToString(chkSun.Checked), Int32.Parse(SageUserModuleID), GetUsername, GetUsername, GetPortalID);
        //////    SaveSetting("WindRecord", Convert.ToString(chkWindRecord.Checked), Int32.Parse(SageUserModuleID), GetUsername, GetUsername, GetPortalID);
        //////    SaveSetting("Humidity_Pressure", Convert.ToString(chkHumidity.Checked), Int32.Parse(SageUserModuleID), GetUsername, GetUsername, GetPortalID);
        //////    SaveSetting("NextDayWeather", Convert.ToString(chkNxtDay.Checked), Int32.Parse(SageUserModuleID), GetUsername, GetUsername, GetPortalID);
        //////    SaveSetting("DefaultLocation", txtDefaultLocation.Text, Int32.Parse(SageUserModuleID), GetUsername, GetUsername, GetPortalID);
        //////     ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/WeatherModules/ModuleLocalText", "SettingSavedSuccessfully"), "", SageMessageType.Success);
        //////    //ShowMessage(SageMessageTitle.Information.ToString(), GetSageMessage("WeatherModules", "SettingSavedSuccessfully"), "", SageMessageType.Success);
        //////}
        //////catch (Exception ex)
        //////{
        //////    ProcessException(ex);
        //////}
       
        int lenDefault = (txtDefaultLocation.Text).Length; 
        if (lenDefault < 26)
        {
            try
            {
                SaveSetting("SunInformation", Convert.ToString(chkSun.Checked), Int32.Parse(SageUserModuleID),
                            GetUsername, GetUsername, GetPortalID);
                SaveSetting("WindRecord", Convert.ToString(chkWindRecord.Checked), Int32.Parse(SageUserModuleID),
                            GetUsername, GetUsername, GetPortalID);
                SaveSetting("Humidity_Pressure", Convert.ToString(chkHumidity.Checked), Int32.Parse(SageUserModuleID),
                            GetUsername, GetUsername, GetPortalID);
                SaveSetting("NextDayWeather", Convert.ToString(chkNxtDay.Checked), Int32.Parse(SageUserModuleID),
                            GetUsername, GetUsername, GetPortalID);
                SaveSetting("DefaultLocation", txtDefaultLocation.Text, Int32.Parse(SageUserModuleID), GetUsername,
                            GetUsername, GetPortalID);
                        ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/WeatherModules/ModuleLocalText", "SettingSavedSucessfully"), "", SageMessageType.Success);

            }
            catch (Exception ex)
            {
                ProcessException(ex);
            }
        }
        else
        {

            ShowMessage("", GetSageMessage("Announcement", "LengthValidation"), "", SageMessageType.Alert);
        }
    }
    private void SaveSetting(string Key, string value, int usermoduleid, string Addedby, string Updatedby, int PortalID)
    {
        WeatherSettingProvider objSet = new WeatherSettingProvider();
        objSet.SaveSetting(Key, value, usermoduleid, Addedby, Updatedby, PortalID);


    }
    public GetSettingInfo GetSettingList(int PortalID, int UserModuleID)
    {
        GetSettingInfo Getsettin = new GetSettingInfo();
        List<KeyValuePair<string, object>> paramCol = new List<KeyValuePair<string, object>>();
        paramCol.Add(new KeyValuePair<string, object>("@PortalID", PortalID));
        paramCol.Add(new KeyValuePair<string, object>("@UserModuleID", UserModuleID));
        SQLHandler sageSQL = new SQLHandler();
        Getsettin = sageSQL.ExecuteAsObject<GetSettingInfo>("[usp_GetWeatherSetting]", paramCol);

        return Getsettin;
 }

}
