﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SageFrame.Web;
using SageFrame.Announcement.Controller;
using SageFrame.SageFrameClass;
using SageFrame.Announcement.Entity;
public partial class Modules_SageAnnouncement_SageAnnouncementSetting : BaseAdministrationUserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                ImageURL();
                SetAnnouncementSetting();
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }


    private void ImageURL()
    {
        imbSaveAnnouncementSetting.ImageUrl = GetTemplateImageUrl("imgSave.png", true);

    }


    protected void imbSaveAnnouncementSetting_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            SaveSageAnnouncementSetting("AnnouncementHeaderText", txtAnnouncementHeaderText.Text, Int32.Parse(SageUserModuleID), GetUsername, GetUsername, GetPortalID);
            SaveSageAnnouncementSetting("ReadMoreText", txtReadMoreText.Text, Int32.Parse(SageUserModuleID), GetUsername, GetUsername, GetPortalID);
            SaveSageAnnouncementSetting("NoContentText", txtNoContentText.Text, Int32.Parse(SageUserModuleID), GetUsername, GetUsername, GetPortalID);
            SaveSageAnnouncementSetting("items_per_page", txtItemperpage.Text, Int32.Parse(SageUserModuleID), GetUsername, GetUsername, GetPortalID);
			ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/SageAnnouncement/ModuleLocalText", "AnnouncementSettingSavedSuccessfully"), "", SageMessageType.Success);


        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }


    }


    private void SaveSageAnnouncementSetting(string AnnounceSettingKey, string value, int usermoduleid, string Addedby, string Updatedby, int PortalID)
    {
        try
        {
            AnnouncementController objC = new AnnouncementController();
            objC.SaveSageAnnouncementSetting(AnnounceSettingKey, value, usermoduleid, Addedby, Updatedby, PortalID);
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }

    }


    private void SetAnnouncementSetting()
    {
        try
        {
            AnnouncementInfo objInf = GetAnnouncementSetting(GetPortalID, Int32.Parse(SageUserModuleID));
            txtAnnouncementHeaderText.Text = objInf.AnnouncementHeaderText;
            txtReadMoreText.Text = objInf.ReadMoreText;
            txtNoContentText.Text = objInf.NoContentText;
			txtItemperpage.Text =objInf.items_per_page;
        }
        catch (Exception ex)
        {
            ProcessException (ex);
        }
    }


    private AnnouncementInfo GetAnnouncementSetting(int PortalID, int UserModuleID)
    {
       
            AnnouncementInfo GetSetting = new AnnouncementInfo();
            AnnouncementController ObjC = new AnnouncementController();
            return GetSetting = ObjC.GetAnnouncementSetting(PortalID, UserModuleID);
       
       
    }

}
