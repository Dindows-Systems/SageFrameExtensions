﻿

(function($) {
    $.createAnnouncementScript = function(p) {
        p = $.extend
        ({
            PortalId: 1,
            usermoduleid: 1,
            AnnouncementHeader: '',
            ReadMoreText: '',
            baseURL: 'Services/Services.aspx/',
            NoContent: '',
			Itemsperpage: '1'
        }, p);


        $('#btnSearchByDateRange').attr('src', p.baseURL + "images/search-btn.jpg");
        $('#ToDateTrigger').attr('src', p.baseURL + "images/imgcalendar.png");
        $('#calendar-trigger').attr('src', p.baseURL + "images/imgcalendar.png");
        $('#imgCalenderSingle').attr('src', p.baseURL + "images/imgcalendar.png");
        $('#imgSearchSingle').attr('src', p.baseURL + "images/search-btn.jpg");
        $('input[name=rdbsearch]:first').attr('checked', true);
        $('#divSearchByDate').hide();
        $('#divSearchByDateRange').show();

        getDateArchiveOnTreeView();
        GetLatestAnnouncement();
        $('#btnSearchByDateRange').click(function() {
            GetAnnouncementByDateRange();
        });
        $('#imgSearchSingle').click(function() {
            GetAnnouncementBySingleDate();
        });
        jQuery('input[name=rdbsearch]:radio').click(function() {
            var clickval = jQuery(this).val();
            if (clickval == 'DateRange') {
                $('#divSearchByDate').hide();
                $('#divSearchByDateRange').show();

            }
            else if (clickval == 'DateSingle') {
                $('#divSearchByDateRange').hide();
                $('#divSearchByDate').show();
            }
        });

        function GetLatestAnnouncement() {
            $.ajax({
                type: "POST",
                url: p.baseURL + "Services/SageAnnouncementWebService.asmx/GetLatestAnnouncement",
                data: JSON2.stringify({ PortalID: p.PortalId, UserModuleID: p.usermoduleid }),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function(msg) {
                    var htmlcontent = "";
					$('#divAnnounceHeader').html(p.AnnouncementHeader);
                   // htmlcontent += ('<h2 class=\"cssClassContentTile\"><span class=\"ContentTitleText\">' + p.AnnouncementHeader + '</span></h2>');
                    if (msg.d.length == 0) {
                        $('#PageNav').attr("style","display:none");
                        htmlcontent += ('<div>' + p.NoContent + '</div>');
                    }
                    else {

                        $.each(msg.d, function(index, Data) {
                            var AnnounceID = Data.AnnouncementID;
                            var latestannouncedate = dateFormat(Data.PublishDate, "fullDate");
                            htmlcontent += ('<li><div class=\"sfAnnouncement\">');
                            htmlcontent += ('<h2>' + Data.Title + '</h2>');
                            htmlcontent += (' <span class=\"sfItalic\">By ' + Data.AuthorName + ' On ' + latestannouncedate + '</span>');
                            htmlcontent += ('<p></p>');
                            htmlcontent += ('<div class=\"sfAnnouncementdesc\">' + Data.ShortDescription + '</div>');
                            htmlcontent += ('<a href=\"#\" id="' + AnnounceID + '" class=\"sfBtn\" >' + p.ReadMoreText + '</a>');
                            htmlcontent += ('</div></li>');

                        });
                    }
                    $('#divAnnouncement').html(htmlcontent);
					if(msg.d.length>p.Itemsperpage)
					{
                    $('#SagePagination').pajinate({
                        items_per_page: p.Itemsperpage
					
                    });
					}
					

                },
                error: function(error) {
                    //alert('Error Getting Load Latest Announcement');
                }

            });
        }
        function getDateArchiveOnTreeView() {
            $.ajax({
                type: "POST",
                url: p.baseURL + "Services/SageAnnouncementWebService.asmx/GetAnnouncementArchiveYear",
                data: JSON2.stringify({ PortalID: parseInt(p.PortalId), UserMOduleID: parseInt(p.usermoduleid) }),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                async: false,
                success: function(msg) {
                    var htmldata = ('<ul id="test">');
                    if (msg.d.length == 0) {
                        htmldata += ('<li> No Archive!!</li>');
                    }
                    else {
                        $.each(msg.d, function(index, Data) {
                            if (!Data.ArchiveYear == "") {
                                htmldata += ('<li class=\"expandable\" id="' + Data.ArchiveYear + '"><a href=\"#\">' + Data.ArchiveYear + '<\a>');
                                htmldata += AnnouncementArchiveGetMonth(Data.ArchiveYear);
                                htmldata += '</li>';
                            }
                        });
                    }

                    htmldata += ('</ul>');
                    $('#treeview').append(htmldata);
                    $("#treeview")
		.jstree({ "plugins": ["themes", "html_data", "ui"] })
		.bind("select_node.jstree", function(event, data) {
		    var DateYearMonth = data.rslt.obj.attr("id");
		    GetAnnouncementByYearOrMonth(DateYearMonth);
		})
.delegate("a", "click", function(event, data) { event.preventDefault(); })

                },
                error: function(error) {
                    // alert('error getting date Archive');
                }

            });
        }



        function AnnouncementArchiveGetMonth(archiveYear) {
            var htmldata = '<ul>';
            $.ajax({
                type: "POST",
                url: p.baseURL + "Services/SageAnnouncementWebService.asmx/AnnouncementArchiveGetMonth",
                data: JSON2.stringify({ PortalID: parseInt(p.PortalId), year: archiveYear, UserModuleID: parseInt(p.usermoduleid) }),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                async: false,
                success: function(msg) {

                    $.each(msg.d, function(index, Data) {

                        htmldata += ('<li class=\"jstree-open\" id="' + Data.ArchiveMonthValue + ',' + archiveYear + '"><a href=\"#\">' + Data.ArchiveMonth + '</a></li>');
                    });
                    htmldata += '</ul>';
                },
                error: function(error) {
                    // alert('error getting date Archive Month');
                }

            });
            return htmldata;
        }

        function GetAnnouncementByYearOrMonth(date) {
            $.ajax({
                type: "POST",
                url: p.baseURL + "Services/SageAnnouncementWebService.asmx/GetAnnouncementByYearOrMonth",
                data: JSON2.stringify({ PortalID: parseInt(p.PortalId), ClickedYearMonth: date, UserModuleID: parseInt(p.usermoduleid) }),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function(msg) {
                    var htmlc = "";
                    if (msg.d.length == 0) {
					$('#PageNav').attr("style","display:none");
                        htmlc += ('</br></br><div>' + p.NoContent + '</div>');
                    }
                    else {
                        $.each(msg.d, function(index, Data) {
                            if (msg.d.length != '') {
                                var AnnounceID = Data.AnnouncementID;
                                var announcedate = dateFormat(Data.PublishDate, "fullDate");
                                htmlc += ('<li><div class=\"cssClassAnnounceContent\">');
                                htmlc += ('<div class=\"cssClassHead\"><h2 class=\"cssClassTitle\">' + Data.Title + '</h2></div>');
                                htmlc += ('<span>By ' + Data.AuthorName + '</span> <span>On ' + announcedate + '</span>');
                                htmlc += ('<p></p>');
                                htmlc += ('<div class=\"cssClassAnnounce\">' + Data.ShortDescription + '</div>');
                                htmlc += ('<a href=\"#\" id="' + AnnounceID + '" class=\"sfBtn\">' + p.ReadMoreText + '</a>');
                                htmlc += ('</div></li>');
                            }

                        });
                    }
                    $('#divAnnouncement').html(htmlc);
                    if (msg.d.length > p.Itemsperpage) {
			
                    $('#SagePagination').pajinate({
                        items_per_page: p.Itemsperpage
                    });
					}

                },
                error: function(error) {
                    //alert('error getting load announcement by date');
                }
            });

        }


           function getReadMoreData(AnnounceID) {
            $.ajax({
                type: "POST",
                url: p.baseURL + "Services/SageAnnouncementWebService.asmx/getReadMoreData",
                data: JSON2.stringify({ AnnouncementId: parseInt(AnnounceID) }),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function(msg) {
                    var htmlMore = "";
						$('#PageNav').attr("style","display:none");
                    $('#divAnnouncement').html('');
                    //htmlMore += ('<h2 class=\"cssClassContentTile\"><span class=\"ContentTitleText\">' + p.AnnouncementHeader + '</span></h2>');
                    $.each(msg.d, function(index, Data) {
                        var announcedate = dateFormat(Data.PublishDate, "fullDate"); ;
                        htmlMore += ('<div class=\"cssClassHead\"><h2 class=\"cssClassTitle\">' + Data.Title + '</h2></div>');
                        htmlMore += ('<span>By ' + Data.AuthorName + '</span><span> On ' + announcedate + '</span>');
                        htmlMore += ('<p></p>');
                        htmlMore += ('<div class=\"cssClassAnnounce\">' + Data.LongDescription + '</div>');
                        htmlMore += ('<a id=\"a_returnback\" href=\"#\"class=\"sfBtn\">Back</a>');
                    });
                    $('#divAnnouncement').html(htmlMore);

                },
                error: function(error) {
                    // alert('error getting More News');
                }
            });
        }

        var CheckFromDate = new Array();
        var CheckToDate = new Array();

        function GetAnnouncementByDateRange(obj) {

            var FromDate = $("input#calendar-inputField").val();
            var Todate = $("input#txtToDate").val();
            if ((FromDate.length) == 0 || (Todate.length) == 0) {
                javascript: return confirm('Please enter the Date range!!');
            }
            else {

                var fromDate = Date.parse(FromDate);
                var toDate = Date.parse(Todate);
                if (toDate <= fromDate) {

                    alert("Please check the date range");
                }
                else {
   
                    $.ajax({
                        type: "POST",
                        url: p.baseURL + "Services/SageAnnouncementWebService.asmx/GetAnnouncementByDateRange",
                        data: JSON2.stringify({ PortalID: parseInt(p.PortalId), FromDate: FromDate, Todate: Todate, UserModuleID: parseInt(p.usermoduleid) }),
                        contentType: "application/json; charset=utf-8",
                        dataType: "json",
                        success: function(msg) {

                            var htmlcon = "";

                            if (msg.d.length == 0) {
							$('#PageNav').attr("style","display:none");
                                htmlcon += ('<div class=\"cssClassNoAnnounce\">' + p.NoContent + '</div>');
                            }
                            else {
                                //htmlcon += ('<h2 class=\"cssClassContentTile\"><span class=\"ContentTitleText\">' + p.AnnouncementHeader + ' in the date between ' + FromDate + ' and  ' + Todate + '</span></h2>');
                                $.each(msg.d, function(index, Data) {
                                    var AnnounceID = Data.AnnouncementID;
                                    var announcedate = dateFormat(Data.PublishDate, "fullDate");
                                    htmlcon += ('<li><div class=\"cssClassAnnounceContent\">');
                                    htmlcon += ('<div class=\"cssClassHead\"><h2 class=\"cssClassTitle\">' + Data.Title + '</h2></div>');
                                    htmlcon += ('<span>By ' + Data.AuthorName + '</span> <span>On ' + announcedate + '</span>');
                                    htmlcon += ('<p></p>');
                                    htmlcon += ('<div class=\"cssClassAnnounce\">' + Data.ShortDescription + '</div>');
                                    htmlcon += ('<a href=\"#\" id="' + AnnounceID + '" class=\"sfBtn\">' + p.ReadMoreText + '</a>');
                                    htmlcon += ('</div></li>');
                                });
                            }
                            $('#divAnnouncement').html(htmlcon);

                            if (msg.d.length > p.Itemsperpage) {
                    $('#SagePagination').pajinate({
                        items_per_page: p.Itemsperpage
                    });
					 }
					 


                        },
                        error: function(error) {
                            //alert('error getting load announcement');
                        }
                    });

                }
            }
        }
        function GetAnnouncementBySingleDate() {
            var singleDate = $("input#txtSerchBySingleDate").val();
            if ((singleDate.length) == 0) {
                javascript: return confirm('Please enter the Date !!');
            }
            else {

                $.ajax({
                    type: "POST",
                    url: SageModulePath + "Services/SageAnnouncementWebService.asmx/GetAnnouncementByDate",
                    data: JSON2.stringify({ PortalID: parseInt(p.PortalId), ClickedDate: singleDate, UserModuleID: parseInt(p.usermoduleid) }),
                    contentType: "application/json; charset=utf-8",
                    dataType: "json",
                    success: function(msg) {
                        var htmlconten = "";
                        if (msg.d.length == 0) {
                            htmlconten += ('<div class=\"cssClassNoAnnounce\"><h3>' + p.NoContent + '</h3></div>');
							$('#PageNav').attr("style","display:none");
                        }
                        else {
                            //htmlconten += ('<h2 class=\"cssClassContentTile\"><span class=\"ContentTitleText\">' + p.AnnouncementHeader + ' in the date ' + singleDate + '</span></h2>');
                            $.each(msg.d, function(index, Data) {
                                var AnnouncementId = Data.AnnouncementID;
                                var announcementdate = dateFormat(Data.PublishDate, "fullDate");
                                htmlconten += ('<li><div class=\"cssClassAnnounceContent\">');
                                htmlconten += ('<div class=\"cssClassHead\"><h2 class=\"cssClassTitle\">' + Data.Title + '</h2></div>');
                                htmlconten += ('<span>By ' + Data.AuthorName + '</span> <span>On ' + announcementdate + '</span>');
                                htmlconten += ('<p></p>');
                                htmlconten += ('<div class=\"cssClassAnnounce\">' + Data.ShortDescription + '</div>');
                                htmlconten += ('<a href=\"#\" id="' + AnnouncementId + '" class=\"sfBtn\">' + p.ReadMoreText + '</a>');
                                htmlconten += ('</div></li>');


                            });
                        }
                        $('#divAnnouncement').html(htmlconten);
					
                        if (msg.d.length > p.Itemsperpage ) {
							
						
                    $('#SagePagination').pajinate({
                        items_per_page: p.Itemsperpage
                    });
					}
                    },
                    error: function(error) {
                        //alert('error getting load announcement');
                    }
                });
            }
        }

        $('#divAnnouncement a').live("click", function() {
            var id = $(this).attr("id");
            if (isNaN(id)) {
			$('#PageNav').attr("style","display:block");
                GetLatestAnnouncement();   // It isn't a number
            } else {
                getReadMoreData(id); // It is a number
            }


        });
    };
    $.fn.GetAnnouncement = function(p) {
        $.createAnnouncementScript(p);
    };
})(jQuery);


