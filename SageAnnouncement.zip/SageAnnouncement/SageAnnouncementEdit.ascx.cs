﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SageFrame.Web;
using SageFrame.Announcement.Entity;
using SageFrame.Announcement.Controller;

public partial class Modules_SageAnnouncement_SageAnnouncementEdit : BaseAdministrationUserControl
{

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                IncludeImage();
                LoadDataOngdvManageAnnouncement();
                PanelVisibility(true, false);
               
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }

    }

    protected void cvFckLong_ServerValidate(object source, ServerValidateEventArgs args)
    {
        try
        {
            if ((txtAnnounceLongDesc.Text == "&nbsp;") || (txtAnnounceLongDesc.Text == "<br />") || (txtAnnounceLongDesc.Text.Length == 0))
            {
                cvLong.ErrorMessage = SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/SageAnnouncement/ModuleLocalText", "PleaseEnterSomeContent");
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }


    protected void cvFckshort_ServerValidate(object source, ServerValidateEventArgs args)
    {
        try
        {
            if ((txtAnnounceShortDescription.Text == "&nbsp;" || (txtAnnounceShortDescription.Text == "<br />") || (txtAnnounceShortDescription.Text.Length == 0)))
            {
                cvShort.ErrorMessage = SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/SageAnnouncement/ModuleLocalText", "PleaseEnterSomeShortContent");
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }
        catch(Exception ex)
        {
            ProcessException(ex);
        }
    }


    private void IncludeImage()
    {
        try
        {
            imbUpdateAnnouncement.ImageUrl = GetTemplateImageUrl("imgsave.png", true);
            imbAnnouncementCancel.ImageUrl = GetTemplateImageUrl("imgcancel.png", true);
            imbAddAnnouncment.ImageUrl = GetTemplateImageUrl("imgadd.png", true);
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }

    }


    private void PanelVisibility(bool gdvPanel, bool formPanel)
    {
        try
        {
            pnlAnnouncementDisplay.Visible = gdvPanel;
            pnlAddAnnouncement.Visible = formPanel;
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }

    }


    private void ClearForm()
    {
        try
        {
            txtAnnouncementTitle.Text = string.Empty;
            txtAnnounceShortDescription.Text = string.Empty;
            txtAnnounceLongDesc.Text = string.Empty;
            txtAnnounceDate.Text = string.Empty;
            chkIsActive.Checked = false;
            txtAuthorName.Text = string.Empty;
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }


    #region gdvManageAnnouncement
    public void LoadDataOngdvManageAnnouncement()
    {
        try
        {
            AnnouncementController objc = new AnnouncementController();
            gdvManageAnnouncement.DataSource = objc.LoadDataOngdvManageAnnouncement(GetPortalID,Int32.Parse(SageUserModuleID) );
            gdvManageAnnouncement.DataBind();
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }

    protected void gdvManageAnnouncement_RowCommand(object sender, GridViewCommandEventArgs e)
    {

        try
        {
            int AnnouncementID = Int32.Parse(e.CommandArgument.ToString());
            switch (e.CommandName.ToString())
            {
                case "Edit":
                    AnnouncementEditByID(AnnouncementID);

                    break;
                case "Delete":
                    AnnouncementDeleteByID(AnnouncementID);
                    break;
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }




    protected void gdvManageAnnouncement_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {

            gdvManageAnnouncement.PageIndex = e.NewPageIndex;
            LoadDataOngdvManageAnnouncement();
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }

    }


    protected void gdvManageAnnouncement_RowEditing(object sender, GridViewEditEventArgs e)
    {

    }


    protected void gdvManageAnnouncement_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

    }


    public void AnnouncementEditByID(int AnnouncementID)
    {
        try
        {

            Session["AnnouncementID"] = AnnouncementID;
            AnnouncementController objC = new AnnouncementController();
            AnnouncementInfo objInfo = new AnnouncementInfo();
            objInfo = objC.GetAnnouncementByID(AnnouncementID);
            txtAnnouncementTitle.Text = objInfo.Title;
            txtAnnounceShortDescription.Text = objInfo.ShortDescription;
            txtAnnounceLongDesc.Text = objInfo.LongDescription;
            txtAnnounceDate.Text = Convert.ToString(objInfo.PublishDate);
            chkIsActive.Checked = objInfo.IsActive;
            txtAuthorName.Text = objInfo.AuthorName;
            PanelVisibility(false, true);
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }



    }


    public void AnnouncementDeleteByID(int AnnouncementID)
    {
        try
        {
            AnnouncementController objC = new AnnouncementController();
            objC.AnnouncementDeleteByID(AnnouncementID);
            ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/SageAnnouncement/ModuleLocalText", "AnnouncementDeletedSuccessfully"), "", SageMessageType.Success);
            LoadDataOngdvManageAnnouncement();
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }


    }
    #endregion


    protected void imbUpdateAnnouncement_Click(object sender, ImageClickEventArgs e)
    {
        try
        {

            AnnouncementInfo objInf = new AnnouncementInfo();
            if (Session["AnnouncementID"] != null)
            {
                objInf.AnnouncementID = Convert.ToInt32(Session["AnnouncementID"]);
            }
            else
            {
                objInf.AnnouncementID = 0;
            }
            objInf.Title = txtAnnouncementTitle.Text;
            objInf.ShortDescription = txtAnnounceShortDescription.Text;
            objInf.LongDescription = txtAnnounceLongDesc.Text;
            objInf.PublishDate = txtAnnounceDate.Text.ToString() ;
            objInf.IsActive = chkIsActive.Checked;
            objInf.PortalID = GetPortalID;
            objInf.UserModuleID = Int32.Parse(SageUserModuleID);
            objInf.AddedBy = GetUsername;
            objInf.AuthorName = txtAuthorName.Text;
            AnnouncementController objC = new AnnouncementController();
            objC.SaveAnnouncement(objInf);
            ShowMessage(SageMessageTitle.Information.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/SageAnnouncement/ModuleLocalText", "AnnouncementSavedSuccessfully"), "", SageMessageType.Success);
            Session.Abandon();
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
        LoadDataOngdvManageAnnouncement();
        PanelVisibility(true, false);

    }


    protected void imbAnnouncementCancel_Click(object sender, ImageClickEventArgs e)
    {
        PanelVisibility(true, false);

    }


    protected void imbAddAnnouncment_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            ClearForm();
            PanelVisibility(false, true);
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }

    }





    
}
