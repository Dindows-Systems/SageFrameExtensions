﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SageFrame.Web;
using SageFrame.Announcement.Controller;
using SageFrame.Announcement.Entity;
using System.Collections.Generic;
using System.Text;
using SageFrame.Announcement;


public partial class Modules_SageAnnouncement_SageAnnouncementView : BaseAdministrationUserControl
{   public string ItemsPerPage = "";
    public int UserModuleId;
    public int PortalId;
    public string AnnouncementHeader;
    public string ReadMoreText;
    public string DateFormat;
    public string SearchimageUrl = "";
    public string modulePath = "";
    public string basePageURL = "";
    public string NoContentText="";
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                modulePath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "globalVariables", " var SageModulePath='" + ResolveUrl(modulePath) + "';", true);
                UserModuleId = Int32.Parse(SageUserModuleID);
                PortalId = GetPortalID;
                SetAnnouncementSetting();
                SearchimageUrl = GetTemplateImageUrl("search-btn.jpg", true);
                IncludeJS();
                IncludeCSS();
                IncludeImage();
                if (Request.QueryString["RSS"] != null)
                {
                    GetSageAnnouncementRSS();
                }
            }
        }
        
        catch (Exception ex)
        {
            ProcessException(ex);
        }

    }


    private void IncludeCSS()
    {
        try
        {
            IncludeCss("SageBanner", "/Modules/SageAnnouncement/css/jscal2.css", "/Modules/SageAnnouncement/css/Module.css", "/Modules/SageAnnouncement/css/default/style.css", "/Modules/SageAnnouncement/css/style.css"); 
            //IncludeCssFile(modulePath + "css/matrix/matrix.css");
            

        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }

    }


    private void IncludeJS()
    {
        try
        {
            IncludeJs("SageBanner", "/Modules/SageAnnouncement/js/jscal2.js", "/Modules/SageAnnouncement/js/lang/en.js", "/Modules/SageAnnouncement/js/Announcement.js", "/Modules/SageAnnouncement/js/jquery.DateFormat.js", "/Modules/SageAnnouncement/js/jquery.cookie.js", "/Modules/SageAnnouncement/js/jquery.hotkeys.js", "/Modules/SageAnnouncement/js/jquery.jstree.js", "/Modules/SageAnnouncement/js/paginate.js");
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }

    }
    private void IncludeImage()
    {
        imgRssButton.ImageUrl = modulePath + "images/rss-icon.png";
    }


     private void SetAnnouncementSetting()
    {
        try
        {
            AnnouncementInfo objInf = GetAnnouncementSetting(GetPortalID, Int32.Parse(SageUserModuleID));
            AnnouncementHeader = objInf.AnnouncementHeaderText;
            ReadMoreText = objInf.ReadMoreText;
            //DateFormat = objInf.DateTimeFormat;
            NoContentText = objInf.NoContentText;
            ItemsPerPage = objInf.items_per_page;
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }


    private AnnouncementInfo GetAnnouncementSetting(int PortalID, int UserModuleID)
    {
        AnnouncementInfo GetSetting = new AnnouncementInfo();
        AnnouncementController ObjC = new AnnouncementController();
        return GetSetting = ObjC.GetAnnouncementSetting(PortalID, UserModuleID);
    }

    #region SageRSS Region

    private void GetSageAnnouncementRSS()
    {
        try
        {

            AnnouncementRSS objrss = new AnnouncementRSS();
            objrss.GetRSS(Int32.Parse(SageUserModuleID), Request.Url.AbsoluteUri,PageURL());

        }
       
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }
    private string PageURL()
    {
        AnnouncementInfo objAnnounceClass = new AnnouncementInfo();
        return   objAnnounceClass.BaseUrl(Request.RawUrl);
    }
   




    protected void imgRssButton_Click(object sender, ImageClickEventArgs e)
    {
        try
        {

            if (Session["BasePage"] != null)
            {
                string basePage = Session["BasePage"].ToString();
               string  redirectURL = basePage;
                if (basePage.Contains("?"))
                {
                    redirectURL += "&RSS=SageAnnouncement";
                }
                else
                {
                    redirectURL += "?RSS=SageAnnouncement";
                }
                Response.Redirect(redirectURL, false);
            }
            else
            {
                AnnouncementInfo objAnnounceClass = new AnnouncementInfo();
                 basePageURL = objAnnounceClass.BaseUrl(Request.RawUrl);
                if (basePageURL.Contains("?"))
                {
                    basePageURL += "&RSS=SageAnnouncement";
                }
                else
                {
                    basePageURL += "?RSS=SageAnnouncement";
                }
                Response.Redirect(basePageURL, false);
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }
    #endregion
}
