﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Web;
using SageFrame.Job;
using System.Data;
using System.IO;
using System.Collections;
using AjaxControlToolkit.HTMLEditor;
using FredCK.FCKeditorV2;
using System.Net.Mail;
public partial class Modules_JobModule_JobView : BaseAdministrationUserControl
{
    string filePath = string.Empty;
    string messageDetail = string.Empty;
    string messageSubject = string.Empty;
    public int UserModuleID = 0;
    public int PortalID = 0;
    public string serviceURL;
   // public string sagefilePath = string.Empty;
    public string Salary = string.Empty;
    public string CompanyUrl = string.Empty;
    public string ResumeEmailAddress = string.Empty;
    public string ResumeEmail = string.Empty;
    public string ResumeDatabase = string.Empty;
    public string FileSize = string.Empty;

    List<JobSetting> lstSetting = new List<JobSetting>();
    JobSetting objSetting = new JobSetting();
    protected void Page_Load(object sender, EventArgs e)
    {
        InitializeJS();
        lstSetting = JobDataProvider.SelectJobSetting(new JobSetting(Int32.Parse(SageUserModuleID), GetPortalID));
        if (!IsPostBack)
        {
            BindData();
            UserModuleID = Int32.Parse(SageUserModuleID);
            PortalID = GetPortalID;
            this.serviceURL = ResolveUrl(this.AppRelativeTemplateSourceDirectory) + "Services/WebService.asmx/";
            string modulePath = ResolveUrl(this.AppRelativeTemplateSourceDirectory);
            //sagefilePath = ""; 
           // sagefilePath=HttpContext.Current.Server.MapPath("~/" + "Modules/JobModule/Resume/");
            //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "EmailFileGlobalVariable", " var SageFilePath='" + HttpContext.Current.Server.MapPath("~/" + "Modules/JobModule/Resume/") + "';", true);
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DocumentDownloadGlobalVariable", " var DocumentUploadPath='" + ResolveUrl(modulePath) + "';", true);
        }
    }
    private void InitializeJS()
    {
        IncludeCss("cssModule", "Modules/JobModule/css/StyleSheet.css", "Modules/JobModule/css/message.style.css");
        IncludeJs("upload", "Modules/JobModule/js/ajaxupload.js");
        IncludeJs("alertbox", "Modules/JobModule/js/alertbox.js");

        //Page.ClientScript.RegisterClientScriptInclude("JQueryToolTip", ResolveUrl(this.AppRelativeTemplateSourceDirectory + "/js/jquery.tooltip.js"));
        // IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/StyleSheet.css");


    }
    private void BindData()
    {



        int usermoduleID = Int32.Parse(SageUserModuleID);

        List<JobSetting> lst = JobDataProvider.SelectJobSetting(new JobSetting(usermoduleID, GetPortalID));
        List<JobInfo> lstJob = JobDataProvider.SelectJobListForView();
        foreach (JobSetting setting in lst)
        {
            switch (setting.SettingKey)
            {
                case "CompanyUrl":
                    if (setting.SettingValue == "true")
                    {
                        CompanyUrl = "true";
                    }
                    break;


                case "Salary":
                    if (setting.SettingValue == "true")
                    {
                        Salary = "true";
                    }
                    break;
                case "ResumeEmailAddress":

                    ResumeEmailAddress = setting.SettingValue;

                    break;
                case "ResumeEmail":
                    if (setting.SettingValue == "true")
                    {
                        ResumeEmail = "true";
                    }
                    break;
                case "ResumeDatabase":
                    if (setting.SettingValue == "true")
                    {
                        ResumeDatabase = "true";
                    }
                    break;
                case "FileSize":
                    FileSize = setting.SettingValue;
                    break;








            }
        }

        //DataTable dtJob = FilterJob(CompanyUrl,jobType, Description, Salary, lstJob, RowNumber, CharNumber, format,ExpireDays,Alignment,TitleVacancy,ShowApply);
        //gdvJobList.DataSource = dtJob;
        //if (RowNumber > 0)
        //{
        //    gdvJobList.PageSize = RowNumber;
        //}
        //gdvJobList.DataBind();

    }
}
