﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Job;
using SageFrame.Web;
using SageFrame.SageFrameClass;
using System.Text.RegularExpressions;

public partial class Modules_JobModule_JobSetting : BaseAdministrationUserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            AddImageUrl();
            List<JobSetting> lst = JobDataProvider.SelectJobSetting(new JobSetting(int.Parse(SageUserModuleID), GetPortalID));
            foreach (JobSetting setting in lst)
            {
                string varSetting = string.Empty;
                switch (setting.SettingKey)
                {

                    case "CompanyUrl":
                        chkShowCompany.Checked = bool.Parse(setting.SettingValue);
                        break;


                    case "Salary":
                        if (setting.SettingValue == "true")
                        {

                            chkShowSalary.Checked = true;

                        }

                        break;
                    case "FileSize":
                        if (setting.SettingValue == "true")
                        {

                            ddlFileSize.SelectedValue = setting.SettingValue;

                        }
                        break;

                    case "ResumeDatabase":
                        if (setting.SettingValue == "true")
                        {


                            chkSaveResume.Checked = true;

                        }
                        break;
                    case "ResumeEmail":
                        if (setting.SettingValue == "true")
                        {

                            chkEmailResume.Checked = true;


                        }
                        break;
                    case "ResumeEmailAddress":
                        txtEmailAddress.Text = setting.SettingValue;
                        break;
                }

            }

        }
    }

    public void AddImageUrl()
    {
        btnAdd.ImageUrl = GetTemplateImageUrl("btnsave.png", true);

    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {


        string companyUrl = "false";
        if (chkShowCompany.Checked)
        {
            companyUrl = "true";

        }




        string salary = "false";
        if (chkShowSalary.Checked)
        {
            salary = "true";

        }


        string resumeDatabase = "false";
        if (chkSaveResume.Checked)
        {
            resumeDatabase = "true";
        }
        string resumeEmail = "false";
        if (chkEmailResume.Checked)
        {
            resumeEmail = "true";
        }

        string value_fileSize = ddlFileSize.SelectedValue;


        string value_resumeDatabase = resumeDatabase;
        string value_resumeEmail = resumeEmail;
        string value_resumeEmailAddress = txtEmailAddress.Text;
        string keyName_companyUrl = "CompanyUrl";

        string keyName_salary = "Salary";

        string keyName_fileSize = "FileSize";
        string keyName_resumeDataBase = "ResumeDatabase";
        string keyName_resumeEmail = "ResumeEmail";
        string keyName_resumeEmailAddress = "ResumeEmailAddress";
        try
        {
            JobDataProvider.AssignJobSetting(new JobSetting(keyName_resumeEmail, value_resumeEmail, true, GetUsername, GetUsername, GetPortalID, int.Parse(SageUserModuleID)));
            if (value_resumeEmailAddress != "" && value_resumeEmailAddress != string.Empty && value_resumeEmailAddress != null)
            {
                if (isEmail(value_resumeEmailAddress))
                {
                    JobDataProvider.AssignJobSetting(new JobSetting(keyName_resumeEmailAddress, value_resumeEmailAddress, true, GetUsername, GetUsername, GetPortalID, int.Parse(SageUserModuleID)));
                    lblEmailAddress.Text = string.Empty;
                }
                else
                {
                    lblEmailAddress.Text = "Invalid Email Address";
                    return;
                }
            }
            JobDataProvider.AssignJobSetting(new JobSetting(keyName_resumeEmailAddress, value_resumeEmailAddress, true, GetUsername, GetUsername, GetPortalID, int.Parse(SageUserModuleID)));
            JobDataProvider.AssignJobSetting(new JobSetting(keyName_companyUrl, companyUrl, true, GetUsername, GetUsername, GetPortalID, int.Parse(SageUserModuleID)));
            JobDataProvider.AssignJobSetting(new JobSetting(keyName_salary, salary, true, GetUsername, GetUsername, GetPortalID, int.Parse(SageUserModuleID)));
            JobDataProvider.AssignJobSetting(new JobSetting(keyName_fileSize, value_fileSize, true, GetUsername, GetUsername, GetPortalID, int.Parse(SageUserModuleID)));
            JobDataProvider.AssignJobSetting(new JobSetting(keyName_resumeDataBase, value_resumeDatabase, true, GetUsername, GetUsername, GetPortalID, int.Parse(SageUserModuleID)));
            ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/JobModule/ModuleLocalText", "JobSettingUpdatedSuccessfully"), "", SageMessageType.Success);
        }
        catch (Exception ex)
        {

            ProcessException(ex);
        }

    }
    protected void chkTitleVacancy_CheckedChanged(object sender, EventArgs e)
    {




    }
    public static bool isEmail(string inputEmail)
    {
        string strRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
              @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
              @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
        Regex re = new Regex(strRegex);
        if (re.IsMatch(inputEmail))
            return (true);
        else
            return (false);
    }
}
