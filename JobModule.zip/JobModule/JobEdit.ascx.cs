﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SageFrame.Job;
using SageFrame.Web;
using System.Data;
using System.IO;
using SageFrame.FileManager;
using System.Collections;
using System.Text.RegularExpressions;


public partial class Modules_JobModule_JobEdit : BaseAdministrationUserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            InitializeJS();
            if (!IsPostBack)
            {
                BindDepartment();
                BindData();
                AddImageUrl();
                BindDepartmentData();
                BindDepartmentResume();
                pnlJobAdd.Visible = false;
                pnlDepartment.Visible = false;
                pnlResume.Visible = false;
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
       
    }
    private void InitializeJS()
    {
        IncludeCss("jobmodule", "Modules/JobModule/css/popup.css");    
        //IncludeCssFile(AppRelativeTemplateSourceDirectory + "css/popup.css");
    }
    public void AddImageUrl()
    {
        btnSubmit.ImageUrl = GetTemplateImageUrl("btnsave.png", true);
        imgBtnSumit.ImageUrl = GetTemplateImageUrl("btnsave.png", true);
        imgExpiryDate.ImageUrl = GetTemplateImageUrl("imgcalendar.png", true);
        imgPostedDate.ImageUrl = GetTemplateImageUrl("imgcalendar.png", true);
        btnCancel.ImageUrl = GetTemplateImageUrl("btncancel.png", true);
        btnDepartmentCancel.ImageUrl = GetTemplateImageUrl("btncancel.png", true);
        btnAddJob.ImageUrl = GetTemplateImageUrl("imgadd.png", true);
        btnAddDepartment.ImageUrl = GetTemplateImageUrl("imgadd.png", true);
        btnResume.ImageUrl = GetTemplateImageUrl("imgcontinue.png", true);
        
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            bool status = false;
            DateTime postedDate = DateTime.Parse("1/1/1754");
            DateTime expiryDate = DateTime.Parse("1/1/1754");
            if ((string)ViewState["update"]!="true")
            {
                if(chkStatus.Checked)
                {
                    status=true;
                }
                string dateFirst = txtPostedDate.Text;
                string dateSecond = txtExpiryDate.Text;
                DateTime date1, date2;
                bool date1OK, date2OK;
                date1 = new DateTime(1, 1, 1);
                date2 = new DateTime(1, 1, 1);
                try
                {

                    date1 = Convert.ToDateTime(dateFirst);
                    date1OK = true;
                }
                catch (Exception)
                {

                    date1OK = false;
                }

                try
                {
                    date2 = Convert.ToDateTime(dateSecond);
                    date2OK = true;
                }

                catch
                {
                    date2OK = false;
                }
                
                if (date2OK==true && date1OK==true)
                {
                    expiryDate = DateTime.Parse(txtExpiryDate.Text);
                
                }
                if (date2OK == true && date1OK == true)
                {
                    postedDate = DateTime.Parse(txtPostedDate.Text);
                }
                
                if (date1OK == true && date2OK == true)
                {
                    int JobID = JobDataProvider.AddNewJob(new JobInfo(0,txtJobTitle.Text, txtSalary.Text, txtDescription.Text.ToString(), txtPost.Text, int.Parse(ddlDepartment.SelectedValue), status, txtJobType.Text, postedDate, expiryDate, int.Parse(txtNoVacancy.Text),Int32.Parse(SageUserModuleID),GetPortalID,txtLocation.Text));
                    int CompanyID = JobDataProvider.AddCompanyInfo(new JobInfo(txtCompanyUrl.Text));
                    JobDataProvider.AddCompanyDepartmentJob(new JobInfo(int.Parse(ddlDepartment.SelectedValue), JobID, CompanyID));
                }
                else
                {
                    lblResult.Text = "Date Format Is Not Supported";
                    return;
                }
              // ShowMessage(SageMessageTitle.Information.ToString(), GetSageMessage("JobModule", "JobIsAddedSuccessfully"), "", SageMessageType.Success);
               ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/JobModule/ModuleLocalText", "JobIsAddedSuccessfully"), "", SageMessageType.Success);
               pnlJobList.Visible = true;
               pnlJobAdd.Visible = false;
               BindData();
            }
            else
            {
                List<JobInfo>lst=new List<JobInfo>();
                if (txtExpiryDate.Text != null && txtExpiryDate.Text != " " && txtExpiryDate.Text != string.Empty)
                {
                    expiryDate = DateTime.Parse(txtExpiryDate.Text);
                }
                if (txtPostedDate.Text != null && txtPostedDate.Text != "" && txtPostedDate.Text != string.Empty)
                {
                    postedDate = DateTime.Parse(txtPostedDate.Text);

                }
                if (chkStatus.Checked)
                {
                    status = true;
                }
                int jobID = int.Parse(hdnIDHolder.Value);
                bool result = JobDataProvider.UpdateJob(new JobInfo(jobID, txtJobTitle.Text, txtSalary.Text, txtDescription.Text.ToString(), txtPost.Text, int.Parse(ddlDepartment.SelectedValue), status, txtJobType.Text, postedDate, expiryDate, int.Parse(txtNoVacancy.Text),Int32.Parse(SageUserModuleID),GetPortalID,txtLocation.Text));

                int companyID = int.Parse(hdnCompanyIDHolder.Value);
                bool secondResult = JobDataProvider.UpdateCompanyInfo(new JobInfo(txtCompanyUrl.Text));

                bool thirdResult = JobDataProvider.UpdateCompanyJobDepartment(new JobInfo(int.Parse(ddlDepartment.SelectedValue), jobID, companyID));
                if (result == true && thirdResult==true && thirdResult==true)
                {
                    ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/JobModule/ModuleLocalText", "JobIsUpdatedSuccessfully"), "", SageMessageType.Success);
                    pnlJobList.Visible = true;
                    pnlJobAdd.Visible = false;
                }

                BindData();
                ViewState["update"] = string.Empty;
            }
        }
        catch (Exception ex)
        {
            ProcessException(ex);
        }
    }
    public void BindDepartment()
    {
        List<JobInfo> lst = JobDataProvider.SelectDepartment();
        ddlDepartment.DataSource = lst;
        ddlDepartment.DataTextField = "department_name";
        ddlDepartment.DataValueField = "department_id";
        ddlDepartment.DataBind();
    }
    protected void imgBtnSumit_Click(object sender, EventArgs e)
    {
        string update=(string)ViewState["update"];
        if (update!="true")
        {
            try
            {
                JobDataProvider.AddNewDepartment(new JobInfo(txtCategory.Text,0,Int32.Parse(SageUserModuleID),GetPortalID ));
                ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/JobModule/ModuleLocalText", "DepartmentIsAddedSuccessfully"), "", SageMessageType.Success);
                BindDepartmentData();
                ddlDepartment.Items.Clear();
                BindDepartment();
               
            }
            catch (Exception ex)
            {

                ProcessException(ex);
            }
        }
        else
        {
            try
            {
                int departmentID = int.Parse(ViewState["departmentID"].ToString());
                bool result=JobDataProvider.UpdateDepartment(new JobInfo(txtCategory.Text,departmentID,Int32.Parse(SageUserModuleID),GetPortalID));
                BindDepartmentData();
            if (result == true)
            {
                ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/JobModule/ModuleLocalText", "DepartmentIsUpdatedSuccessfully"), "", SageMessageType.Error);
                ViewState["update"] = "false";
                txtCategory.Text = string.Empty;
                ddlDepartment.Items.Clear();
                BindDepartment();
            }
            }
            catch (Exception ex)
            {
                
               ProcessException(ex);
            }
        }
    }
    public void BindData()
    {
        int CharNumber = 3;
        List<JobInfo> lst = JobDataProvider.SelectJobList(Int32.Parse(SageUserModuleID),GetPortalID);
        lst.ForEach(
            delegate(JobInfo obj)
            {
                obj.first_name = obj.first_name + " " + obj.middle_name + "" + obj.last_name;
                string description = obj.description;
                string[] showDescription = new string[description.Length];
                showDescription = description.Split(' ');
                string[] showFinalDescription1 = new string[CharNumber];
                string showFinalDescription = string.Empty;
                for (int j = 0; j < CharNumber; j++)
                {
                    if (showDescription.Length > j)
                    {
                        showFinalDescription += string.Concat(showDescription[j].ToString(), '+');
                    }
                }
                string showFinalDescription2 = showFinalDescription.Replace('+', ' ');
                showFinalDescription2 = string.Concat(showFinalDescription2, ".....");
                obj.description = showFinalDescription2;
            }
            );
        rptrJobList.DataSource = lst;
        rptrJobList.DataBind();
    }
    public void BindDepartmentData()
    {
        List<JobInfo> lst = JobDataProvider.SelectDepartment();
        gdvDepartment.DataSource = lst;
        gdvDepartment.DataBind();
    
    }
    protected void rptrJobList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int Id = int.Parse(e.CommandArgument.ToString());
        
           switch (e.CommandName)
            {
                case "Select":
                    pnlJobAdd.Visible = true;
                    pnlJobList.Visible = false;
                    List<JobInfo> lst = JobDataProvider.SelectJobByID(new JobInfo(Id));
                    foreach (JobInfo job in lst)
                    {
                      
                        txtJobTitle.Text = job.job_title;
                        txtDescription.Text = job.description;
                        txtPost.Text = job.post;
                        txtSalary.Text = job.salary;
                        ddlDepartment.ClearSelection();
                        ddlDepartment.Items.FindByValue(Convert.ToString(job.department_id)).Selected=true;
                        txtNoVacancy.Text = job.no_of_vacancy.ToString();
                        if (job.status == true)
                        {
                            chkStatus.Checked = true;

                        }
                        txtCompanyUrl.Text = job.company_url;
                    }
                    break;
                case "DeleteJob":
                    try
                    {
                        bool result = JobDataProvider.DeleteJob(new JobInfo(Id));
                        ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/JobModule/ModuleLocalText", "JobIsDeletedSuccessfully"), "", SageMessageType.Success);
                        BindData();
                    }
                    catch (Exception ex)
                    {
                        ProcessException(ex);
                    }
                    break;
            }
    }

    protected void rptrJobList_SelectedIndexChanged(object sender, EventArgs e)
    {
        ViewState["update"] = "true";
        int Id = int.Parse((rptrJobList.SelectedRow.FindControl("lblID") as Label).Text);
        List<JobInfo> lst = JobDataProvider.SelectJobByID(new JobInfo(Id));
        foreach (JobInfo job in lst)
        {
            txtJobTitle.Text = job.job_title;
            txtDescription.Text = job.description;
            txtPost.Text = job.post;
            txtSalary.Text = job.salary;
            hdnIDHolder.Value = job.job_id.ToString();
            //ddlDepartment.SelectedValue = job.department_name;
            txtNoVacancy.Text = job.no_of_vacancy.ToString();
            txtJobType.Text = job.job_type;
            txtLocation.Text = job.Location;
            txtPostedDate.Text = job.posted_date_time.ToString();
            txtExpiryDate.Text = job.expiry_date_time.ToString();
            hdnCompanyIDHolder.Value = job.company_id.ToString();
            if (job.status == true)
            {
                chkStatus.Checked = true;
            
            }

        }
    }
    protected void gdvDepartment_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int Id = int.Parse(e.CommandArgument.ToString());

        switch (e.CommandName)
        {
            case "Select":
                List<JobInfo> lst = JobDataProvider.SelectDepartmentByID(new JobInfo(Id));
                foreach (JobInfo job in lst)
                {
                    txtCategory.Text = job.department_name;
                    ViewState["departmentID"] = job.department_id;
                }
                break;
            case "DeleteDepartment":
                try
                {
                    bool result = JobDataProvider.DeleteDepartment(new JobInfo(Id));
                    ShowMessage(SageMessageTitle.Notification.ToString(), SageMessage.GetSageModuleLocalMessageByVertualPath("Modules/JobModule/ModuleLocalText", "DepartmentIsDeletedSuccessfullty"), "", SageMessageType.Success);
                    BindDepartmentData();
                }
                catch (Exception ex)
                {
                    ProcessException(ex);
                }
                break;
        }
    }
    protected void gdvDepartment_SelectedIndexChanged(object sender, EventArgs e)
    {
       
        ViewState["update"] = "true";
    }
    protected void gdvDepartmentResume_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        switch (e.CommandName)
        {
            case "showResume":

                int departmentID = int.Parse(e.CommandArgument.ToString());
                ViewState["DepartmentID"] = departmentID;
                BindJobTitleResume(departmentID);
                    break;
        
        }
    }
    public void BindDepartmentResume()
    {
        List<JobInfo> lstResume = JobDataProvider.SelectDepartmentResume();
        gdvDepartmentResume.DataSource = lstResume;
        gdvDepartmentResume.DataBind();
    }
    public void BindJobTitleResume(int departmentID)
    {
        List<JobInfo>lstTitleResume=JobDataProvider.SelectJobTitleResume(new JobInfo(departmentID));
        gdvTitleResume.DataSource = lstTitleResume;
        gdvTitleResume.DataBind();
    }
    public void DownloadFile(string filepath)
    {
        FileInfo file = new FileInfo(filepath);
        string actualFileName = file.Name.Substring(0, file.Name.LastIndexOf("."));
        if (file.Exists)
        {
            Response.ClearContent();
            Response.AddHeader("Content-Disposition", "attachment; filename=" + file.Name.Replace(' ', '_'));
            Response.ContentType = FileManagerHelper.ReturnExtension(Path.GetExtension(file.Name));
            Response.TransmitFile(file.FullName);
            Response.End();
        }
    }
    public string GetAbsolutePath(string filepath)
    {
      return  Path.GetFullPath(filepath);
    
    }
    protected void gdvTitleResume_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        switch (e.CommandName)
        {
            case "download":


                string resume = e.CommandArgument.ToString();
                string fPath = "Resume\\" + resume;
                string FilePath = MapPath(fPath);
                string filePath = "..Modules\\JobModule\\Resume\\" + resume;
                DownloadFile(FilePath);
                break;
        }
    }
    protected void btnAddJob_Click(object sender, EventArgs e)
    {
        pnlJobAdd.Visible = true;
        pnlJobList.Visible = false;
        pnlDepartment.Visible = false;
        pnlResume.Visible = false;
        txtCompanyUrl.Text = string.Empty;
        txtCategory.Text = string.Empty;
        txtJobTitle.Text = string.Empty;
        txtSalary.Text = string.Empty;
        txtPost.Text = string.Empty;
        txtPostedDate.Text = string.Empty;
        txtExpiryDate.Text = string.Empty;
        txtJobType.Text = string.Empty;
        txtDescription.Text = string.Empty;
        txtLocation.Text = string.Empty;
        txtNoVacancy.Text = string.Empty;
    }
    protected void btnAddDepartment_Click(object sender, EventArgs e)
    {
        pnlDepartment.Visible = true;
        pnlJobList.Visible = false;
        pnlJobAdd.Visible = false;
        pnlResume.Visible = false;
    }
    protected void btnResume_Click(object sender, EventArgs e)
    {
        pnlResume.Visible = true;
        pnlJobList.Visible = false;
        pnlDepartment.Visible = false;
        pnlJobAdd.Visible = false;
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        pnlJobAdd.Visible = false;
        pnlJobList.Visible = true;
    
    }
    protected void btnDepartmentCancel_Click(object sender, EventArgs e)
    {
        pnlDepartment.Visible = false;
        pnlJobList.Visible = true;
    
    }
    protected void gdvTitleResume_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvTitleResume.PageIndex = e.NewPageIndex;
        int id = (int)ViewState["DepartmentID"];
        if (id != null)
        {

            BindJobTitleResume(id);
        }
    }
    protected void rptrJobList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        rptrJobList.PageIndex = e.NewPageIndex;
        BindData();

    }
}
